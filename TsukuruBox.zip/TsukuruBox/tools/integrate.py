#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
쯔꾸르박스 통합 스크립트 — 원본 엔진 소스를 고정 커밋으로 받아 한 APK 로 합칠 수 있게 정리한다.
원본 저장소는 수정하지 않고, 필요한 변경은 아래 두 가지 방식으로만 한다.
  1) deps/gen/ 아래에 '고친 사본'을 만든다 (리소스 이름 충돌, SDL2 패키지 이름 변경)
  2) Winlator app/build.gradle 에 오버레이 한 줄을 붙이고, 루트 경로 가정 두 곳을 고친다

사용법
  python3 tools/integrate.py                # EasyRPG + Winlator
  python3 tools/integrate.py --with-mkxp    # + mkxp-z (실험적)
  python3 tools/integrate.py --check        # 네트워크 없이 현재 상태만 검사

필요: git, python3 (mkxp-z 는 bash, wget 추가)
"""
from __future__ import annotations

import argparse
import hashlib
import io
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TP = ROOT / "deps"
GEN = TP / "gen"
MARKER = "// >>> tsukurubox overlay"

# 빌드 중 내려받는 완성품 파일의 SHA-256 (바뀌면 빌드를 멈춰 변조된 파일이 들어가지 않게 함)
SDL3_AAR_SHA256 = {"3.4.8": "3e853028f8ccbd54e5aabc071922ceb11c74f88249fc4cb112c5226d12b67f2e"}

# 동작을 확인한 커밋으로 고정 (업스트림이 바뀌어도 빌드가 깨지지 않게)
PINS = {
    "Player": ("https://github.com/EasyRPG/Player.git", "e68fff4a13a3dd5d40678ae66ee60f85ccb04153"),
    "buildscripts": ("https://github.com/EasyRPG/buildscripts.git", "84cf2f449a0d1c09f17d2bbf3d28f4f573aa718a"),
    "winlator": ("https://github.com/StevenMXZ/Winlator-Ludashi.git", "29373dde819e5cf9b7e30ac2bb5bd97b5aac0cb7"),
    "mkxp-z-android": ("https://github.com/thehatkid/mkxp-z-android.git", "468fe8128a40cc7d2cba4ac7fbe21a82787de255"),
    "krkr2yuri": ("https://github.com/YuriSizuku/Kirikiroid2Yuri.git", "6e61ce3b81416ceb2be3427a5f0471edefab7151"),
}

# 吉里吉里(Kirikiroid2Yuri) 빌드용 파일. 원작자가 GitHub 릴리스로 배포하는 미리 빌드된 의존 라이브러리와,
# 1.3.9 릴리스 APK 의 assets/ (UI 그림·문자열 데이터만 사용, 코드는 쓰지 않음)
KRKR_BASE = "https://github.com/YuriSizuku/Kirikiroid2Yuri/releases/download"
KRKR_FILES = {
    "thirdparty_build.tar.gz": (f"{KRKR_BASE}/deps/thirdparty_build.tar.gz",
                                "99edcfefc9685b14fe8a7cc2a63aa90be2d4f4652ae6843cd189490eb49f9729"),
    "thirdparty_port.tar.gz": (f"{KRKR_BASE}/deps/thirdparty_port.tar.gz",
                               "ba188338d8ca4e9b73854523fe39febca276b5cad2b89227010853ca88119d8a"),
    "Kirikiroid2_yuri_1.3.9.apk": (f"{KRKR_BASE}/1.3.9_yuri/Kirikiroid2_yuri_1.3.9.apk",
                                   "782d85ed767ec8c07d69709b668275f3872ae6472b02343038538f011337c83d"),
}


def log(msg: str):
    print(f"[integrate] {msg}", flush=True)


def die(msg: str):
    print(f"[integrate] 오류: {msg}", file=sys.stderr)
    sys.exit(1)


def run(cmd, cwd=None):
    log("$ " + " ".join(str(c) for c in cmd))
    subprocess.run(cmd, cwd=cwd, check=True)


# ─── 1. 소스 받기 ───────────────────────────────────────────

def git_head(repo: Path) -> str | None:
    try:
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, check=True,
                              capture_output=True, text=True).stdout.strip()
    except Exception:
        return None


def fetch(name: str):
    url, sha = PINS[name]
    dest = TP / name
    if (dest / ".git").exists() and git_head(dest) == sha:
        log(f"{name}: {sha[:10]} 이미 준비됨")
        init_submodules(name, dest)
        return dest
    dest.mkdir(parents=True, exist_ok=True)
    if not (dest / ".git").exists():
        run(["git", "init", "-q"], cwd=dest)
        run(["git", "remote", "add", "origin", url], cwd=dest)
    run(["git", "fetch", "--depth", "1", "origin", sha], cwd=dest)
    run(["git", "checkout", "-q", "-f", "FETCH_HEAD"], cwd=dest)
    run(["git", "clean", "-q", "-fdx", "-e", "app/src/main/assets/imagefs.tar.zst",
         "-e", "app/src/main/assets/proton-9.0-arm64ec.tar.zst"], cwd=dest)
    init_submodules(name, dest)
    return dest


# 빌드에 필요한 git 서브모듈 (Winlator 네이티브 코드가 libadrenotools 를 add_subdirectory 로 포함)
SUBMODULES = {"winlator": ["app/src/main/cpp/adrenotools"]}


def init_submodules(name: str, dest: Path):
    for path in SUBMODULES.get(name, []):
        if (dest / path / "CMakeLists.txt").is_file():
            continue
        run(["git", "submodule", "update", "--init", "--recursive", "--depth", "1", path], cwd=dest)


# ─── 2. Winlator 패치 ───────────────────────────────────────

def strip_block(text: str, keyword: str) -> str:
    """최상위 'keyword { ... }' 블록을 중괄호 짝을 맞춰 제거"""
    m = re.search(rf"(?m)^{keyword}\s*\{{", text)
    if not m:
        return text
    depth, i = 0, m.end() - 1
    while i < len(text):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[:m.start()] + text[i + 1:].lstrip("\n")
        i += 1
    die(f"{keyword} 블록의 닫는 중괄호를 찾지 못함")


def patch_winlator():
    gradle = TP / "winlator" / "app" / "build.gradle"
    if not gradle.is_file():
        die(f"{gradle} 없음")
    text = gradle.read_text(encoding="utf-8")
    if MARKER in text:
        log("winlator: 이미 패치됨")
        return
    # (a) 서브모듈 buildscript 의 AGP 8.8 클래스패스 제거 → 루트의 AGP 8.13 하나만 사용
    text = strip_block(text, "buildscript")
    # (b) imagefs/proton 다운로드 경로가 Winlator 저장소 루트를 rootDir 로 가정 → 모듈 기준으로 변경
    n = text.count("new File(project.rootDir,")
    if n != 2:
        die(f"winlator build.gradle 의 rootDir 참조가 예상(2)과 다름: {n}")
    text = text.replace("new File(project.rootDir,", "new File(project.projectDir.parentFile,")
    # (c) 오버레이 적용
    text = text.rstrip() + f"\n\n{MARKER}\napply from: rootProject.file('overlay/winlator-app.gradle')\n"
    gradle.write_text(text, encoding="utf-8")
    log("winlator: build.gradle 패치 완료")


def patch_winlator_privacy():
    """로딩 화면 그림을 찾으려고 게임 제목을 TheGamesDB 로 자동 전송하는 기능 끄기"""
    p = TP / "winlator/app/src/main/java/com/winlator/cmod/core/PreloaderDialog.java"
    t = p.read_text(encoding="utf-8")
    tag = "// tsukurubox: no-thegamesdb"
    if tag in t:
        return
    sig = "    private void requestTheGamesDbBanner(String title, File destination) {\n"
    if t.count(sig) != 1:
        die("PreloaderDialog.requestTheGamesDbBanner 구조가 예상과 다름")
    t = t.replace(sig, sig + f"        if (true) return; {tag}\n")
    p.write_text(t, encoding="utf-8")
    log("winlator: TheGamesDB 자동 조회 비활성화")


def patch_winlator_paths():
    """Winlator 가 내장 저장소 최상위에 만드는 Winlator/ 폴더(logs, banners, icons, Saves…)를
    TsukuruBox/Winlator/ 아래로 옮긴다. 파일 경로 문자열만 바꾸므로 동작은 같다."""
    src = TP / "winlator/app/src/main/java"
    rules = [
        (re.compile(r'"Winlator/'), '"TsukuruBox/Winlator/'),
        (re.compile(r'(getExternalStorageDirectory\(\),\s*)"Winlator"'), r'\1"TsukuruBox/Winlator"'),
        (re.compile(r'getPath\(\)\s*\+\s*"/Winlator"'), 'getPath() + "/TsukuruBox/Winlator"'),
    ]
    changed = 0
    for f in src.rglob("*.java"):
        t = f.read_text(encoding="utf-8")
        nt = t
        for rx, rep in rules:
            nt = rx.sub(rep, nt)
        nt = nt.replace('"TsukuruBox/TsukuruBox/', '"TsukuruBox/')
        if nt != t:
            f.write_text(nt, encoding="utf-8")
            changed += 1
    settings = (src / "com/winlator/cmod/SettingsFragment.java").read_text(encoding="utf-8")
    if '"/TsukuruBox/Winlator"' not in settings:
        die("SettingsFragment.DEFAULT_WINLATOR_PATH 구조가 예상과 다름")
    log(f"winlator: 저장 폴더를 TsukuruBox/Winlator 로 이동 ({changed}개 파일)")


# ─── 3. 리소스 이름 충돌 정리 ───────────────────────────────

STYLE_TOKEN = r'(?<=["/])AppTheme(?=[."])'
JAVA_STYLE_TOKEN = r"(?<=R\.style\.)AppTheme(?=[_;),\s])"


def copy_res_renamed(src: Path, dst: Path, theme: str, xml_renames: dict[str, str]):
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    changed = 0
    for f in dst.rglob("*.xml"):
        t = f.read_text(encoding="utf-8")
        nt = re.sub(STYLE_TOKEN, theme, t)
        for old, new in xml_renames.items():
            nt = nt.replace(f"@xml/{old}\"", f"@xml/{new}\"")
        if nt != t:
            f.write_text(nt, encoding="utf-8")
            changed += 1
    for old, new in xml_renames.items():
        for f in dst.glob(f"xml*/{old}.xml"):
            f.rename(f.with_name(f"{new}.xml"))
    # 검증: 원래 테마 이름이 스타일 참조로 남아 있으면 안 됨
    for f in dst.rglob("*.xml"):
        if re.search(STYLE_TOKEN, f.read_text(encoding="utf-8")):
            die(f"테마 이름 변경 누락: {f}")
    log(f"리소스 사본 {dst.relative_to(ROOT)} (수정된 파일 {changed}개)")


def prepare_easyrpg():
    src = TP / "Player" / "builds" / "android" / "app" / "src" / "main"
    copy_res_renamed(src / "res", GEN / "easyrpg" / "res", "ErpgAppTheme", {"file_paths": "erpg_file_paths"})
    java_hits = [p for p in (src / "java").rglob("*.java")
                 if re.search(JAVA_STYLE_TOKEN, p.read_text(encoding="utf-8"))]
    if java_hits:
        die(f"EasyRPG Java 가 R.style.AppTheme 을 직접 참조함 — 스크립트 갱신 필요: {java_hits}")


def download_sdl3_aar():
    props = (TP / "Player" / "builds" / "android" / "gradle.properties").read_text(encoding="utf-8")
    m = re.search(r"(?m)^sdlVersion=(\S+)", props)
    if not m:
        die("EasyRPG gradle.properties 에서 sdlVersion 을 찾지 못함")
    ver = m.group(1)
    ours = re.search(r"(?m)^easyrpgSdlVersion=(\S+)", (ROOT / "gradle.properties").read_text(encoding="utf-8"))
    if not ours or ours.group(1) != ver:
        die(f"gradle.properties 의 easyrpgSdlVersion 을 {ver} 로 맞추세요")
    aar = TP / "aars" / f"SDL3-{ver}.aar"
    if aar.is_file() and verify_sha(aar, SDL3_AAR_SHA256.get(ver)):
        log(f"SDL3 AAR {ver} 이미 준비됨")
        publish_local_maven(aar, ver)
        return
    url = f"https://github.com/libsdl-org/SDL/releases/download/release-{ver}/SDL3-devel-{ver}-android.zip"
    log(f"SDL3 {ver} 다운로드: {url}")
    data = urllib.request.urlopen(url, timeout=300).read()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [n for n in z.namelist() if n.endswith(".aar")]
        if not names:
            die("SDL3 zip 안에 .aar 가 없음")
        aar.parent.mkdir(parents=True, exist_ok=True)
        aar.write_bytes(z.read(names[0]))
    if not verify_sha(aar, SDL3_AAR_SHA256.get(ver)):
        aar.unlink()
        die("SDL3 AAR 의 SHA-256 이 예상과 다릅니다 (파일 변조 또는 업스트림 변경)")
    log(f"SDL3 AAR 저장 (SHA-256 확인): {aar.relative_to(ROOT)}")
    publish_local_maven(aar, ver)


def verify_sha(path: Path, expected: str | None) -> bool:
    if expected is None:
        die(f"{path.name} 의 기준 SHA-256 이 없습니다. tools/integrate.py 에 추가하세요")
    return hashlib.sha256(path.read_bytes()).hexdigest() == expected


def publish_local_maven(aar: Path, ver: str):
    """라이브러리 모듈은 로컬 .aar 파일을 직접 의존할 수 없으므로 로컬 maven 저장소 형태로 둔다"""
    d = TP / "maven" / "org" / "libsdl" / "android" / "SDL3" / ver
    d.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(aar, d / f"SDL3-{ver}.aar")
    (d / f"SDL3-{ver}.pom").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<project xmlns="http://maven.apache.org/POM/4.0.0">\n'
        '  <modelVersion>4.0.0</modelVersion>\n'
        '  <groupId>org.libsdl.android</groupId>\n'
        '  <artifactId>SDL3</artifactId>\n'
        f'  <version>{ver}</version>\n'
        '  <packaging>aar</packaging>\n'
        '</project>\n', encoding="utf-8")


# ─── 4. mkxp-z (실험적) ─────────────────────────────────────

def prepare_mkxp(skip_deps: bool):
    app = TP / "mkxp-z-android" / "app"
    jni = app / "jni"
    if not skip_deps:
        run(["bash", "get_deps.sh"], cwd=jni)
    sdl = jni / "SDL2"
    if not sdl.is_dir():
        die("mkxp-z 의존성(SDL2)이 없습니다. get_deps.sh 실행 결과를 확인하세요")

    # (a) SDL2 C 소스의 JNI 이름: org.libsdl.app → org.libsdl.app2 (EasyRPG 의 SDL3 와 클래스 충돌 방지)
    touched = 0
    for f in list((sdl / "src").rglob("*.c")) + list((sdl / "src").rglob("*.cpp")) + list((sdl / "src").rglob("*.h")):
        t = f.read_text(encoding="utf-8", errors="surrogateescape")
        nt = re.sub(r"\borg_libsdl_app\b", "org_libsdl_app2", t)
        nt = nt.replace("org/libsdl/app/", "org/libsdl/app2/")
        if nt != t:
            f.write_text(nt, encoding="utf-8", errors="surrogateescape")
            touched += 1
    core = (sdl / "src/core/android/SDL_android.c").read_text(encoding="utf-8", errors="surrogateescape")
    if "org_libsdl_app2" not in core or "org/libsdl/app/" in core:
        die("SDL_android.c 패키지 이름 변경 실패")
    log(f"SDL2 C 소스 {touched}개 파일 JNI 패키지 변경")

    # (b) arm64 전용
    amk = jni / "Application.mk"
    amk.write_text(re.sub(r"(?m)^APP_ABI\s*:=.*$", "APP_ABI := arm64-v8a", amk.read_text(encoding="utf-8")),
                   encoding="utf-8")

    # (c) Java 사본: org.libsdl.app → org.libsdl.app2, 런처가 넘긴 게임 경로 사용
    gj = GEN / "mkxp" / "java"
    if gj.exists():
        shutil.rmtree(gj)
    shutil.copytree(app / "src" / "main" / "java", gj)
    old_pkg, new_pkg = gj / "org/libsdl/app", gj / "org/libsdl/app2"
    shutil.move(str(old_pkg), str(new_pkg))
    for f in gj.rglob("*.java"):
        t = f.read_text(encoding="utf-8")
        nt = re.sub(r"\borg\.libsdl\.app\b(?!2)", "org.libsdl.app2", t)
        if nt != t:
            f.write_text(nt, encoding="utf-8")
    main = gj / "com/hatkid/mkxpz/MainActivity.java"
    t = main.read_text(encoding="utf-8")
    t = t.replace("BuildConfig.APPLICATION_ID", "getPackageName()")
    hook = "        super.onCreate(savedInstanceState);\n"
    if t.count(hook) != 1:
        die("mkxp MainActivity.onCreate 구조가 예상과 다름")
    t = t.replace(hook, hook +
                  "        // 쯔꾸르박스 런처가 넘긴 게임 폴더\n"
                  "        String tbGamePath = getIntent() != null ? getIntent().getStringExtra(\"game_path\") : null;\n"
                  "        if (tbGamePath != null) GAME_PATH = tbGamePath;\n")
    main.write_text(t, encoding="utf-8")
    log("mkxp-z Java 사본 준비 (org.libsdl.app2, game_path)")

    # (d) 리소스 사본 (AppTheme → MkxpAppTheme)
    copy_res_renamed(app / "src" / "main" / "res", GEN / "mkxp" / "res", "MkxpAppTheme", {})


# ─── 5. 점검 ────────────────────────────────────────────────

# ─── 吉里吉里 (Kirikiroid2Yuri) ─────────────────────────────

def download_file(url: str, dest: Path, sha: str):
    """큰 파일을 디스크로 바로 받으며 SHA-256 확인 (메모리에 올리지 않음)"""
    if dest.is_file() and hashlib.sha256(dest.read_bytes()).hexdigest() == sha:
        log(f"{dest.name} 이미 받음")
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    log(f"다운로드: {url}")
    h = hashlib.sha256()
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=600) as r, open(tmp, "wb") as f:
                h = hashlib.sha256()
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
                    h.update(b)
            break
        except Exception as e:
            log(f"  재시도 {attempt + 1}/3: {e}")
    else:
        raise RuntimeError(f"{dest.name} 다운로드 실패")
    if h.hexdigest() != sha:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"{dest.name} SHA-256 불일치 (받은 값 {h.hexdigest()})")
    tmp.replace(dest)


def extract_tar(archive: Path, dest: Path, prefix: str):
    """prefix 로 시작하는 항목만 풀기 (폴더 밖으로 나가는 경로·링크는 거부)"""
    import tarfile
    base = dest.resolve()
    n = 0
    with tarfile.open(archive, "r:gz") as t:
        for m in t:
            if not m.name.startswith(prefix):
                continue
            target = (dest / m.name).resolve()
            if not str(target).startswith(str(base) + "/"):
                raise RuntimeError(f"잘못된 압축 경로: {m.name}")
            if m.issym() or m.islnk():
                link = (target.parent / m.linkname).resolve()
                if not str(link).startswith(str(base) + "/"):
                    continue
            t.extract(m, dest)
            n += 1
    log(f"{archive.name}: {prefix} 항목 {n}개 풀기")


KRKR_STARTUP_TAG = "// tsukurubox: startup-path"


def patch_krkr_startup(repo: Path):
    """쯔꾸르박스가 넘긴 게임 경로로 바로 시작하고, 크래시 덤프를 외부 서버(http)로 보내는 기능은 끈다"""
    p = repo / "src/core/environ/android/AndroidUtils.cpp"
    t = p.read_text(encoding="utf-8", errors="surrogateescape")
    if KRKR_STARTUP_TAG in t:
        return
    old = "\tTVPCheckAndSendDumps(Android_GetDumpStoragePath(), GetPackageName(), TVPGetPackageVersionString());\n"
    if t.count(old) != 1:
        raise RuntimeError("AndroidUtils.cpp 의 TVPCheckStartupArg 구조가 예상과 다름")
    new = (
        f"\t{KRKR_STARTUP_TAG}\n"
        "\t{\n"
        "\t\tstd::string sp;\n"
        "\t\tJniMethodInfo mi;\n"
        "\t\tif (JniHelper::getStaticMethodInfo(mi, \"org/tvp/kirikiri2/TsukuruKirikiriActivity\", \"getStartupPath\", \"()Ljava/lang/String;\")) {\n"
        "\t\t\tjstring js = (jstring)mi.env->CallStaticObjectMethod(mi.classID, mi.methodID);\n"
        "\t\t\tif (js) {\n"
        "\t\t\t\tconst char *c = mi.env->GetStringUTFChars(js, nullptr);\n"
        "\t\t\t\tif (c) { sp = c; mi.env->ReleaseStringUTFChars(js, c); }\n"
        "\t\t\t\tmi.env->DeleteLocalRef(js);\n"
        "\t\t\t}\n"
        "\t\t\tmi.env->DeleteLocalRef(mi.classID);\n"
        "\t\t}\n"
        "\t\tif (!sp.empty() && TVPTsukuruStartup(sp)) return true;\n"
        "\t}\n"
    )
    t = t.replace(old, new)
    decl = "bool TVPCheckStartupArg() {\n"
    if t.count(decl) != 1:
        raise RuntimeError("AndroidUtils.cpp 의 TVPCheckStartupArg 선언을 찾지 못함")
    t = t.replace(decl, "bool TVPTsukuruStartup(const std::string &path);\n" + decl)
    # 정의는 TVPMainScene 헤더를 이미 쓰는 MainScene.cpp 에 둔다 (다른 파일에 cocos UI 헤더를 끌어들이지 않음)
    ms = repo / "src/core/environ/cocos2d/MainScene.cpp"
    mt = ms.read_text(encoding="utf-8", errors="surrogateescape")
    anchor = "bool TVPMainScene::startupFrom(const std::string &path) {"
    if mt.count(anchor) != 1:
        raise RuntimeError("MainScene.cpp 의 startupFrom 을 찾지 못함")
    mt = mt.replace(anchor, "bool TVPTsukuruStartup(const std::string &path) { " + KRKR_STARTUP_TAG + "\n"
                    "\treturn TVPMainScene::GetInstance()->startupFrom(path);\n}\n\n" + anchor)
    ms.write_text(mt, encoding="utf-8", errors="surrogateescape")
    p.write_text(t, encoding="utf-8", errors="surrogateescape")
    log("吉里吉里: 시작 경로 연동, 덤프 전송 끄기")


def prepare_kirikiri():
    repo = fetch("krkr2yuri")
    dl = TP / "dlcache" / "krkr"
    for name, (url, sha) in KRKR_FILES.items():
        download_file(url, dl / name, sha)
    if not (repo / "thirdparty/build/arch_androida64/lib/libcocos2d.a").is_file():
        extract_tar(dl / "thirdparty_build.tar.gz", repo, "thirdparty/build/arch_androida64")
    if not (repo / "thirdparty/port/cocos2d-x/cocos/platform/android/java/src").is_dir():
        extract_tar(dl / "thirdparty_port.tar.gz", repo, "thirdparty/port/cocos2d-x")
    assets = repo / "assets"
    if not (assets / "locale").is_dir():
        with zipfile.ZipFile(dl / "Kirikiroid2_yuri_1.3.9.apk") as z:
            for n in z.namelist():
                if not n.startswith("assets/") or n.endswith("/") or ".." in n:
                    continue
                out = repo / n
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(z.read(n))
        log("吉里吉里: UI 에셋 준비")
    patch_krkr_startup(repo)
    # Java: org.tvp.kirikiri2 만 사용 (com.yuri 의 앱 진입점은 쓰지 않음)
    src = repo / "project/android/app/java/org/tvp/kirikiri2"
    dst = GEN / "kirikiri/java/org/tvp/kirikiri2"
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    # compileSdk 34+ 에서 Context.getDeviceId() 와 이름이 겹쳐 컴파일 오류 → 이름 변경 (네이티브 호출도 같이)
    ka = dst / "KR2Activity.java"
    kt = ka.read_text(encoding="utf-8")
    sig = "static public String getDeviceId()"
    if kt.count(sig) != 1:
        raise RuntimeError("KR2Activity.getDeviceId 구조가 예상과 다름")
    ka.write_text(kt.replace(sig, "static public String getDeviceIdStr()"), encoding="utf-8")
    au = repo / "src/core/environ/android/AndroidUtils.cpp"
    at = au.read_text(encoding="utf-8", errors="surrogateescape")
    call = '"getDeviceId", "()Ljava/lang/String;"'
    if call in at:
        au.write_text(at.replace(call, '"getDeviceIdStr", "()Ljava/lang/String;"'), encoding="utf-8", errors="surrogateescape")
    elif '"getDeviceIdStr"' not in at:
        raise RuntimeError("AndroidUtils.cpp 의 getDeviceId 호출을 찾지 못함")
    res = GEN / "kirikiri/res"
    if res.exists():
        shutil.rmtree(res)
    (res / "drawable").mkdir(parents=True)
    shutil.copyfile(repo / "project/android/app/res/drawable/sd_operate_step.png", res / "drawable/sd_operate_step.png")
    (GEN / "kirikiri/.ready").write_text("ok", encoding="utf-8")
    log("吉里吉里 준비 완료")


def check(with_mkxp: bool):
    ok = True

    def expect(cond, msg):
        nonlocal ok
        print(("  ✔ " if cond else "  ✘ ") + msg)
        ok &= bool(cond)

    g = TP / "winlator" / "app" / "build.gradle"
    gt = g.read_text(encoding="utf-8") if g.is_file() else ""
    expect(MARKER in gt, "Winlator 오버레이 적용")
    expect(not re.search(r"(?m)^buildscript\s*\{", gt), "Winlator buildscript 블록 제거")
    expect("project.rootDir" not in gt, "Winlator 경로 가정 수정")
    expect((TP / "winlator/app/src/main/cpp/adrenotools/CMakeLists.txt").is_file(), "Winlator 서브모듈(adrenotools)")
    pd = TP / "winlator/app/src/main/java/com/winlator/cmod/core/PreloaderDialog.java"
    expect(pd.is_file() and "tsukurubox: no-thegamesdb" in pd.read_text(encoding="utf-8"), "TheGamesDB 자동 조회 비활성화")
    expect((GEN / "easyrpg/res/xml/erpg_file_paths.xml").is_file(), "EasyRPG 리소스 사본")
    expect(any((TP / "maven/org/libsdl/android/SDL3").glob("*/SDL3-*.aar")), "SDL3 AAR (로컬 maven)")
    if with_mkxp:
        expect((GEN / "mkxp/java/org/libsdl/app2/SDLActivity.java").is_file(), "mkxp-z SDL2 Java 패키지 변경")
    if (GEN / "kirikiri/.ready").is_file():
        print("  ✔ 吉里吉里(Kirikiroid2) 내장 준비")
    else:
        print("  - 吉里吉里(Kirikiroid2) 내장 없음 (준비 실패 또는 --no-kirikiri)")
    return ok


def main():
    ap = argparse.ArgumentParser(description="쯔꾸르박스 엔진 통합")
    ap.add_argument("--with-mkxp", action="store_true", help="mkxp-z 포함 (실험적)")
    ap.add_argument("--skip-mkxp-deps", action="store_true", help="mkxp-z get_deps.sh 생략 (이미 받은 경우)")
    ap.add_argument("--check", action="store_true", help="상태만 검사")
    ap.add_argument("--no-kirikiri", action="store_true", help="吉里吉里(Kirikiroid2) 내장 제외")
    args = ap.parse_args()

    if args.check:
        sys.exit(0 if check(args.with_mkxp) else 1)

    if shutil.which("git") is None:
        die("git 이 필요합니다")
    TP.mkdir(exist_ok=True)
    for name in ("Player", "buildscripts", "winlator"):
        fetch(name)
    patch_winlator()
    patch_winlator_privacy()
    patch_winlator_paths()
    prepare_easyrpg()
    download_sdl3_aar()
    if args.with_mkxp:
        fetch("mkxp-z-android")
        prepare_mkxp(args.skip_mkxp_deps)
    ready = GEN / "kirikiri/.ready"
    if args.no_kirikiri:
        ready.unlink(missing_ok=True)
    else:
        try:
            prepare_kirikiri()
        except Exception as e:
            # 吉里吉里 준비가 실패해도 나머지 엔진은 빌드되게 한다
            ready.unlink(missing_ok=True)
            log(f"경고: 吉里吉里 내장 준비 실패 → 이번 빌드에서 제외 ({e})")

    print()
    if not check(args.with_mkxp):
        die("점검 실패")
    log("완료")


if __name__ == "__main__":
    main()
