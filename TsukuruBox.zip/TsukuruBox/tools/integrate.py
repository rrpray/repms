#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
쯔꾸르박스 통합 스크립트 — 원본 엔진 소스를 고정 커밋으로 받아 한 APK 로 합칠 수 있게 정리한다.
원본 저장소는 수정하지 않고, 필요한 변경은 아래 두 가지 방식으로만 한다.
  1) deps/gen/ 아래에 '고친 사본'을 만든다 (리소스 이름 충돌, SDL2 패키지 이름 변경)
  2) Winlator app/build.gradle 에 오버레이 한 줄을 붙이고, 루트 경로 가정 두 곳을 고친다

사용법
  python3 tools/integrate.py                # EasyRPG + Winlator
  python3 tools/integrate.py --with-mkxp    # + mkxp-z (실험적)
  python3 tools/integrate.py --check        # 네트워크 없이 현재 상태만 검사

필요: git, python3 (mkxp-z 는 bash, wget 추가)
"""
from __future__ import annotations

import argparse
import io
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TP = ROOT / "deps"
GEN = TP / "gen"
MARKER = "// >>> tsukurubox overlay"

# 동작을 확인한 커밋으로 고정 (업스트림이 바뀌어도 빌드가 깨지지 않게)
PINS = {
    "Player": ("https://github.com/EasyRPG/Player.git", "e68fff4a13a3dd5d40678ae66ee60f85ccb04153"),
    "buildscripts": ("https://github.com/EasyRPG/buildscripts.git", "84cf2f449a0d1c09f17d2bbf3d28f4f573aa718a"),
    "winlator": ("https://github.com/StevenMXZ/Winlator-Ludashi.git", "29373dde819e5cf9b7e30ac2bb5bd97b5aac0cb7"),
    "mkxp-z-android": ("https://github.com/thehatkid/mkxp-z-android.git", "468fe8128a40cc7d2cba4ac7fbe21a82787de255"),
}


def log(msg: str):
    print(f"[integrate] {msg}", flush=True)


def die(msg: str):
    print(f"[integrate] 오류: {msg}", file=sys.stderr)
    sys.exit(1)


def run(cmd, cwd=None):
    log("$ " + " ".join(str(c) for c in cmd))
    subprocess.run(cmd, cwd=cwd, check=True)


# ─── 1. 소스 받기 ───────────────────────────────────────────

def git_head(repo: Path) -> str | None:
    try:
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, check=True,
                              capture_output=True, text=True).stdout.strip()
    except Exception:
        return None


def fetch(name: str):
    url, sha = PINS[name]
    dest = TP / name
    if (dest / ".git").exists() and git_head(dest) == sha:
        log(f"{name}: {sha[:10]} 이미 준비됨")
        return dest
    dest.mkdir(parents=True, exist_ok=True)
    if not (dest / ".git").exists():
        run(["git", "init", "-q"], cwd=dest)
        run(["git", "remote", "add", "origin", url], cwd=dest)
    run(["git", "fetch", "--depth", "1", "origin", sha], cwd=dest)
    run(["git", "checkout", "-q", "-f", "FETCH_HEAD"], cwd=dest)
    run(["git", "clean", "-q", "-fdx", "-e", "app/src/main/assets/imagefs.tar.zst",
         "-e", "app/src/main/assets/proton-9.0-arm64ec.tar.zst"], cwd=dest)
    return dest


# ─── 2. Winlator 패치 ───────────────────────────────────────

def strip_block(text: str, keyword: str) -> str:
    """최상위 'keyword { ... }' 블록을 중괄호 짝을 맞춰 제거"""
    m = re.search(rf"(?m)^{keyword}\s*\{{", text)
    if not m:
        return text
    depth, i = 0, m.end() - 1
    while i < len(text):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[:m.start()] + text[i + 1:].lstrip("\n")
        i += 1
    die(f"{keyword} 블록의 닫는 중괄호를 찾지 못함")


def patch_winlator():
    gradle = TP / "winlator" / "app" / "build.gradle"
    if not gradle.is_file():
        die(f"{gradle} 없음")
    text = gradle.read_text(encoding="utf-8")
    if MARKER in text:
        log("winlator: 이미 패치됨")
        return
    # (a) 서브모듈 buildscript 의 AGP 8.8 클래스패스 제거 → 루트의 AGP 8.13 하나만 사용
    text = strip_block(text, "buildscript")
    # (b) imagefs/proton 다운로드 경로가 Winlator 저장소 루트를 rootDir 로 가정 → 모듈 기준으로 변경
    n = text.count("new File(project.rootDir,")
    if n != 2:
        die(f"winlator build.gradle 의 rootDir 참조가 예상(2)과 다름: {n}")
    text = text.replace("new File(project.rootDir,", "new File(project.projectDir.parentFile,")
    # (c) 오버레이 적용
    text = text.rstrip() + f"\n\n{MARKER}\napply from: rootProject.file('overlay/winlator-app.gradle')\n"
    gradle.write_text(text, encoding="utf-8")
    log("winlator: build.gradle 패치 완료")


# ─── 3. 리소스 이름 충돌 정리 ───────────────────────────────

STYLE_TOKEN = r'(?<=["/])AppTheme(?=[."])'
JAVA_STYLE_TOKEN = r"(?<=R\.style\.)AppTheme(?=[_;),\s])"


def copy_res_renamed(src: Path, dst: Path, theme: str, xml_renames: dict[str, str]):
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    changed = 0
    for f in dst.rglob("*.xml"):
        t = f.read_text(encoding="utf-8")
        nt = re.sub(STYLE_TOKEN, theme, t)
        for old, new in xml_renames.items():
            nt = nt.replace(f"@xml/{old}\"", f"@xml/{new}\"")
        if nt != t:
            f.write_text(nt, encoding="utf-8")
            changed += 1
    for old, new in xml_renames.items():
        for f in dst.glob(f"xml*/{old}.xml"):
            f.rename(f.with_name(f"{new}.xml"))
    # 검증: 원래 테마 이름이 스타일 참조로 남아 있으면 안 됨
    for f in dst.rglob("*.xml"):
        if re.search(STYLE_TOKEN, f.read_text(encoding="utf-8")):
            die(f"테마 이름 변경 누락: {f}")
    log(f"리소스 사본 {dst.relative_to(ROOT)} (수정된 파일 {changed}개)")


def prepare_easyrpg():
    src = TP / "Player" / "builds" / "android" / "app" / "src" / "main"
    copy_res_renamed(src / "res", GEN / "easyrpg" / "res", "ErpgAppTheme", {"file_paths": "erpg_file_paths"})
    java_hits = [p for p in (src / "java").rglob("*.java")
                 if re.search(JAVA_STYLE_TOKEN, p.read_text(encoding="utf-8"))]
    if java_hits:
        die(f"EasyRPG Java 가 R.style.AppTheme 을 직접 참조함 — 스크립트 갱신 필요: {java_hits}")


def download_sdl3_aar():
    props = (TP / "Player" / "builds" / "android" / "gradle.properties").read_text(encoding="utf-8")
    m = re.search(r"(?m)^sdlVersion=(\S+)", props)
    if not m:
        die("EasyRPG gradle.properties 에서 sdlVersion 을 찾지 못함")
    ver = m.group(1)
    ours = re.search(r"(?m)^easyrpgSdlVersion=(\S+)", (ROOT / "gradle.properties").read_text(encoding="utf-8"))
    if not ours or ours.group(1) != ver:
        die(f"gradle.properties 의 easyrpgSdlVersion 을 {ver} 로 맞추세요")
    aar = TP / "aars" / f"SDL3-{ver}.aar"
    if aar.is_file():
        log(f"SDL3 AAR {ver} 이미 준비됨")
        return
    url = f"https://github.com/libsdl-org/SDL/releases/download/release-{ver}/SDL3-devel-{ver}-android.zip"
    log(f"SDL3 {ver} 다운로드: {url}")
    data = urllib.request.urlopen(url, timeout=300).read()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [n for n in z.namelist() if n.endswith(".aar")]
        if not names:
            die("SDL3 zip 안에 .aar 가 없음")
        aar.parent.mkdir(parents=True, exist_ok=True)
        aar.write_bytes(z.read(names[0]))
    log(f"SDL3 AAR 저장: {aar.relative_to(ROOT)}")


# ─── 4. mkxp-z (실험적) ─────────────────────────────────────

def prepare_mkxp(skip_deps: bool):
    app = TP / "mkxp-z-android" / "app"
    jni = app / "jni"
    if not skip_deps:
        run(["bash", "get_deps.sh"], cwd=jni)
    sdl = jni / "SDL2"
    if not sdl.is_dir():
        die("mkxp-z 의존성(SDL2)이 없습니다. get_deps.sh 실행 결과를 확인하세요")

    # (a) SDL2 C 소스의 JNI 이름: org.libsdl.app → org.libsdl.app2 (EasyRPG 의 SDL3 와 클래스 충돌 방지)
    touched = 0
    for f in list((sdl / "src").rglob("*.c")) + list((sdl / "src").rglob("*.cpp")) + list((sdl / "src").rglob("*.h")):
        t = f.read_text(encoding="utf-8", errors="surrogateescape")
        nt = re.sub(r"\borg_libsdl_app\b", "org_libsdl_app2", t)
        nt = nt.replace("org/libsdl/app/", "org/libsdl/app2/")
        if nt != t:
            f.write_text(nt, encoding="utf-8", errors="surrogateescape")
            touched += 1
    core = (sdl / "src/core/android/SDL_android.c").read_text(encoding="utf-8", errors="surrogateescape")
    if "org_libsdl_app2" not in core or "org/libsdl/app/" in core:
        die("SDL_android.c 패키지 이름 변경 실패")
    log(f"SDL2 C 소스 {touched}개 파일 JNI 패키지 변경")

    # (b) arm64 전용
    amk = jni / "Application.mk"
    amk.write_text(re.sub(r"(?m)^APP_ABI\s*:=.*$", "APP_ABI := arm64-v8a", amk.read_text(encoding="utf-8")),
                   encoding="utf-8")

    # (c) Java 사본: org.libsdl.app → org.libsdl.app2, 런처가 넘긴 게임 경로 사용
    gj = GEN / "mkxp" / "java"
    if gj.exists():
        shutil.rmtree(gj)
    shutil.copytree(app / "src" / "main" / "java", gj)
    old_pkg, new_pkg = gj / "org/libsdl/app", gj / "org/libsdl/app2"
    shutil.move(str(old_pkg), str(new_pkg))
    for f in gj.rglob("*.java"):
        t = f.read_text(encoding="utf-8")
        nt = re.sub(r"\borg\.libsdl\.app\b(?!2)", "org.libsdl.app2", t)
        if nt != t:
            f.write_text(nt, encoding="utf-8")
    main = gj / "com/hatkid/mkxpz/MainActivity.java"
    t = main.read_text(encoding="utf-8")
    t = t.replace("BuildConfig.APPLICATION_ID", "getPackageName()")
    hook = "        super.onCreate(savedInstanceState);\n"
    if t.count(hook) != 1:
        die("mkxp MainActivity.onCreate 구조가 예상과 다름")
    t = t.replace(hook, hook +
                  "        // 쯔꾸르박스 런처가 넘긴 게임 폴더\n"
                  "        String tbGamePath = getIntent() != null ? getIntent().getStringExtra(\"game_path\") : null;\n"
                  "        if (tbGamePath != null) GAME_PATH = tbGamePath;\n")
    main.write_text(t, encoding="utf-8")
    log("mkxp-z Java 사본 준비 (org.libsdl.app2, game_path)")

    # (d) 리소스 사본 (AppTheme → MkxpAppTheme)
    copy_res_renamed(app / "src" / "main" / "res", GEN / "mkxp" / "res", "MkxpAppTheme", {})


# ─── 5. 점검 ────────────────────────────────────────────────

def check(with_mkxp: bool):
    ok = True

    def expect(cond, msg):
        nonlocal ok
        print(("  ✔ " if cond else "  ✘ ") + msg)
        ok &= bool(cond)

    g = TP / "winlator" / "app" / "build.gradle"
    gt = g.read_text(encoding="utf-8") if g.is_file() else ""
    expect(MARKER in gt, "Winlator 오버레이 적용")
    expect(not re.search(r"(?m)^buildscript\s*\{", gt), "Winlator buildscript 블록 제거")
    expect("project.rootDir" not in gt, "Winlator 경로 가정 수정")
    expect((GEN / "easyrpg/res/xml/erpg_file_paths.xml").is_file(), "EasyRPG 리소스 사본")
    expect(any((TP / "aars").glob("SDL3-*.aar")), "SDL3 AAR")
    if with_mkxp:
        expect((GEN / "mkxp/java/org/libsdl/app2/SDLActivity.java").is_file(), "mkxp-z SDL2 Java 패키지 변경")
    return ok


def main():
    ap = argparse.ArgumentParser(description="쯔꾸르박스 엔진 통합")
    ap.add_argument("--with-mkxp", action="store_true", help="mkxp-z 포함 (실험적)")
    ap.add_argument("--skip-mkxp-deps", action="store_true", help="mkxp-z get_deps.sh 생략 (이미 받은 경우)")
    ap.add_argument("--check", action="store_true", help="상태만 검사")
    args = ap.parse_args()

    if args.check:
        sys.exit(0 if check(args.with_mkxp) else 1)

    if shutil.which("git") is None:
        die("git 이 필요합니다")
    TP.mkdir(exist_ok=True)
    for name in ("Player", "buildscripts", "winlator"):
        fetch(name)
    patch_winlator()
    prepare_easyrpg()
    download_sdl3_aar()
    if args.with_mkxp:
        fetch("mkxp-z-android")
        prepare_mkxp(args.skip_mkxp_deps)

    print()
    if not check(args.with_mkxp):
        die("점검 실패")
    log("완료")


if __name__ == "__main__":
    main()
