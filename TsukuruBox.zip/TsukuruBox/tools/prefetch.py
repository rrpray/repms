#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EasyRPG buildscripts 가 받는 소스 압축파일을 미리 받아 캐시 폴더에 둔다.

원본 스크립트는 다운로드 결과를 검사하지 않아서, 사이트가 HTML 오류 페이지를 돌려주면
"gzip: stdin: not in gzip format" 으로 멈춘다 (GitHub Actions 에서 zlib.net 이 그랬음).
여기서는 여러 주소를 차례로 시도하고, 진짜 압축파일인지 확인한 것만 캐시에 넣는다.
buildscripts 는 EASYRPG_PATH_DOWNLOADCACHE 에 파일이 있으면 그것을 쓴다.

사용법: python3 tools/prefetch.py <buildscripts 경로> <캐시 폴더>
"""
import re
import sys
import tarfile
import time
import urllib.request
import zipfile
from pathlib import Path

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"


def mirrors(url: str, file: str):
    yield url
    m = re.match(r"https?://zlib\.net/(?:fossils/)?zlib-([\d.]+)\.tar\.gz$", url)
    if m:
        v = m.group(1)
        yield f"https://github.com/madler/zlib/releases/download/v{v}/zlib-{v}.tar.gz"
        yield f"https://zlib.net/zlib-{v}.tar.gz"
        yield f"https://zlib.net/fossils/zlib-{v}.tar.gz"
    m = re.match(r"https?://download\.sourceforge\.net/libpng/(libpng-[\d.]+\.tar\.xz)$", url)
    if m:
        yield f"https://downloads.sourceforge.net/project/libpng/libpng16/{m.group(1)[7:-7]}/{m.group(1)}"
    m = re.match(r"https?://download\.savannah\.gnu\.org/releases/freetype/(.+)$", url)
    if m:
        yield f"https://download-mirror.savannah.gnu.org/releases/freetype/{m.group(1)}"
        ver = re.sub(r"freetype-([\d.]+)\..*", r"\1", m.group(1))
        yield f"https://sourceforge.net/projects/freetype/files/freetype2/{ver}/{m.group(1)}/download"
    yield f"https://easyrpg.org/downloads/sources/{file}"


def valid(path: Path) -> bool:
    try:
        if path.suffix == ".zip":
            with zipfile.ZipFile(path) as z:
                return len(z.namelist()) > 0
        with tarfile.open(path) as t:
            return t.next() is not None
    except Exception:
        return False


def fetch(url: str, dest: Path) -> bool:
    for u in mirrors(url, dest.name):
        for attempt in range(2):
            try:
                req = urllib.request.Request(u, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=120) as r:
                    dest.write_bytes(r.read())
                if valid(dest):
                    print(f"  ✔ {dest.name}  ← {u}", flush=True)
                    return True
                print(f"  · {u} → 압축파일 아님", flush=True)
                break
            except Exception as e:
                print(f"  · {u} → {e}", flush=True)
                time.sleep(2)
    dest.unlink(missing_ok=True)
    return False


def main():
    bs, cache = Path(sys.argv[1]), Path(sys.argv[2])
    cache.mkdir(parents=True, exist_ok=True)
    pk = (bs / "shared" / "packages.sh").read_text(encoding="utf-8")
    urls = dict(re.findall(r'(?m)^([A-Z0-9_]+_URL)="?([^"\s]+)"?', pk))
    script = (bs / "android" / "1_download_library.sh").read_text(encoding="utf-8")
    needed = re.findall(r"download_and_extract \$([A-Z0-9_]+_URL)", script)

    failed = []
    for var in needed:
        url = urls.get(var)
        if not url:
            print(f"  ? {var} 정의 없음 (건너뜀)")
            continue
        dest = cache / url.rsplit("/", 1)[-1]
        if dest.is_file() and valid(dest):
            print(f"  ✔ {dest.name} (캐시)")
            continue
        if not fetch(url, dest):
            failed.append(url)
    if failed:
        print("\n다운로드 실패:\n  " + "\n  ".join(failed))
        sys.exit(1)


if __name__ == "__main__":
    main()
