#!/usr/bin/env bash
# 쯔꾸르박스 원샷 빌드 — Linux 또는 Windows WSL2(Ubuntu) 에서 실행
#
#   ./build.sh               # EasyRPG + Winlator + HTML5 러너
#   ./build.sh --with-mkxp   # + mkxp-z (실험적, 빌드 시간·실패 가능성 증가)
#   ./build.sh --debug       # 디버그 APK (느림, 개발용)
#
# 결과물: dist/TsukuruBox.apk
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

WITH_MKXP=0
VARIANT=Release
for a in "$@"; do
  case "$a" in
    --with-mkxp) WITH_MKXP=1 ;;
    --debug) VARIANT=Debug ;;
    -h|--help) sed -n 2,8p "$0"; exit 0 ;;
    *) echo "알 수 없는 옵션: $a"; exit 1 ;;
  esac
done

step() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
fail() { printf '\n\033[1;31m[오류] %s\033[0m\n' "$*" >&2; exit 1; }

# ─── 0. 호스트 도구 확인 ────────────────────────────────────
step "호스트 도구 확인"
[[ "$(uname -s)" == "Linux" ]] || fail "Linux 또는 WSL2 에서 실행하세요 (EasyRPG 툴체인 스크립트가 Linux/macOS 전용)"
case "$ROOT" in /mnt/*) echo "  ⚠ Windows 드라이브(/mnt/...) 위에서는 매우 느립니다. WSL 홈(~/) 에 두고 빌드하세요." ;; esac

need=(git curl unzip python3 cmake make autoconf automake libtoolize pkg-config patch perl meson ninja g++ javac)
[[ $WITH_MKXP == 1 ]] && need+=(wget ruby bison xxd)
missing=()
for t in "${need[@]}"; do command -v "$t" >/dev/null 2>&1 || missing+=("$t"); done
if ((${#missing[@]})); then
  echo "  없는 도구: ${missing[*]}"
  echo "  Ubuntu/WSL 이라면:"
  echo "    sudo apt update && sudo apt install -y git curl unzip zip xz-utils python3 cmake make autoconf automake libtool \\"
  echo "      pkg-config patch perl meson ninja-build build-essential openjdk-17-jdk wget ruby bison xxd gettext"
  fail "필요한 도구를 설치한 뒤 다시 실행하세요"
fi
JV=$(javac -version 2>&1 | grep -oE '[0-9]+' | head -1)
(( JV >= 17 )) || fail "JDK 17 이상이 필요합니다 (현재 javac $JV)"

# ─── 1. 소스 준비 ───────────────────────────────────────────
step "엔진 소스 받기 및 통합 (tools/integrate.py)"
if [[ $WITH_MKXP == 1 ]]; then python3 tools/integrate.py --with-mkxp; else python3 tools/integrate.py; fi

# ─── 2. EasyRPG 네이티브 툴체인 (Android SDK/NDK 설치 포함) ─
BS="$ROOT/third_party/buildscripts/android"
export ANDROID_HOME="$BS/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
export BUILD_LIBLCF=1   # EasyRPG 의 RPG Maker 데이터 파서(liblcf)도 툴체인에 포함

if [[ ! -x "$SDKM" ]]; then
  step "Android SDK/NDK 및 EasyRPG 라이브러리 소스 다운로드 (buildscripts 1단계)"
  (cd "$BS" && ./1_download_library.sh)
fi

if [[ ! -f "$BS/arm64-v8a-toolchain/.tsukurubox-done" ]]; then
  step "EasyRPG 의존 라이브러리 빌드 — arm64 전용 (buildscripts 2단계, 수십 분 소요)"
  # 원본 스크립트는 4개 ABI 를 모두 빌드하므로 arm64 만 남긴 사본으로 실행
  sed -E '/^build "(ARMeabi-v7a|x86|x86_64)"/s/^/# /' "$BS/2_build_toolchain.sh" > "$BS/2_build_toolchain_arm64.sh"
  chmod +x "$BS/2_build_toolchain_arm64.sh"
  (cd "$BS" && ./2_build_toolchain_arm64.sh && ./3_cleanup.sh)
  touch "$BS/arm64-v8a-toolchain/.tsukurubox-done"
fi

# ─── 3. 나머지 SDK 구성요소 (Winlator 는 NDK 29 / SDK 35~36 사용) ─
step "추가 Android SDK 구성요소 설치"
yes | "$SDKM" --licenses >/dev/null 2>&1 || true
"$SDKM" --install "platforms;android-36" "build-tools;35.0.0" "build-tools;36.0.0" \
  "ndk;29.0.14206865" "ndk;28.2.13676358" "cmake;3.22.1" "platform-tools" >/dev/null
echo "sdk.dir=$ANDROID_HOME" > "$ROOT/local.properties"

# ─── 4. mkxp-z 네이티브 의존성 (선택) ───────────────────────
GRADLE_ARGS=(-PeasyrpgToolchain="$BS")
if [[ $WITH_MKXP == 1 ]]; then
  step "mkxp-z 의존성 빌드 (Ruby, OpenSSL, OpenAL, iconv)"
  JNI="$ROOT/third_party/mkxp-z-android/app/jni"
  (cd "$JNI/mkxp-z" && sh make_xxd.sh)
  make -C "$JNI" -j"$(nproc)" HOST=aarch64-linux-android TARGET=aarch64-linux-android ABI=arm64-v8a \
    ARCH=linux-x86_64 ANDROID_NDK_HOME="$ANDROID_HOME/ndk/28.2.13676358"
  GRADLE_ARGS+=(-PwithMkxp=true)
fi

# ─── 5. APK 빌드 ───────────────────────────────────────────
step "APK 빌드 (:winlator:assemble$VARIANT)"
./gradlew --no-daemon "${GRADLE_ARGS[@]}" ":winlator:assemble$VARIANT"

v_lower=$(echo "$VARIANT" | tr '[:upper:]' '[:lower:]')
APK=$(ls -t third_party/winlator/app/build/outputs/apk/"$v_lower"/*.apk 2>/dev/null | head -1 || true)
[[ -n "$APK" ]] || fail "APK 를 찾지 못했습니다"
mkdir -p dist
cp "$APK" dist/TsukuruBox.apk
step "완료: dist/TsukuruBox.apk ($(du -h dist/TsukuruBox.apk | cut -f1))"
echo "  설치 전: 폰에 Winlator Cmod/Ludashi(com.winlator.cmod)가 있으면 먼저 삭제하세요 (같은 패키지명)."
echo "  설치:   adb install -r dist/TsukuruBox.apk   또는 APK 파일을 폰으로 옮겨 설치"
