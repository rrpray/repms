# 쯔꾸르박스 (TsukuruBox)

쯔꾸르 게임과 Windows 게임을 **한 앱 안에서** 실행하는 안드로이드 앱입니다.
오픈소스 엔진들을 한 APK에 넣고, 런처가 게임 폴더를 분석해 맞는 엔진으로 바로 실행합니다.

| 게임 종류 | 내장 엔진 | 비고 |
|---|---|---|
| RPG Maker 2000 / 2003 | **EasyRPG Player** | 한국어 게임은 CP949 인코딩을 자동으로 적용 |
| RPG Maker MV / MZ, TyranoBuilder | **HTML5 러너** (직접 제작) | 게임마다 세이브 저장소 분리 |
| RPG Maker XP / VX / VX Ace | **Winlator** / mkxp-z(선택) | Win32API·DLL 호출 게임은 자동으로 Winlator |
| 울프 RPG, Unity, Ren'Py, 기타 exe | **Winlator** (Wine + Box64) | 일본어 게임은 ja_JP 로케일을 자동으로 적용 |

게임을 누르면 추천 엔진으로 실행합니다. 길게 누르면 다른 엔진, 로케일 선택, 호환성 분석 결과를 볼 수 있습니다.

> JoiPlay는 소스가 공개되지 않아 포함할 수 없습니다. 위 엔진들이 그 역할을 대신합니다.

---

## 1. 빌드

EasyRPG 네이티브 라이브러리 빌드 스크립트가 Linux 전용이라 **Linux 또는 Windows WSL2(Ubuntu)** 가 필요합니다.
Android SDK와 NDK는 스크립트가 자동으로 설치합니다.

**요구 사양**: 디스크 여유 공간 40GB 이상, RAM 8GB 이상, 인터넷 연결. 첫 빌드는 1~2시간 걸립니다(대부분 EasyRPG 의존 라이브러리 빌드). 이후 빌드는 수 분이면 끝납니다.

### Windows라면 먼저 WSL2 설치 (PowerShell 관리자)
```powershell
wsl --install -d Ubuntu
```
재부팅 후 Ubuntu를 열고 아래를 진행하세요. **프로젝트는 WSL 홈(`~/`)에 두세요.** `/mnt/c/...` 위에서는 매우 느립니다.

### Ubuntu / WSL
```bash
sudo apt update && sudo apt install -y git curl unzip zip xz-utils python3 cmake make autoconf automake libtool \
  pkg-config patch perl meson ninja-build build-essential openjdk-17-jdk wget ruby bison xxd gettext glslang-tools zstd

cd ~ && unzip TsukuruBox.zip && cd TsukuruBox
./build.sh
```
결과물은 `dist/TsukuruBox.apk` 에 생깁니다. Windows 탐색기에서는 `\\wsl$\Ubuntu\home\<사용자>\TsukuruBox\dist` 로 열 수 있습니다.

| 옵션 | 설명 |
|---|---|
| `./build.sh --with-mkxp` | mkxp-z 포함 (실험적). XP/VX/VX Ace를 Wine 없이 네이티브로 실행하지만 빌드 실패 가능성이 있습니다 |
| `./build.sh --debug` | 디버그 APK (게임이 느림, 개발용) |

---

## 2. 설치

> ⚠ **Winlator Cmod 또는 Winlator Ludashi가 폰에 설치되어 있으면 먼저 삭제하세요.**
> 이 앱은 패키지명 `com.winlator.cmod` 를 그대로 씁니다. Winlator의 Wine 환경 파일(소리, 폰트 설정 등)에 이 경로가 박혀 있어 바꿀 수 없습니다.
> 공식 Winlator(`com.winlator`), JoiPlay, EasyRPG 앱과는 함께 설치해도 됩니다.

APK를 폰으로 옮겨 설치하거나 `adb install -r dist/TsukuruBox.apk` 로 설치하세요. arm64 기기(최근 폰 대부분)만 지원합니다.

---

## 3. 사용법

첫 실행 시 **모든 파일 접근 권한**을 허용하면 아래 폴더가 만들어집니다.

```
내장 저장소/TsukuruBox/
├── games/        ← 게임 폴더를 통째로 복사 (폴더 하나 = 게임 하나, 하위 2단계까지 인식)
├── rtp/2000/     ← RPG Maker 2000 RTP (필요한 게임만)
├── rtp/2003/     ← RPG Maker 2003 RTP
└── fonts/        ← Winlator용 한글/일본어 ttf·ttc (실행할 때 자동 복사)
```

**Winlator를 처음 쓸 때 한 번만**: exe 게임을 처음 실행하면 Winlator 화면이 열립니다. 거기서 Wine 환경 설치가 끝나면 **컨테이너를 하나 만든 뒤** 런처로 돌아와 게임을 다시 누르세요. 컨테이너 설정(그래픽 드라이버, Box64 프리셋 등)은 런처 메뉴의 **Winlator 설정**에서 바꿀 수 있습니다.

**문제가 생기면**: 런처 오른쪽 위 메뉴 → **진단 (한 번에 점검)**. 권한, 내장 엔진, Wine 환경, 컨테이너 드라이브, 게임별 실행 경로, 최근 오류 로그를 한 화면에 모아 보여 주고 `TsukuruBox/diagnostics.txt` 로도 저장합니다. 원인이 안 보이면 **Wine 로그 켜기** → 문제 게임 한 번 실행 → **다시 점검**.

| 증상 | 해결 |
|---|---|
| Winlator에서 한글이 □□로 나옴 | `TsukuruBox/fonts` 에 나눔고딕 등 한글 ttf를 넣고 다시 실행 |
| 일본어 게임 글자 깨짐 | 게임을 길게 누르고 **Winlator (일본어 로케일)** 선택 |
| Winlator에서 화면이 안 나옴 | Winlator 설정 → 컨테이너 → 그래픽 드라이버 / DX Wrapper 변경 |
| 2000/2003 그래픽 누락 | `rtp/2000` 또는 `rtp/2003` 에 RTP 파일 배치 |
| MV/MZ 게임이 멈춤 | 길게 누르고 Winlator로 실행 (Node.js 전용 플러그인 사용 게임) |

---

## 4. 구조

```
TsukuruBox/
├── build.sh                  원샷 빌드
├── tools/integrate.py        원본 소스를 고정 커밋으로 받아 합치기 좋게 정리
├── launcher/                 런처 + 엔진 판별 + HTML5 러너 (직접 작성)
├── engines/easyrpg/          EasyRPG 를 라이브러리 모듈로 빌드하는 설정
├── engines/mkxp/             mkxp-z 를 라이브러리 모듈로 빌드하는 설정 (선택)
├── overlay/                  Winlator 앱 모듈에 덧씌우는 설정, Winlator 연결 다리
└── deps/              (빌드 시 생성) 원본 소스
```

통합 과정에서 해결한 충돌:
- **패키지 구성**: Winlator를 앱 모듈로 두고 나머지를 라이브러리로 붙였습니다. Winlator 코드가 `switch(R.id…)` 를 써서 라이브러리로 만들 수 없기 때문입니다. 런처 진입점은 매니페스트 오버레이로 교체했습니다.
- **SDL 클래스 충돌**: EasyRPG(SDL3)와 mkxp-z(SDL2)가 둘 다 `org.libsdl.app` 을 씁니다. 그래서 mkxp-z 쪽 SDL2의 Java 패키지와 C 쪽 JNI 이름을 `org.libsdl.app2` 로 바꿨습니다.
- **리소스 이름 충돌**: `AppTheme`, `file_paths` 등 겹치는 이름을 엔진별 접두어로 바꾼 사본을 사용합니다.
- **프로세스 격리**: EasyRPG(`:easyrpg`), mkxp-z(`:mkxp`), HTML5(`:web`)는 각각 별도 프로세스에서 돌아갑니다. mkxp-z는 종료할 때 `System.exit` 를 호출하기 때문입니다.

고정 커밋 (`tools/integrate.py`):
- EasyRPG Player `e68fff4` / buildscripts `84cf2f4`
- Winlator Ludashi `29373dd`
- mkxp-z-android `468fe81`

---

## 5. 현재 상태와 한계

- 엔진 판별 코어, 런처, HTML5 러너, Winlator 연결 코드는 Android API로 컴파일까지 확인했습니다. 통합 스크립트도 실제 원본 소스에 적용해 검증했습니다.
  **하지만 전체 APK 빌드와 실기기 실행은 아직 검증하지 못했습니다.** 빌드 환경(Android SDK 다운로드)이 막힌 곳에서 작성했기 때문입니다. 첫 빌드에서 오류가 나면 로그의 마지막 30줄을 보내 주세요.
- mkxp-z Android 포트는 원작자도 "실험적"이라고 밝힌 상태입니다(2023년 이후 업데이트 없음).
- iOS는 JIT 제한 때문에 지원할 수 없습니다.

## 라이선스

EasyRPG Player(GPLv3), mkxp-z(GPLv2), Winlator(MIT)의 소스를 포함합니다. 개인 사용 목적으로 작성했습니다.
빌드한 APK를 다른 사람에게 배포하려면 GPL에 따라 소스를 함께 공개해야 합니다.
