package io.tsukurubox.bridge;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.winlator.cmod.container.Container;
import com.winlator.cmod.container.ContainerManager;
import com.winlator.cmod.xenvironment.ImageFs;
import com.winlator.cmod.xenvironment.ImageFsInstaller;

import java.io.File;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.tsukurubox.core.GameDetector;
import io.tsukurubox.core.GameInfo;
import io.tsukurubox.core.Runner;

/**
 * 한 번에 점검: 앱·권한·엔진·Winlator 환경·컨테이너 드라이브·게임별 실행 경로·최근 오류 로그를 모아
 * /sdcard/TsukuruBox/diagnostics.txt 로 저장하고 화면에 보여 준다. (복사·공유 버튼)
 */
public class DiagnosticsActivity extends Activity {
    private static final String PREFS = "tsukurubox";
    private static final String KEY_CONTAINER = "wine_container_id";

    private TextView body;
    private Button logToggle;
    private String report = "";
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("쯔꾸르박스 진단");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = new Button(this);
        copy.setText("복사");
        copy.setOnClickListener(v -> copyReport());
        Button share = new Button(this);
        share.setText("공유");
        share.setOnClickListener(v -> shareReport());
        Button again = new Button(this);
        again.setText("다시 점검");
        again.setOnClickListener(v -> runChecks());
        logToggle = new Button(this);
        logToggle.setOnClickListener(v -> toggleWineLog());
        for (Button b : new Button[]{copy, share, again, logToggle}) {
            bar.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(bar);

        body = new TextView(this);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        body.setTextIsSelectable(true);
        int pad = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics());
        body.setPadding(pad, pad, pad, pad);
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.addView(body);
        ScrollView v = new ScrollView(this);
        v.addView(h);
        root.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        updateLogButton();
        runChecks();
    }

    // ─── 점검 ───────────────────────────────────────────────

    private void runChecks() {
        body.setText("점검 중…");
        new Thread(() -> {
            String r;
            try {
                r = buildReport();
            } catch (Throwable t) {
                r = "진단 중 오류: " + t;
            }
            final String text = r;
            File out = new File(Environment.getExternalStorageDirectory(), "TsukuruBox/diagnostics.txt");
            try (PrintWriter w = new PrintWriter(out, "UTF-8")) {
                w.print(text);
            } catch (Exception ignored) {
            }
            ui.post(() -> {
                report = text;
                body.setText(text);
            });
        }).start();
    }

    private String buildReport() {
        StringBuilder b = new StringBuilder();
        File app = new File(Environment.getExternalStorageDirectory(), "TsukuruBox");
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        head(b, "기본 정보");
        b.append("시각        : ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date())).append('\n');
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            b.append("앱          : ").append(getPackageName()).append(" ").append(pi.versionName)
                    .append(" (").append(pi.getLongVersionCode()).append(")\n");
        } catch (Exception ignored) {
        }
        b.append("안드로이드  : ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        b.append("기기        : ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(" / ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        boolean storage = Build.VERSION.SDK_INT >= 30 ? Environment.isExternalStorageManager()
                : checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0;
        b.append(mark(storage)).append("모든 파일 접근 권한\n");

        head(b, "내장 엔진");
        String[][] engines = {
                {"EasyRPG", "org.easyrpg.player.player.EasyRpgPlayerActivity"},
                {"HTML5 러너", "io.tsukurubox.launcher.WebGameActivity"},
                {"Winlator", "com.winlator.cmod.XServerDisplayActivity"},
                {"mkxp-z(선택)", "com.hatkid.mkxpz.MainActivity"},
        };
        for (String[] e : engines) b.append(mark(hasClass(e[1]))).append(e[0]).append('\n');
        File libDir = new File(getApplicationInfo().nativeLibraryDir);
        String[] libs = libDir.list();
        List<String> want = Arrays.asList("libeasyrpg_android.so", "libSDL3.so", "libwinlator.so");
        for (String l : want) b.append(mark(libs != null && Arrays.asList(libs).contains(l))).append(l).append('\n');

        head(b, "쯔꾸르박스 폴더");
        for (String sub : new String[]{"games", "fonts", "rtp/2000", "rtp/2003", "rtp/XP", "rtp/VX", "rtp/VXAce"}) {
            File f = new File(app, sub);
            String[] list = f.list();
            b.append(f.isDirectory() ? "  " : "✘ ").append(pad(sub, 10)).append(list == null ? "없음" : list.length + "개 항목").append('\n');
        }

        head(b, "Winlator 환경");
        ImageFs fs = ImageFs.find(this);
        boolean fsOk = fs.isValid() && fs.getVersion() >= ImageFsInstaller.LATEST_VERSION;
        b.append(mark(fsOk)).append("Wine 환경(imagefs) 설치: ").append(fs.isValid() ? "버전 " + fs.getVersion() : "미설치")
                .append(" / 필요 ").append(ImageFsInstaller.LATEST_VERSION).append('\n');
        File pad = new File(getFilesDir(), "profiles/controls-" + WinlatorBridgeActivity.PAD_PROFILE_ID + ".icp");
        b.append(mark(pad.isFile())).append("가상 패드 프로필 (첫 게임 실행 때 생성)\n");
        boolean wineLog = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("enable_wine_debug", false);
        b.append("  Wine 로그 기록: ").append(wineLog ? "켜짐" : "꺼짐 (오류 원인을 모를 때 위 버튼으로 켜고 게임을 한 번 실행)").append('\n');

        Container selected = null;
        if (fs.isValid()) {
            ContainerManager cm = new ContainerManager(this);
            ArrayList<Container> cs = cm.getContainers();
            b.append(mark(!cs.isEmpty())).append("컨테이너 ").append(cs.size()).append("개\n");
            selected = cm.getContainerById(prefs.getInt(KEY_CONTAINER, -1));
            if (selected == null && !cs.isEmpty()) selected = cs.get(0);
            for (Container c : cs) {
                b.append("  [").append(c.id).append("] ").append(c.getName()).append(" · ").append(c.getWineVersion())
                        .append(c == selected ? "  ← 게임 실행에 사용" : "").append('\n');
                for (String[] d : c.drivesIterator()) {
                    File root = new File(d[1]);
                    b.append("      ").append(mark(root.isDirectory() && root.canRead())).append(d[0]).append(": → ")
                            .append(d[1]).append('\n');
                }
                File dos = new File(c.getRootDir(), ".wine/dosdevices");
                String[] links = dos.list();
                b.append("      dosdevices: ").append(links == null ? "없음(아직 한 번도 실행 안 함)" : String.join(" ", sorted(links))).append('\n');
            }
        }

        head(b, "게임별 점검");
        String rootPath = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString("games_root", new File(app, "games").getAbsolutePath());
        List<GameInfo> games = GameDetector.scan(new File(rootPath), 2);
        b.append("게임 폴더: ").append(rootPath).append(" · ").append(games.size()).append("개\n");
        boolean mkxp = hasClass("com.hatkid.mkxpz.MainActivity");
        for (GameInfo g : games) {
            List<Runner> rs = g.runners(mkxp);
            b.append("\n■ ").append(g.title).append("  [").append(g.engine.displayName).append("]\n");
            b.append("  폴더  : ").append(g.dir.getAbsolutePath()).append('\n');
            b.append("  실행  : ").append(rs.isEmpty() ? "✘ 실행 가능한 엔진 없음" : rs.get(0).label).append('\n');
            if (g.exe != null) {
                b.append("  exe   : ").append(g.exe.getName()).append(g.exe.canRead() ? "" : "  ✘ 읽을 수 없음").append('\n');
                if (selected != null) {
                    String win = WinlatorBridgeActivity.toWindowsPath(selected, g.exe);
                    boolean ok = resolvesBack(selected, win, g.exe);
                    b.append("  Wine  : ").append(mark(ok)).append(win);
                    if (!ok) b.append("  ← 이 드라이브로는 파일이 안 보임 (실행 시 자동 연결됨)");
                    b.append('\n');
                    if (g.exe.getAbsolutePath().contains("\"")) b.append("  ✘ 경로에 따옴표(\")가 있어 실행 불가 → 폴더 이름 변경\n");
                }
            }
            for (GameInfo.Issue i : g.issues) b.append("  (").append(i.level).append(") ").append(i.message).append('\n');
            for (String n : g.notes) b.append("  · ").append(n).append('\n');
        }

        head(b, "최근 실행 기록 (last_launch.txt)");
        b.append(tail(new File(app, "last_launch.txt"), 20));

        head(b, "최근 앱 오류 (crash.txt)");
        b.append(tail(new File(app, "crash.txt"), 40));

        head(b, "최근 Wine 로그");
        File newest = newestFile(wineLogDir());
        b.append(newest == null ? "(없음)\n" : newest.getName() + "\n" + tailFiltered(newest, 60));

        head(b, "최근 EasyRPG 로그");
        File erpg = new File(getExternalFilesDir(null), "easyrpg/easyrpg-player.log");
        b.append(tail(erpg, 40));

        b.append("\n저장 위치: ").append(new File(app, "diagnostics.txt").getAbsolutePath()).append('\n');
        return b.toString();
    }

    /** Windows 경로의 드라이브 글자를 컨테이너 설정으로 되돌려 실제 파일이 보이는지 확인 */
    private static boolean resolvesBack(Container c, String win, File expected) {
        if (win.length() < 3 || win.charAt(1) != ':') return false;
        String letter = win.substring(0, 1).toUpperCase(Locale.ROOT);
        for (String[] d : c.drivesIterator()) {
            if (d[0].replace(":", "").trim().equalsIgnoreCase(letter)) {
                File f = new File(d[1].replaceAll("/+$", "") + win.substring(2).replace('\\', '/'));
                return f.getAbsolutePath().equals(expected.getAbsolutePath()) && f.isFile();
            }
        }
        return false;
    }

    // ─── 버튼 ───────────────────────────────────────────────

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        String text = report.length() > 60000 ? report.substring(0, 60000) : report;
        cm.setPrimaryClip(ClipData.newPlainText("쯔꾸르박스 진단", text));
        Toast.makeText(this, "복사했습니다", Toast.LENGTH_SHORT).show();
    }

    private void shareReport() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, report.length() > 60000 ? report.substring(0, 60000) : report);
        startActivity(Intent.createChooser(i, "진단 결과 공유"));
    }

    @SuppressWarnings("deprecation")
    private void toggleWineLog() {
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(this);
        boolean on = !p.getBoolean("enable_wine_debug", false);
        p.edit().putBoolean("enable_wine_debug", on).apply();
        updateLogButton();
        Toast.makeText(this, on ? "Wine 로그를 켰습니다. 문제 게임을 한 번 실행한 뒤 '다시 점검'을 누르세요."
                : "Wine 로그를 껐습니다.", Toast.LENGTH_LONG).show();
    }

    @SuppressWarnings("deprecation")
    private void updateLogButton() {
        boolean on = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("enable_wine_debug", false);
        logToggle.setText(on ? "Wine 로그 끄기" : "Wine 로그 켜기");
    }

    // ─── 유틸 ───────────────────────────────────────────────

    private static void head(StringBuilder b, String t) {
        b.append("\n===== ").append(t).append(" =====\n");
    }

    private static String mark(boolean ok) {
        return ok ? "✔ " : "✘ ";
    }

    private static String pad(String s, int n) {
        StringBuilder b = new StringBuilder(s);
        while (b.length() < n) b.append(' ');
        return b.toString();
    }

    private static List<String> sorted(String[] a) {
        List<String> l = new ArrayList<>(Arrays.asList(a));
        java.util.Collections.sort(l);
        return l;
    }

    private boolean hasClass(String name) {
        try {
            Class.forName(name, false, getClassLoader());
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private File wineLogDir() {
        return new File(Environment.getExternalStorageDirectory(), "Winlator/logs");
    }

    private static File newestFile(File dir) {
        File[] fs = dir.listFiles(File::isFile);
        if (fs == null || fs.length == 0) return null;
        File best = fs[0];
        for (File f : fs) if (f.lastModified() > best.lastModified()) best = f;
        return best;
    }

    /** 파일 끝 부분만 읽기 (최대 64KB) */
    private static List<String> lastLines(File f, int n) {
        List<String> out = new ArrayList<>();
        if (f == null || !f.isFile()) return out;
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long len = r.length();
            long start = Math.max(0, len - 64 * 1024);
            byte[] buf = new byte[(int) (len - start)];
            r.seek(start);
            r.readFully(buf);
            String[] lines = new String(buf, StandardCharsets.UTF_8).split("\r?\n");
            for (int i = Math.max(0, lines.length - n); i < lines.length; i++) out.add(lines[i]);
        } catch (Exception ignored) {
        }
        return out;
    }

    private static String tail(File f, int n) {
        List<String> l = lastLines(f, n);
        return l.isEmpty() ? "(없음)\n" : String.join("\n", l) + "\n";
    }

    /** Wine 로그는 양이 많아서 오류·경고 줄 위주로 */
    private static String tailFiltered(File f, int n) {
        List<String> all = lastLines(f, 2000);
        List<String> hit = new ArrayList<>();
        for (String s : all) {
            String l = s.toLowerCase(Locale.ROOT);
            if (l.contains("err") || l.contains("not found") || l.contains("cannot") || l.contains("failed")
                    || l.contains("exception") || l.contains("fixme:") && hit.size() < n / 3) hit.add(s);
        }
        List<String> use = hit.isEmpty() ? all : hit;
        List<String> last = use.subList(Math.max(0, use.size() - n), use.size());
        return last.isEmpty() ? "(내용 없음)\n" : String.join("\n", last) + "\n";
    }
}
