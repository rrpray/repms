package io.tsukurubox.bridge;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.winlator.cmod.container.Container;
import com.winlator.cmod.container.ContainerManager;
import com.winlator.cmod.core.WineRegistryEditor;
import com.winlator.cmod.xenvironment.ImageFs;
import com.winlator.cmod.xenvironment.ImageFsInstaller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 쯔꾸르박스 런처 → Winlator 연결 다리.
 * Winlator 파일 관리자의 "바로 실행"(FileManagerFragment.runFileDirectly)과 같은 형식의 .desktop 을 만들어
 * XServerDisplayActivity 로 넘긴다. Winlator 모듈 안에서 컴파일되므로 내부 클래스를 직접 사용한다.
 */
public class WinlatorBridgeActivity extends Activity {
    private static final String TAG = "TsukuruBridge";
    private static final String PREFS = "tsukurubox";
    private static final String KEY_CONTAINER = "wine_container_id";

    /** 쯔꾸르용 가상 패드 프로필 ID (Winlator 프로필 폴더의 controls-<ID>.icp) */
    static final int PAD_PROFILE_ID = 9100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            run();
        } catch (Exception e) {
            Log.e(TAG, "launch failed", e);
            Toast.makeText(this, "Winlator 실행 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        finish();
    }

    private void run() throws Exception {
        String exePath = getIntent().getStringExtra("exe_path");
        String title = clean(getIntent().getStringExtra("title"));
        String lcAll = getIntent().getStringExtra("lc_all");
        if (exePath == null || !new File(exePath).isFile()) {
            Toast.makeText(this, "실행 파일을 찾을 수 없습니다", Toast.LENGTH_LONG).show();
            return;
        }
        // .desktop 파일 형식을 깨뜨리거나 Wine 명령에 인자를 끼워 넣을 수 있는 문자는 거부
        if (!exePath.toLowerCase(Locale.ROOT).endsWith(".exe") || exePath.matches(".*[\"\\p{Cntrl}].*")) {
            Toast.makeText(this, "경로에 사용할 수 없는 문자(\" 또는 제어문자)가 있습니다. 게임 폴더 이름을 바꿔 주세요.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (lcAll == null || !lcAll.matches("[A-Za-z_]{2,8}\\.UTF-8")) lcAll = "ko_KR.UTF-8";
        boolean virtualPad = getIntent().getBooleanExtra("virtual_pad", true);
        if (virtualPad) installPadProfile();

        // 1) Wine 환경(imagefs) 설치 여부
        ImageFs imageFs = ImageFs.find(this);
        if (!imageFs.isValid() || imageFs.getVersion() < ImageFsInstaller.LATEST_VERSION) {
            Toast.makeText(this, "처음 한 번 Wine 환경 설치가 필요합니다.\n설치와 컨테이너 생성 후 게임을 다시 실행하세요.",
                    Toast.LENGTH_LONG).show();
            openWinlator();
            return;
        }

        // 2) 컨테이너 선택 (마지막으로 쓴 것 → 첫 번째)
        ContainerManager cm = new ContainerManager(this);
        ArrayList<Container> containers = cm.getContainers();
        if (containers.isEmpty()) {
            Toast.makeText(this, "Winlator 컨테이너가 없습니다. 컨테이너를 하나 만든 뒤 다시 실행하세요.",
                    Toast.LENGTH_LONG).show();
            openWinlator();
            return;
        }
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Container container = cm.getContainerById(prefs.getInt(KEY_CONTAINER, -1));
        if (container == null) container = containers.get(0);
        prefs.edit().putInt(KEY_CONTAINER, container.id).apply();

        // 3) 한글/일본어 폰트 자동 복사: /sdcard/TsukuruBox/fonts/*.ttf|ttc|otf → C:\windows\Fonts
        copyUserFonts(container);
        registerRgssRtp(container);

        // 4) runFileDirectly 와 동일한 형식의 임시 바로가기
        File exe = new File(exePath);
        // Winlator 는 바로가기 파일 이름으로 로딩 화면 그림(Winlator/banners/<이름>.png)을 저장·재사용하므로
        // 게임마다 다른 이름을 써야 그림이 섞이지 않는다
        File shortcutDir = new File(getCacheDir(), "tsukuru");
        //noinspection ResultOfMethodCallIgnored
        shortcutDir.mkdirs();
        String base = (title != null ? title : exe.getName()).replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        if (base.length() > 40) base = base.substring(0, 40);
        String id = Integer.toHexString(exe.getAbsolutePath().hashCode());
        File shortcut = new File(shortcutDir, base + "_" + id + ".desktop");
        String wineHome = containerWineHome(container);
        try (PrintWriter w = new PrintWriter(shortcut, "UTF-8")) {
            w.println("[Desktop Entry]");
            w.println("Name=" + (title != null ? title : exe.getName()));
            // Windows 경로(F:\...)로 넘겨야 Winlator 가 "start /dir <폴더>" 를 올바르게 만든다.
            // (리눅스 경로를 넘기면 /dir 이 C:\storage\... 로 해석되어 "File not found")
            // Winlator 의 .desktop 파서(StringUtils.unescape)가 역슬래시를 두 번 벗겨내므로 4개로 기록한다.
            String winPath = toWindowsPath(container, exe);
            w.println("Exec=env WINEPREFIX=\"" + wineHome + "/.wine\" wine \""
                    + winPath.replace("\\", "\\\\\\\\") + "\"");
            w.println("Type=Application");
            w.println("container_id:" + container.id);
            w.println();
            w.println("[Extra Data]");
            w.println("lc_all=" + lcAll);
            if (virtualPad) {
                // 화면에 방향키·결정·취소 버튼을 띄우고, 화면 터치는 마우스 커서 이동 대신 그 위치를 바로 클릭
                w.println("controlsProfile=" + PAD_PROFILE_ID);
                w.println("simTouchScreen=1");
            }
        }

        Intent i = new Intent();
        i.setClassName(getPackageName(), "com.winlator.cmod.XServerDisplayActivity");
        i.putExtra("container_id", container.id);
        i.putExtra("shortcut_path", shortcut.getAbsolutePath());
        i.putExtra("shortcut_name", title != null ? title : exe.getName());
        startActivity(i);
    }

    /** 게임 파일에서 온 제목: 줄바꿈 등 제어문자 제거 (.desktop 에 새 항목을 끼워 넣지 못하게) */
    private static String clean(String t) {
        if (t == null) return null;
        String c = t.replaceAll("[\\p{Cntrl}\\p{Cf}=\\[\\]]", " ").trim();
        if (c.length() > 80) c = c.substring(0, 80);
        return c.isEmpty() ? null : c;
    }

    /**
     * 쯔꾸르 게임 조작용 가상 패드를 Winlator 프로필 폴더에 설치 (없을 때만 → 사용자가 Winlator 에서 고친 배치는 유지).
     * RPG Maker 2000~VX Ace·울프 RPG 공통 키: 방향키, Z(결정), X(취소/메뉴), Shift(달리기), Esc(메뉴), Enter, Q/W(페이지)
     */
    private void installPadProfile() {
        File dir = new File(getFilesDir(), "profiles");
        File file = new File(dir, "controls-" + PAD_PROFILE_ID + ".icp");
        if (file.isFile()) return;
        try {
            JSONArray el = new JSONArray();
            el.put(element("D_PAD", "CIRCLE", 0.13, 0.70, 1.5, "",
                    "KEY_UP", "KEY_RIGHT", "KEY_DOWN", "KEY_LEFT"));
            el.put(element("BUTTON", "CIRCLE", 0.91, 0.70, 1.3, "결정", "KEY_Z"));
            el.put(element("BUTTON", "CIRCLE", 0.79, 0.84, 1.3, "취소", "KEY_X"));
            el.put(element("BUTTON", "CIRCLE", 0.79, 0.56, 1.0, "달리기", "KEY_SHIFT_L"));
            el.put(element("BUTTON", "ROUND_RECT", 0.93, 0.10, 0.9, "메뉴", "KEY_ESC"));
            el.put(element("BUTTON", "ROUND_RECT", 0.82, 0.10, 0.9, "Enter", "KEY_ENTER"));
            el.put(element("BUTTON", "ROUND_RECT", 0.06, 0.10, 0.8, "Q", "KEY_Q"));
            el.put(element("BUTTON", "ROUND_RECT", 0.14, 0.10, 0.8, "W", "KEY_W"));
            JSONObject profile = new JSONObject();
            profile.put("id", PAD_PROFILE_ID);
            profile.put("name", "쯔꾸르 (방향키 + 결정/취소)");
            profile.put("cursorSpeed", 1.0);
            profile.put("elements", el);
            if (!dir.isDirectory() && !dir.mkdirs()) return;
            try (PrintWriter w = new PrintWriter(file, "UTF-8")) {
                w.print(profile.toString(2));
            }
        } catch (Exception e) {
            Log.w(TAG, "pad profile install failed", e);
        }
    }

    private static JSONObject element(String type, String shape, double x, double y, double scale,
                                      String text, String... keys) throws Exception {
        JSONArray b = new JSONArray();
        for (int i = 0; i < 4; i++) b.put(i < keys.length ? keys[i] : "NONE");
        JSONObject o = new JSONObject();
        o.put("type", type);
        o.put("shape", shape);
        o.put("bindings", b);
        o.put("scale", scale);
        o.put("x", x);
        o.put("y", y);
        o.put("toggleSwitch", false);
        o.put("text", text);
        o.put("iconId", 0);
        return o;
    }

    private void openWinlator() {
        Intent i = new Intent();
        i.setClassName(getPackageName(), "com.winlator.cmod.MainActivity");
        startActivity(i);
    }

    /**
     * 안드로이드 경로 → 컨테이너 드라이브 기준 Windows 경로.
     * 기본 컨테이너는 F: = 내장 저장소, D: = Download. 해당 드라이브가 없으면 Wine 기본 Z:(= /) 사용.
     */
    static String toWindowsPath(Container container, File file) {
        String path = file.getAbsolutePath();
        String bestLetter = null;
        String bestRoot = null;
        for (String[] drive : container.drivesIterator()) {
            if (drive == null || drive.length < 2 || drive[0] == null || drive[1] == null) continue;
            String root = drive[1].replaceAll("/+$", "");
            if (root.isEmpty()) continue;
            if ((path.equals(root) || path.startsWith(root + "/"))
                    && (bestRoot == null || root.length() > bestRoot.length())) {
                bestLetter = drive[0].replace(":", "").trim().toUpperCase(Locale.ROOT);
                bestRoot = root;
            }
        }
        if (bestLetter != null && bestLetter.length() == 1) {
            String rel = path.substring(bestRoot.length()).replace('/', '\\');
            if (!rel.startsWith("\\")) rel = "\\" + rel;
            return bestLetter + ":" + rel;
        }
        return "Z:" + path.replace('/', '\\');
    }

    /** FileManagerFragment.getContainerWineHome 과 같은 계산 */
    private String containerWineHome(Container container) {
        String imagefs = new File(getFilesDir(), "imagefs").getAbsolutePath();
        String root = container.getRootDir().getAbsolutePath();
        return root.startsWith(imagefs) ? root.substring(imagefs.length()) : "/home/" + ImageFs.USER;
    }

    /**
     * RPG Maker XP/VX/VX Ace 게임 중 RTP 를 따로 설치해야 하는 게임은, Windows 레지스트리에서 RTP 위치를 찾는다.
     * /sdcard/TsukuruBox/rtp/XP|VX|VXAce 에 RTP 가 있으면 컨테이너 레지스트리에 그 위치를 등록한다.
     */
    private void registerRgssRtp(Container container) {
        String[][] rtps = {
                {"XP", "Enterbrain\\RGSS\\RTP", "Standard"},
                {"VX", "Enterbrain\\RGSS2\\RTP", "RPGVX"},
                {"VXAce", "Enterbrain\\RGSS3\\RTP", "RPGVXAce"},
        };
        File rtpRoot = new File(Environment.getExternalStorageDirectory(), "TsukuruBox/rtp");
        File systemReg = new File(container.getRootDir(), ".wine/system.reg");
        if (!systemReg.isFile()) return;
        try (WineRegistryEditor reg = new WineRegistryEditor(systemReg)) {
            reg.setCreateKeyIfNotExist(true);
            for (String[] r : rtps) {
                File dir = new File(rtpRoot, r[0]);
                String[] files = dir.list();
                if (files == null || files.length == 0) continue;
                String winDir = toWindowsPath(container, dir);
                // 32비트 Game.exe 는 Wow6432Node 쪽을 읽으므로 양쪽 모두 등록
                reg.setStringValue("Software\\Wow6432Node\\" + r[1], r[2], winDir);
                reg.setStringValue("Software\\" + r[1], r[2], winDir);
            }
        } catch (Exception e) {
            Log.w(TAG, "RTP registry update failed", e);
        }
    }

    private void copyUserFonts(Container container) {
        File src = new File(Environment.getExternalStorageDirectory(), "TsukuruBox/fonts");
        File[] fonts = src.listFiles((d, n) -> {
            String l = n.toLowerCase(Locale.ROOT);
            return l.endsWith(".ttf") || l.endsWith(".ttc") || l.endsWith(".otf");
        });
        if (fonts == null || fonts.length == 0) return;
        File dst = new File(container.getRootDir(), ".wine/drive_c/windows/Fonts");
        if (!dst.isDirectory() && !dst.mkdirs()) return;
        byte[] buf = new byte[64 * 1024];
        for (File f : fonts) {
            File out = new File(dst, f.getName());
            if (out.isFile() && out.length() == f.length()) continue;
            try (InputStream in = new FileInputStream(f); OutputStream os = new FileOutputStream(out)) {
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            } catch (Exception e) {
                Log.w(TAG, "font copy failed: " + f, e);
            }
        }
    }
}
