package io.tsukurubox.bridge;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.winlator.cmod.container.Container;
import com.winlator.cmod.container.ContainerManager;
import com.winlator.cmod.xenvironment.ImageFs;
import com.winlator.cmod.xenvironment.ImageFsInstaller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;

/**
 * 쯔꾸르박스 런처 → Winlator 연결 다리.
 * Winlator 파일 관리자의 "바로 실행"(FileManagerFragment.runFileDirectly)과 같은 형식의 .desktop 을 만들어
 * XServerDisplayActivity 로 넘긴다. Winlator 모듈 안에서 컴파일되므로 내부 클래스를 직접 사용한다.
 */
public class WinlatorBridgeActivity extends Activity {
    private static final String TAG = "TsukuruBridge";
    private static final String PREFS = "tsukurubox";
    private static final String KEY_CONTAINER = "wine_container_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            run();
        } catch (Exception e) {
            Log.e(TAG, "launch failed", e);
            Toast.makeText(this, "Winlator 실행 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        finish();
    }

    private void run() throws Exception {
        String exePath = getIntent().getStringExtra("exe_path");
        String title = getIntent().getStringExtra("title");
        String lcAll = getIntent().getStringExtra("lc_all");
        if (exePath == null || !new File(exePath).isFile()) {
            Toast.makeText(this, "실행 파일을 찾을 수 없습니다", Toast.LENGTH_LONG).show();
            return;
        }

        // 1) Wine 환경(imagefs) 설치 여부
        ImageFs imageFs = ImageFs.find(this);
        if (!imageFs.isValid() || imageFs.getVersion() < ImageFsInstaller.LATEST_VERSION) {
            Toast.makeText(this, "처음 한 번 Wine 환경 설치가 필요합니다.\n설치와 컨테이너 생성 후 게임을 다시 실행하세요.",
                    Toast.LENGTH_LONG).show();
            openWinlator();
            return;
        }

        // 2) 컨테이너 선택 (마지막으로 쓴 것 → 첫 번째)
        ContainerManager cm = new ContainerManager(this);
        ArrayList<Container> containers = cm.getContainers();
        if (containers.isEmpty()) {
            Toast.makeText(this, "Winlator 컨테이너가 없습니다. 컨테이너를 하나 만든 뒤 다시 실행하세요.",
                    Toast.LENGTH_LONG).show();
            openWinlator();
            return;
        }
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Container container = cm.getContainerById(prefs.getInt(KEY_CONTAINER, -1));
        if (container == null) container = containers.get(0);
        prefs.edit().putInt(KEY_CONTAINER, container.id).apply();

        // 3) 한글/일본어 폰트 자동 복사: /sdcard/TsukuruBox/fonts/*.ttf|ttc|otf → C:\windows\Fonts
        copyUserFonts(container);

        // 4) runFileDirectly 와 동일한 형식의 임시 바로가기
        File exe = new File(exePath);
        File shortcut = new File(getCacheDir(), "tsukuru_run.desktop");
        String wineHome = containerWineHome(container);
        try (PrintWriter w = new PrintWriter(shortcut, "UTF-8")) {
            w.println("[Desktop Entry]");
            w.println("Name=" + (title != null ? title.replace('\n', ' ') : exe.getName()));
            w.println("Exec=env WINEPREFIX=\"" + wineHome + "/.wine\" wine \"" + exe.getAbsolutePath() + "\"");
            w.println("Type=Application");
            w.println("container_id:" + container.id);
            if (lcAll != null && !lcAll.isEmpty()) {
                w.println();
                w.println("[Extra Data]");
                w.println("lc_all=" + lcAll);
            }
        }

        Intent i = new Intent();
        i.setClassName(getPackageName(), "com.winlator.cmod.XServerDisplayActivity");
        i.putExtra("container_id", container.id);
        i.putExtra("shortcut_path", shortcut.getAbsolutePath());
        i.putExtra("shortcut_name", title != null ? title : exe.getName());
        startActivity(i);
    }

    private void openWinlator() {
        Intent i = new Intent();
        i.setClassName(getPackageName(), "com.winlator.cmod.MainActivity");
        startActivity(i);
    }

    /** FileManagerFragment.getContainerWineHome 과 같은 계산 */
    private String containerWineHome(Container container) {
        String imagefs = new File(getFilesDir(), "imagefs").getAbsolutePath();
        String root = container.getRootDir().getAbsolutePath();
        return root.startsWith(imagefs) ? root.substring(imagefs.length()) : "/home/" + ImageFs.USER;
    }

    private void copyUserFonts(Container container) {
        File src = new File(Environment.getExternalStorageDirectory(), "TsukuruBox/fonts");
        File[] fonts = src.listFiles((d, n) -> {
            String l = n.toLowerCase(Locale.ROOT);
            return l.endsWith(".ttf") || l.endsWith(".ttc") || l.endsWith(".otf");
        });
        if (fonts == null || fonts.length == 0) return;
        File dst = new File(container.getRootDir(), ".wine/drive_c/windows/Fonts");
        if (!dst.isDirectory() && !dst.mkdirs()) return;
        byte[] buf = new byte[64 * 1024];
        for (File f : fonts) {
            File out = new File(dst, f.getName());
            if (out.isFile() && out.length() == f.length()) continue;
            try (InputStream in = new FileInputStream(f); OutputStream os = new FileOutputStream(out)) {
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            } catch (Exception e) {
                Log.w(TAG, "font copy failed: " + f, e);
            }
        }
    }
}
