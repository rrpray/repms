package io.tsukurubox.bridge;

import android.content.Context;

import com.winlator.cmod.container.Container;
import com.winlator.cmod.xenvironment.ImageFs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * "not found" 원인 추적용 도구 모음.
 * 1) exe 헤더 분석: 32/64비트, 필요한 DLL 목록과 각각을 찾을 수 있는지
 * 2) Wine 안에서 실행 테스트: C:\tsukurubox\test.bat 을 만들어 Wine 이 실제로 보는 드라이브·폴더·실행 결과를
 *    C:\tsukurubox\wine_test.txt 에 기록 (ShellExecute 오류 창 대신 글로 남김)
 */
final class WineProbe {
    private WineProbe() {}

    static final String TEST_DIR = "tsukurubox";
    static final String TEST_OUT = "wine_test.txt";

    // ─── exe 분석 ────────────────────────────────────────────

    static final class PeInfo {
        String error;
        int machine;
        boolean pe32Plus;
        int subsystem;
        boolean dotNet;
        final List<String> imports = new ArrayList<>();

        boolean is32() {
            return machine == 0x14c;
        }

        String describe() {
            if (error != null) return "✘ " + error;
            String arch = machine == 0x14c ? "32비트(x86)" : machine == 0x8664 ? "64비트(x64)"
                    : machine == 0xaa64 ? "ARM64" : String.format(Locale.ROOT, "알 수 없음(0x%x)", machine);
            String sub = subsystem == 2 ? "창 프로그램" : subsystem == 3 ? "콘솔 프로그램" : "subsystem " + subsystem;
            return arch + " · " + sub + (dotNet ? " · .NET (Wine Mono 필요)" : "");
        }
    }

    static PeInfo readPe(File exe) {
        PeInfo p = new PeInfo();
        try (RandomAccessFile r = new RandomAccessFile(exe, "r")) {
            if (r.length() < 64 || u16(r, 0) != 0x5A4D) { p.error = "Windows 실행 파일이 아님 (MZ 헤더 없음)"; return p; }
            long pe = u32(r, 0x3c);
            if (pe <= 0 || pe > r.length() - 24 || u32(r, pe) != 0x00004550) {
                p.error = "16비트 DOS/Windows 3.x 프로그램 (Wine 에서 실행 불가)";
                return p;
            }
            p.machine = u16(r, pe + 4);
            int nsec = u16(r, pe + 6);
            int optSize = u16(r, pe + 20);
            long opt = pe + 24;
            p.pe32Plus = u16(r, opt) == 0x20b;
            p.subsystem = u16(r, opt + 68);
            long dd = opt + (p.pe32Plus ? 112 : 96);
            long impRva = u32(r, dd + 8);
            long clrRva = u32(r, dd + 14 * 8);
            p.dotNet = clrRva != 0;
            long secTab = opt + optSize;
            long[][] secs = new long[Math.min(nsec, 96)][];
            for (int i = 0; i < secs.length; i++) {
                long s = secTab + i * 40L;
                long vsize = u32(r, s + 8), va = u32(r, s + 12), rawSize = u32(r, s + 16), raw = u32(r, s + 20);
                secs[i] = new long[]{va, Math.max(vsize, rawSize), raw};
            }
            if (impRva == 0) return p;
            long imp = rvaToOff(secs, impRva);
            for (int i = 0; imp > 0 && i < 256; i++) {
                long d = imp + i * 20L;
                if (d + 20 > r.length()) break;
                long nameRva = u32(r, d + 12);
                if (nameRva == 0 && u32(r, d) == 0 && u32(r, d + 16) == 0) break;
                long nameOff = rvaToOff(secs, nameRva);
                if (nameOff <= 0) continue;
                String n = cstr(r, nameOff);
                if (!n.isEmpty()) p.imports.add(n);
            }
        } catch (Exception e) {
            p.error = "읽기 실패: " + e.getMessage();
        }
        return p;
    }

    /** 가져오는 DLL 마다 어디서 찾았는지. 못 찾으면 ✘ */
    static String checkImports(Context ctx, Container c, File gameDir, PeInfo p) {
        StringBuilder b = new StringBuilder();
        Set<String> local = lowerNames(gameDir);
        File win = new File(c.getRootDir(), ".wine/drive_c/windows");
        Set<String> sys = lowerNames(new File(win, p.is32() ? "syswow64" : "system32"));
        Set<String> builtin = new HashSet<>();
        for (File d : wineDllDirs(ctx)) {
            String dn = d.getName();
            if (p.is32() ? dn.startsWith("i386") : !dn.startsWith("i386")) builtin.addAll(lowerNames(d));
        }
        int missing = 0;
        for (String dll : p.imports) {
            String l = dll.toLowerCase(Locale.ROOT);
            String where;
            if (local.contains(l)) where = "게임 폴더";
            else if (sys.contains(l)) where = p.is32() ? "syswow64" : "system32";
            else if (builtin.contains(l)) where = "Wine 내장";
            else if (l.startsWith("api-ms-win-") || l.startsWith("ext-ms-")) where = "Wine 내장(API set)";
            else where = null;
            if (where == null) missing++;
            b.append("      ").append(where != null ? "✔ " : "✘ ").append(dll)
                    .append(where != null ? "  (" + where + ")" : "  ← 찾을 수 없음").append('\n');
        }
        if (missing > 0) {
            b.append("      → 위 ✘ DLL 이 없으면 Wine 이 \"not found\" 오류를 냅니다. 게임 배포처의 런타임(DirectX, VC++ 등)이나\n")
             .append("        해당 DLL 을 게임 폴더에 넣어야 합니다.\n");
        }
        return b.toString();
    }

    private static List<File> wineDllDirs(Context ctx) {
        List<File> out = new ArrayList<>();
        File opt = new File(ImageFs.find(ctx).getRootDir(), "opt");
        File[] wines = opt.listFiles(File::isDirectory);
        if (wines == null) return out;
        for (File w : wines) {
            File[] arch = new File(w, "lib/wine").listFiles(f -> f.isDirectory() && f.getName().endsWith("-windows"));
            if (arch != null) out.addAll(Arrays.asList(arch));
        }
        return out;
    }

    private static Set<String> lowerNames(File dir) {
        Set<String> s = new HashSet<>();
        String[] l = dir.list();
        if (l != null) for (String n : l) s.add(n.toLowerCase(Locale.ROOT));
        return s;
    }

    /** 게임 폴더 최상위 목록 (폴더는 / 표시) */
    static String listDir(File dir, int max) {
        File[] fs = dir.listFiles();
        if (fs == null) return "      (읽을 수 없음)\n";
        Arrays.sort(fs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        StringBuilder b = new StringBuilder("      ");
        int col = 6;
        for (int i = 0; i < fs.length && i < max; i++) {
            String n = fs[i].getName() + (fs[i].isDirectory() ? "/" : "");
            if (col + n.length() > 90) { b.append("\n      "); col = 6; }
            b.append(n).append("  ");
            col += n.length() + 2;
        }
        if (fs.length > max) b.append("… 외 ").append(fs.length - max).append("개");
        return b.append('\n').toString();
    }

    private static long rvaToOff(long[][] secs, long rva) {
        for (long[] s : secs) if (s != null && rva >= s[0] && rva < s[0] + s[1]) return rva - s[0] + s[2];
        return -1;
    }

    private static int u16(RandomAccessFile r, long off) throws Exception {
        r.seek(off);
        return r.read() | (r.read() << 8);
    }

    private static long u32(RandomAccessFile r, long off) throws Exception {
        r.seek(off);
        return (r.read() | (r.read() << 8) | (r.read() << 16) | ((long) r.read() << 24)) & 0xffffffffL;
    }

    private static String cstr(RandomAccessFile r, long off) throws Exception {
        r.seek(off);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            int ch = r.read();
            if (ch <= 0) break;
            if (ch < 0x20 || ch > 0x7e) return "";
            b.append((char) ch);
        }
        return b.toString();
    }

    // ─── Wine 안에서 실행 테스트 ─────────────────────────────

    static File testDir(Container c) {
        return new File(c.getRootDir(), ".wine/drive_c/" + TEST_DIR);
    }

    static Charset batchCharset(String lcAll) {
        String[] names = lcAll != null && lcAll.startsWith("ja")
                ? new String[]{"Shift_JIS", "windows-31j"}
                : new String[]{"x-windows-949", "MS949", "windows-949", "EUC-KR"};
        for (String n : names) {
            try {
                if (Charset.isSupported(n)) return Charset.forName(n);
            } catch (Exception ignored) {
            }
        }
        return Charset.forName("US-ASCII");
    }

    /**
     * test.bat 과 이를 실행할 .desktop 을 만든다. 반환값: .desktop 파일
     * bat 은 C: 에 두므로 게임 드라이브가 Wine 에서 안 보여도 bat 자체는 실행된다.
     */
    static File prepareTest(Context ctx, Container c, File exe, String lcAll) throws Exception {
        File dir = testDir(c);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new Exception("C:\\" + TEST_DIR + " 폴더를 만들 수 없음");
        //noinspection ResultOfMethodCallIgnored
        new File(dir, TEST_OUT).delete();

        String winExe = WinlatorBridgeActivity.toWindowsPath(c, exe);
        String winDir = winExe.substring(0, winExe.lastIndexOf('\\'));
        if (winDir.length() == 2) winDir += "\\";
        String out = "C:\\" + TEST_DIR + "\\" + TEST_OUT;

        StringBuilder s = new StringBuilder();
        s.append("@echo off\r\n");
        s.append("set OUT=").append(out).append("\r\n");
        s.append("echo [1] cmd started (ShellExecute OK) > \"%OUT%\"\r\n");
        s.append("ver >> \"%OUT%\" 2>&1\r\n");
        s.append("echo arch=%PROCESSOR_ARCHITECTURE% wow=%PROCESSOR_ARCHITEW6432% >> \"%OUT%\"\r\n");
        s.append("echo [2] drives visible in Wine >> \"%OUT%\"\r\n");
        s.append("for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do dir %%d:\\ >nul 2>&1 && echo   %%d: >> \"%OUT%\"\r\n");
        s.append("echo [3] dir \"").append(winDir).append("\" >> \"%OUT%\"\r\n");
        s.append("dir \"").append(winDir).append("\" >> \"%OUT%\" 2>&1\r\n");
        s.append("echo [4] exe check >> \"%OUT%\"\r\n");
        s.append("if exist \"").append(winExe).append("\" (echo   exe VISIBLE >> \"%OUT%\") else (echo   exe NOT VISIBLE >> \"%OUT%\")\r\n");
        s.append("cd /d \"").append(winDir).append("\" >> \"%OUT%\" 2>&1\r\n");
        s.append("echo   cwd=%CD% >> \"%OUT%\"\r\n");
        s.append("echo [5] start /wait \"").append(exe.getName()).append("\" >> \"%OUT%\"\r\n");
        s.append("start \"\" /wait \"").append(winExe).append("\" >> \"%OUT%\" 2>&1\r\n");
        s.append("echo   exit code=%ERRORLEVEL% >> \"%OUT%\"\r\n");
        s.append("echo [6] done >> \"%OUT%\"\r\n");

        Charset cs = batchCharset(lcAll);
        File bat = new File(dir, "test.bat");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(bat), cs)) {
            w.write(s.toString());
        }

        File shortcutDir = new File(ctx.getCacheDir(), "tsukuru");
        //noinspection ResultOfMethodCallIgnored
        shortcutDir.mkdirs();
        File desktop = new File(shortcutDir, "wine_test.desktop");
        String imagefs = new File(ctx.getFilesDir(), "imagefs").getAbsolutePath();
        String root = c.getRootDir().getAbsolutePath();
        String home = root.startsWith(imagefs) ? root.substring(imagefs.length()) : "/home/" + ImageFs.USER;
        try (PrintWriter w = new PrintWriter(desktop, "UTF-8")) {
            w.println("[Desktop Entry]");
            w.println("Name=wine_test");
            w.println("Exec=env WINEPREFIX=\"" + home + "/.wine\" wine \"C:\\\\\\\\" + TEST_DIR + "\\\\\\\\test.bat\"");
            w.println("Type=Application");
            w.println("container_id:" + c.id);
            w.println();
            w.println("[Extra Data]");
            w.println("lc_all=" + (lcAll != null ? lcAll : "ko_KR.UTF-8"));
        }
        return desktop;
    }

    static String readResult(Container c, String lcAll) {
        File f = new File(testDir(c), TEST_OUT);
        if (!f.isFile()) return null;
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            byte[] buf = new byte[(int) Math.min(r.length(), 32 * 1024)];
            r.readFully(buf);
            return new String(buf, batchCharset(lcAll)).replace("\r", "");
        } catch (Exception e) {
            return "읽기 실패: " + e;
        }
    }
}
