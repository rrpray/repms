package org.tvp.kirikiri2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import java.io.File;

/**
 * 쯔꾸르박스용 Kirikiroid2 진입점.
 * - 런처가 넘긴 게임 경로(data.xp3 또는 게임 폴더)로 파일 선택 화면 없이 바로 시작 (네이티브 TVPCheckStartupArg 가 호출)
 * - 엔진 라이브러리를 직접 로드 (앱 전체 meta-data 에 기대지 않음)
 * - 설정 저장소를 Winlator 기본 설정 파일과 분리
 */
public class TsukuruKirikiriActivity extends KR2Activity {
    public static final String EXTRA_GAME_PATH = "game_path";

    private static volatile String sStartupPath;

    /** 네이티브에서 한 번만 가져간다 (다시 호출하면 빈 문자열 → 파일 선택 화면) */
    public static String getStartupPath() {
        String p = sStartupPath;
        sStartupPath = null;
        return p == null ? "" : p;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        String path = getIntent() != null ? getIntent().getStringExtra(EXTRA_GAME_PATH) : null;
        sStartupPath = resolve(path);
        super.onCreate(savedInstanceState);
        Sp = getSharedPreferences("kirikiroid2", Context.MODE_PRIVATE);
    }

    /** 폴더를 받으면 data.xp3 가 있을 때 그것을, 없으면 폴더 자체(startup.tjs 가 있는 경우)를 넘긴다 */
    private static String resolve(String path) {
        if (path == null || path.isEmpty()) return null;
        File f = new File(path);
        if (f.isDirectory()) {
            File xp3 = new File(f, "data.xp3");
            if (xp3.isFile()) return xp3.getAbsolutePath();
            File[] cand = f.listFiles((d, n) -> n.toLowerCase(java.util.Locale.ROOT).equals("data.xp3"));
            if (cand != null && cand.length > 0) return cand[0].getAbsolutePath();
            return f.getAbsolutePath();
        }
        return f.isFile() ? f.getAbsolutePath() : null;
    }

    @Override
    protected void onLoadNativeLibraries() {
        System.loadLibrary("krkr2yuri");
    }

    @Override
    public int get_res_sd_operate_step() {
        return R.drawable.sd_operate_step;
    }
}
