package io.tsukurubox.easyrpg;

import androidx.core.content.FileProvider;

/**
 * EasyRPG 의 FileProvider(버그 리포트 첨부용).
 * Winlator 도 androidx FileProvider 를 쓰므로, 같은 클래스 이름으로 두 번 선언되면
 * 매니페스트 병합이 충돌한다. 하위 클래스로 분리해 둘 다 유지한다.
 */
public class ErpgFileProvider extends FileProvider {
}
