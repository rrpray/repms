package io.tsukurubox.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.Inflater;

/**
 * RPG Maker XP/VX/VX Ace 스크립트 추출.
 * - Data/Scripts.rxdata|rvdata|rvdata2 (Ruby Marshal 4.8)
 * - 암호화 아카이브 Game.rgssad / .rgss2a (v1), .rgss3a (v3)
 */
final class RgssScripts {
    private RgssScripts() {}

    static final class Script {
        final String name;
        final String code;

        Script(String name, String code) {
            this.name = name;
            this.code = code;
        }
    }

    private static final long M32 = 0xFFFFFFFFL;

    // ─── 아카이브 ────────────────────────────────────────────

    static byte[] extractFromArchive(File archive) throws IOException {
        try (RandomAccessFile f = new RandomAccessFile(archive, "r")) {
            byte[] head = new byte[8];
            f.readFully(head);
            if (!new String(head, 0, 7, StandardCharsets.ISO_8859_1).equals("RGSSAD\0")) {
                throw new IOException("RGSSAD 헤더 아님");
            }
            int ver = head[7];
            if (ver == 1) return extractV1(f);
            if (ver == 3) return extractV3(f);
            throw new IOException("알 수 없는 RGSSAD 버전: " + ver);
        }
    }

    private static long u32(RandomAccessFile f) throws IOException {
        byte[] b = new byte[4];
        if (f.read(b) < 4) return -1;
        return (b[0] & 0xFFL) | (b[1] & 0xFFL) << 8 | (b[2] & 0xFFL) << 16 | (b[3] & 0xFFL) << 24;
    }

    private static long next(long key) {
        return (key * 7 + 3) & M32;
    }

    private static byte[] extractV1(RandomAccessFile f) throws IOException {
        long key = 0xDEADCAFEL;
        long len = f.length();
        while (f.getFilePointer() + 4 <= len) {
            long nlen = u32(f) ^ key;
            key = next(key);
            if (nlen < 0 || nlen > 4096) throw new IOException("손상된 아카이브");
            byte[] nb = new byte[(int) nlen];
            f.readFully(nb);
            for (int i = 0; i < nb.length; i++) {
                nb[i] ^= (byte) (key & 0xFF);
                key = next(key);
            }
            long size = u32(f) ^ key;
            key = next(key);
            if (isScripts(new String(nb, StandardCharsets.UTF_8))) {
                return decrypt(readBytes(f, size), key);
            }
            f.seek(f.getFilePointer() + size);
        }
        return null;
    }

    private static byte[] extractV3(RandomAccessFile f) throws IOException {
        long key = (u32(f) * 9 + 3) & M32;
        long len = f.length();
        while (f.getFilePointer() + 16 <= len) {
            long offset = u32(f) ^ key;
            if (offset == 0) return null;
            long size = u32(f) ^ key;
            long fkey = u32(f) ^ key;
            long nlen = u32(f) ^ key;
            if (nlen > 4096) throw new IOException("손상된 아카이브");
            byte[] nb = new byte[(int) nlen];
            f.readFully(nb);
            for (int i = 0; i < nb.length; i++) {
                nb[i] ^= (byte) ((key >> (8 * (i % 4))) & 0xFF);
            }
            if (isScripts(new String(nb, StandardCharsets.UTF_8))) {
                f.seek(offset);
                return decrypt(readBytes(f, size), fkey);
            }
        }
        return null;
    }

    private static byte[] readBytes(RandomAccessFile f, long size) throws IOException {
        if (size < 0 || size > 64L * 1024 * 1024) throw new IOException("스크립트 크기 비정상");
        byte[] b = new byte[(int) size];
        f.readFully(b);
        return b;
    }

    private static byte[] decrypt(byte[] data, long key) {
        for (int i = 0; i < data.length; i += 4) {
            for (int j = 0; j < 4 && i + j < data.length; j++) {
                data[i + j] ^= (byte) ((key >> (8 * j)) & 0xFF);
            }
            key = next(key);
        }
        return data;
    }

    static boolean isScripts(String name) {
        String n = name.replace('\\', '/').toLowerCase(Locale.ROOT);
        return n.matches("(.*/)?data/scripts\\.(rxdata|rvdata2?)");
    }

    // ─── Ruby Marshal (필요한 타입만) ─────────────────────────

    static List<Script> parse(byte[] data) throws IOException {
        Marshal m = new Marshal(data);
        Object root = m.load();
        List<Script> out = new ArrayList<>();
        if (!(root instanceof List)) throw new IOException("스크립트 배열 아님");
        for (Object e : (List<?>) root) {
            if (!(e instanceof List) || ((List<?>) e).size() < 3) continue;
            List<?> entry = (List<?>) e;
            String name = entry.get(1) instanceof byte[] ? Text.decode((byte[]) entry.get(1)) : String.valueOf(entry.get(1));
            String code = "";
            if (entry.get(2) instanceof byte[]) {
                try {
                    code = new String(inflate((byte[]) entry.get(2)), StandardCharsets.UTF_8);
                } catch (Exception ignored) {
                }
            }
            out.add(new Script(name, code));
        }
        return out;
    }

    /** 스크립트 하나당 압축 해제 최대 크기 (압축 폭탄 방지) */
    private static final int MAX_SCRIPT = 16 * 1024 * 1024;

    private static byte[] inflate(byte[] z) throws Exception {
        Inflater inf = new Inflater();
        inf.setInput(z);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(z.length * 4);
        byte[] buf = new byte[8192];
        while (!inf.finished()) {
            int n = inf.inflate(buf);
            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break;
            bos.write(buf, 0, n);
            if (bos.size() > MAX_SCRIPT) throw new IOException("스크립트가 너무 큼");
        }
        inf.end();
        return bos.toByteArray();
    }

    private static final class Marshal {
        private final byte[] d;
        private int p;
        private final List<String> syms = new ArrayList<>();
        private final List<Object> objs = new ArrayList<>();
        private int depth;
        private static final int MAX_DEPTH = 64;

        Marshal(byte[] d) {
            this.d = d;
        }

        private int b() throws IOException {
            if (p >= d.length) throw new IOException("Marshal 데이터 끝");
            return d[p++] & 0xFF;
        }

        private byte[] r(int n) throws IOException {
            if (n < 0 || p + n > d.length) throw new IOException("Marshal 길이 오류");
            byte[] s = new byte[n];
            System.arraycopy(d, p, s, 0, n);
            p += n;
            return s;
        }

        private int integer() throws IOException {
            int c = (byte) b();
            if (c == 0) return 0;
            if (c >= 5) return c - 5;
            if (c <= -5) return c + 5;
            int n = Math.abs(c);
            long v = 0;
            for (int i = 0; i < n; i++) v |= (long) b() << (8 * i);
            if (c < 0) v -= 1L << (8 * n);
            return (int) v;
        }

        Object load() throws IOException {
            if (b() != 4 || b() != 8) throw new IOException("Ruby Marshal 4.8 형식 아님");
            return obj();
        }

        private Object obj() throws IOException {
            if (++depth > MAX_DEPTH) throw new IOException("Marshal 중첩이 너무 깊음");
            try {
                return objInner();
            } finally {
                depth--;
            }
        }

        private Object objInner() throws IOException {
            char t = (char) b();
            switch (t) {
                case '0':
                    return null;
                case 'T':
                    return Boolean.TRUE;
                case 'F':
                    return Boolean.FALSE;
                case 'i':
                    return integer();
                case ':': {
                    String s = new String(r(integer()), StandardCharsets.UTF_8);
                    syms.add(s);
                    return s;
                }
                case ';': {
                    int i = integer();
                    if (i < 0 || i >= syms.size()) throw new IOException("Marshal 심볼 참조 오류");
                    return syms.get(i);
                }
                case '"': {
                    byte[] s = r(integer());
                    objs.add(s);
                    return s;
                }
                case '[': {
                    int n = integer();
                    if (n < 0 || n > d.length - p) throw new IOException("Marshal 배열 길이 오류");
                    List<Object> arr = new ArrayList<>(Math.min(n, 4096));
                    objs.add(arr);
                    for (int i = 0; i < n; i++) arr.add(obj());
                    return arr;
                }
                case 'I': {
                    Object o = obj();
                    int n = integer();
                    if (n < 0 || n > d.length - p) throw new IOException("Marshal 속성 개수 오류");
                    for (int i = 0; i < n; i++) {
                        obj();
                        obj();
                    }
                    return o;
                }
                case '@': {
                    int i = integer();
                    if (i < 0 || i >= objs.size()) throw new IOException("Marshal 참조 오류");
                    return objs.get(i);
                }
                case 'l': {
                    b(); // sign
                    r(integer() * 2);
                    objs.add(0L);
                    return 0L;
                }
                default:
                    throw new IOException("지원하지 않는 Marshal 타입: " + t);
            }
        }
    }
}
