package io.tsukurubox.core;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** 파일/문자열 유틸 */
final class Text {
    private Text() {}

    private static final String[] CHARSETS = {"UTF-8", "x-windows-949", "windows-949", "MS949", "EUC-KR", "Shift_JIS"};

    /** UTF-8 → CP949 → Shift_JIS 순으로 엄격 디코딩, 모두 실패하면 ISO-8859-1 */
    static String decode(byte[] b) {
        for (String cs : CHARSETS) {
            if (!Charset.isSupported(cs)) continue;
            try {
                return Charset.forName(cs).newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(b)).toString();
            } catch (CharacterCodingException ignored) {
            }
        }
        return new String(b, StandardCharsets.ISO_8859_1);
    }

    static byte[] readAll(File f, long max) throws IOException {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long len = Math.min(r.length(), max);
            byte[] b = new byte[(int) len];
            r.readFully(b);
            return b;
        }
    }

    static String readText(File f) {
        try {
            byte[] b = readAll(f, 16L * 1024 * 1024);
            String s = decode(b);
            return s.startsWith("﻿") ? s.substring(1) : s;
        } catch (IOException e) {
            return null;
        }
    }

    /** 섹션 무시, 키 소문자 INI 파서 */
    static Map<String, String> readIni(File f) {
        Map<String, String> out = new HashMap<>();
        String s = f.isFile() ? readText(f) : null;
        if (s == null) return out;
        for (String line : s.split("\r?\n")) {
            line = line.trim();
            int eq = line.indexOf('=');
            if (eq <= 0 || line.startsWith(";") || line.startsWith("#") || line.startsWith("[")) continue;
            out.put(line.substring(0, eq).trim().toLowerCase(Locale.ROOT), line.substring(eq + 1).trim());
        }
        return out;
    }

    static boolean contains(byte[] hay, byte[] needle) {
        outer:
        for (int i = 0; i + needle.length <= hay.length; i++) {
            for (int j = 0; j < needle.length; j++) {
                if (hay[i + j] != needle[j]) continue outer;
            }
            return true;
        }
        return false;
    }
}
