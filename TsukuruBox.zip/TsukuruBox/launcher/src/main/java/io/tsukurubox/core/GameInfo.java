package io.tsukurubox.core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** 게임 한 개에 대한 분석 결과 */
public final class GameInfo {
    public enum Level { OK, MED, HIGH }

    public static final class Issue {
        public final Level level;
        public final String message;

        Issue(Level level, String message) {
            this.level = level;
            this.message = message;
        }
    }

    public final File dir;
    /** MV/MZ 는 www 폴더일 수 있음. index.html 이 있는 위치 */
    public final File baseDir;
    public final Engine engine;
    public String title;
    /** Windows 실행 파일 (없으면 null) */
    public File exe;
    /** 2000/2003 텍스트 인코딩: "949", "932" 또는 null */
    public String encoding;
    public final List<Issue> issues = new ArrayList<>();
    public final List<String> notes = new ArrayList<>();

    GameInfo(File dir, File baseDir, Engine engine) {
        this.dir = dir;
        this.baseDir = baseDir;
        this.engine = engine;
        this.title = dir.getName();
    }

    void add(Level level, String message) {
        issues.add(new Issue(level, message));
    }

    public Level worst() {
        Level w = Level.OK;
        for (Issue i : issues) {
            if (i.level.ordinal() > w.ordinal()) w = i.level;
        }
        return w;
    }

    /**
     * 이 게임을 실행할 수 있는 러너를 우선순위대로 반환.
     * @param mkxpAvailable mkxp-z 모듈이 APK 에 포함되었는지
     */
    public List<Runner> runners(boolean mkxpAvailable) {
        List<Runner> r = new ArrayList<>();
        boolean high = worst() == Level.HIGH;
        switch (engine) {
            case RM2000:
            case RM2003:
                r.add(Runner.EASYRPG);
                break;
            case XP:
            case VX:
            case VXACE:
                if (mkxpAvailable && !high) r.add(Runner.MKXP);
                break;
            case MV:
            case MZ:
                if (!high) r.add(Runner.WEB);
                break;
            case TYRANO:
                if (new File(baseDir, "index.html").isFile()) r.add(Runner.WEB);
                break;
            default:
                break;
        }
        if (exe != null) r.add(Runner.WINE);
        if (engine.isRgss() && mkxpAvailable && high) r.add(Runner.MKXP);
        if ((engine == Engine.MV || engine == Engine.MZ) && high) r.add(Runner.WEB);
        return r;
    }
}
