package io.tsukurubox.core;

/** 앱 안에 내장된 실행 엔진 */
public enum Runner {
    EASYRPG("EasyRPG (내장)"),
    MKXP("mkxp-z (내장, 실험적)"),
    WEB("HTML5 러너 (내장)"),
    WINE("Winlator (내장)");

    public final String label;

    Runner(String label) {
        this.label = label;
    }
}
