package io.tsukurubox.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.zip.Inflater;

/**
 * 吉里吉里 xp3 아카이브가 Kirikiroid2 로 읽을 수 있는 형식인지 검사.
 * 상용 게임 상당수는 xp3 를 게임 전용 방식으로 암호화(파일 이름 해시화, 내용 암호화)해서
 * Windows 용 게임 exe 안의 복호 코드 없이는 읽을 수 없다 → 그런 게임은 Winlator 로 실행해야 한다.
 */
public final class Xp3Probe {
    private Xp3Probe() {}

    public enum Result {
        /** 평범한 xp3 (startup.tjs 를 읽을 수 있음) */
        PLAIN,
        /** 파일 목록이 암호화·해시화되어 있음 */
        HASHED_INDEX,
        /** 목록은 보이지만 스크립트 내용이 암호화되어 있음 */
        ENCRYPTED_DATA,
        /** xp3 가 아니거나 읽기 실패 */
        UNKNOWN
    }

    private static final byte[] MAGIC = {'X', 'P', '3', '\r', '\n', ' ', '\n', 0x1a, (byte) 0x8b, 0x67, 0x01};
    private static final long MAX_INDEX = 64L * 1024 * 1024;

    public static Result probe(File xp3) {
        try (RandomAccessFile r = new RandomAccessFile(xp3, "r")) {
            byte[] m = new byte[11];
            r.readFully(m);
            for (int i = 0; i < 11; i++) if (m[i] != MAGIC[i]) return Result.UNKNOWN;
            long indexOfs = le64(r);
            if (indexOfs == 0x17) {
                // 2.28 이후 형식: [u32 부버전][u8 0x80 @0x17][u64 크기][u64 실제 목록 위치]
                r.seek(0x13);
                le32(r);                     // minor version
                int flag = r.read();         // 0x80 = continue
                if (flag != 0x80) return Result.HASHED_INDEX;
                le64(r);                     // index size
                indexOfs = le64(r);
            }
            if (indexOfs <= 0 || indexOfs >= r.length()) return Result.UNKNOWN;
            r.seek(indexOfs);
            int iflag = r.read();
            byte[] index;
            if ((iflag & 0x07) == 1) {       // zlib
                long comp = le64(r), raw = le64(r);
                if (comp <= 0 || comp > MAX_INDEX || raw <= 0 || raw > MAX_INDEX) return Result.HASHED_INDEX;
                byte[] c = new byte[(int) comp];
                r.readFully(c);
                index = inflate(c, (int) raw);
                if (index == null) return Result.HASHED_INDEX;
            } else if ((iflag & 0x07) == 0) {
                long size = le64(r);
                if (size <= 0 || size > MAX_INDEX) return Result.HASHED_INDEX;
                index = new byte[(int) size];
                r.readFully(index);
            } else {
                return Result.HASHED_INDEX;
            }
            return inspectIndex(r, index);
        } catch (Exception e) {
            return Result.UNKNOWN;
        }
    }

    /** 최상위 청크를 훑어 startup.tjs 를 찾고, 그 내용이 글자인지 확인 */
    private static Result inspectIndex(RandomAccessFile r, byte[] idx) throws Exception {
        int p = 0, files = 0;
        boolean foreignChunk = false;
        while (p + 12 <= idx.length) {
            String tag = new String(idx, p, 4, StandardCharsets.ISO_8859_1);
            long size = le64(idx, p + 4);
            int body = p + 12;
            if (size < 0 || body + size > idx.length) break;
            if (tag.equals("File")) {
                files++;
                String name = null;
                long segOfs = -1, segArc = 0, segOrig = 0;
                boolean segComp = false;
                int q = body;
                int end = (int) (body + size);
                while (q + 12 <= end) {
                    String st = new String(idx, q, 4, StandardCharsets.ISO_8859_1);
                    long ss = le64(idx, q + 4);
                    int sb = q + 12;
                    if (ss < 0 || sb + ss > end) break;
                    if (st.equals("info") && ss >= 22) {
                        int len = (idx[sb + 20] & 0xff) | (idx[sb + 21] & 0xff) << 8;
                        if (sb + 22 + len * 2L <= sb + ss) {
                            name = new String(idx, sb + 22, len * 2, StandardCharsets.UTF_16LE);
                        }
                    } else if (st.equals("segm") && ss >= 28 && segOfs < 0) {
                        segComp = (le32(idx, sb) & 7) == 1;
                        segOfs = le64(idx, sb + 4);
                        segOrig = le64(idx, sb + 12);
                        segArc = le64(idx, sb + 20);
                    }
                    q = (int) (sb + ss);
                }
                if (name != null && name.equalsIgnoreCase("startup.tjs")) {
                    return looksLikeText(readHead(r, segOfs, segArc, segOrig, segComp))
                            ? Result.PLAIN : Result.ENCRYPTED_DATA;
                }
            } else {
                foreignChunk = true;         // Hxv4, hnfn, eliF 등: 해시 이름 목록
            }
            p = (int) (body + size);
        }
        if (foreignChunk) return Result.HASHED_INDEX;
        // startup.tjs 가 없는 xp3 (패치·영상용) 는 판단하지 않음
        return files > 0 ? Result.PLAIN : Result.UNKNOWN;
    }

    private static byte[] readHead(RandomAccessFile r, long ofs, long arc, long orig, boolean comp) throws Exception {
        if (ofs < 0 || arc <= 0 || ofs + arc > r.length()) return new byte[0];
        int n = (int) Math.min(arc, comp ? 64 * 1024 : 256);
        byte[] b = new byte[n];
        r.seek(ofs);
        r.readFully(b);
        if (!comp) return b;
        byte[] out = inflate(b, (int) Math.min(orig, 256));
        return out == null ? new byte[0] : out;
    }

    /** UTF-16 BOM, UTF-8 BOM, 또는 대부분 인쇄 가능한 문자면 글자로 본다 */
    static boolean looksLikeText(byte[] b) {
        if (b.length < 2) return false;
        if ((b[0] & 0xff) == 0xff && (b[1] & 0xff) == 0xfe) return true;
        if (b.length >= 3 && (b[0] & 0xff) == 0xef && (b[1] & 0xff) == 0xbb && (b[2] & 0xff) == 0xbf) return true;
        // 吉里吉里 자체 단순 암호화 텍스트(FE FE ..)는 엔진이 스스로 풀 수 있으므로 글자로 본다
        if ((b[0] & 0xff) == 0xfe && (b[1] & 0xff) == 0xfe) return true;
        int ok = 0;
        for (byte x : b) {
            int c = x & 0xff;
            if (c == 9 || c == 10 || c == 13 || c >= 0x20 && c < 0x7f || c >= 0x80) ok++;
        }
        int ascii = 0;
        for (byte x : b) if ((x & 0xff) < 0x80) ascii++;
        return ok * 100 >= b.length * 95 && ascii * 100 >= b.length * 60;
    }

    private static byte[] inflate(byte[] c, int max) {
        Inflater inf = new Inflater();
        try {
            inf.setInput(c);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            while (!inf.finished() && out.size() < max) {
                int n = inf.inflate(buf);
                if (n == 0) {
                    if (inf.needsInput() || inf.needsDictionary()) break;
                }
                out.write(buf, 0, n);
            }
            return out.size() == 0 ? null : out.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            inf.end();
        }
    }

    private static long le64(RandomAccessFile r) throws Exception {
        long v = 0;
        for (int i = 0; i < 8; i++) v |= (long) (r.read() & 0xff) << (8 * i);
        return v;
    }

    private static int le32(RandomAccessFile r) throws Exception {
        int v = 0;
        for (int i = 0; i < 4; i++) v |= (r.read() & 0xff) << (8 * i);
        return v;
    }

    private static long le64(byte[] b, int o) {
        long v = 0;
        for (int i = 0; i < 8; i++) v |= (long) (b[o + i] & 0xff) << (8 * i);
        return v;
    }

    private static int le32(byte[] b, int o) {
        int v = 0;
        for (int i = 0; i < 4; i++) v |= (b[o + i] & 0xff) << (8 * i);
        return v;
    }
}
