package io.tsukurubox.launcher;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * RPG Maker 공식 사이트에서 RTP 설치 프로그램을 받아 게임 목록에 "RTP 설치" 항목으로 넣는다.
 *
 * RTP 라이선스가 재배포를 금지하므로 앱(APK)에 넣지 않고, 사용자의 폰이 공식 주소에서 직접 받는다.
 * 받은 설치 프로그램은 Winlator 에서 실행하면 컨테이너 안에 설치되고 레지스트리 등록도 설치 프로그램이 한다.
 */
final class RtpDownloader {
    private RtpDownloader() {}

    interface Progress {
        void update(String message);
    }

    /** {표시 이름, 폴더 이름, 공식 URL} */
    static final String[][] PACKAGES = {
            {"RPG Maker VX Ace RTP", "RTP 설치 - VX Ace", "https://assets.rpgmakerweb.com/RPGVXAce_RTP.zip"},
            {"RPG Maker VX RTP", "RTP 설치 - VX", "https://assets.rpgmakerweb.com/vx_rtp102e.zip"},
            {"RPG Maker XP RTP", "RTP 설치 - XP", "https://assets.rpgmakerweb.com/xp_rtp104e.exe"},
    };

    /** 이 파일이 있는 폴더는 이름에 setup 이 들어간 exe 도 실행 대상으로 인정 (GameDetector) */
    static final String INSTALLER_MARKER = ".tsukuru_installer";

    private static final long MAX_DOWNLOAD = 512L * 1024 * 1024;

    static void downloadAll(File gamesRoot, boolean[] selected, Progress p) throws IOException {
        for (int i = 0; i < PACKAGES.length; i++) {
            if (!selected[i]) continue;
            String[] pkg = PACKAGES[i];
            File dir = new File(gamesRoot, pkg[1]);
            if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("폴더를 만들 수 없음: " + dir);
            String url = pkg[2];
            String fileName = url.substring(url.lastIndexOf('/') + 1);
            File tmp = new File(dir, fileName + ".part");
            download(url, tmp, pkg[0], p);
            if (fileName.toLowerCase(Locale.ROOT).endsWith(".zip")) {
                p.update(pkg[0] + " 압축 푸는 중…");
                unzip(tmp, dir);
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            } else {
                File exe = new File(dir, fileName);
                if (!tmp.renameTo(exe)) throw new IOException("파일 이름 변경 실패: " + exe);
            }
            flattenSingleSubfolder(dir);
            //noinspection ResultOfMethodCallIgnored
            new File(dir, INSTALLER_MARKER).createNewFile();
        }
    }

    private static void download(String url, File dest, String label, Progress p) throws IOException {
        if (!url.startsWith("https://assets.rpgmakerweb.com/")) throw new IOException("허용되지 않은 주소");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException(label + " 다운로드 실패 (HTTP " + code + ")");
            long total = c.getContentLengthLong();
            try (InputStream in = new BufferedInputStream(c.getInputStream());
                 OutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[64 * 1024];
                long done = 0, lastShown = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    done += n;
                    if (done > MAX_DOWNLOAD) throw new IOException("파일이 너무 큼");
                    if (done - lastShown > 512 * 1024) {
                        lastShown = done;
                        p.update(label + " 받는 중… " + (done >> 20) + "MB"
                                + (total > 0 ? " / " + (total >> 20) + "MB" : ""));
                    }
                }
            }
        } finally {
            c.disconnect();
        }
    }

    /** zip 해제 (폴더 밖으로 나가는 경로 차단) */
    private static void unzip(File zip, File destDir) throws IOException {
        String base = destDir.getCanonicalPath() + File.separator;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new java.io.FileInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[64 * 1024];
            long total = 0;
            while ((e = zin.getNextEntry()) != null) {
                File out = new File(destDir, e.getName());
                if (!out.getCanonicalPath().startsWith(base)) throw new IOException("잘못된 zip 경로: " + e.getName());
                if (e.isDirectory()) {
                    //noinspection ResultOfMethodCallIgnored
                    out.mkdirs();
                    continue;
                }
                //noinspection ResultOfMethodCallIgnored
                out.getParentFile().mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        total += n;
                        if (total > MAX_DOWNLOAD * 2) throw new IOException("압축 해제 크기 초과");
                    }
                }
            }
        }
    }

    /** zip 안에 폴더가 하나만 있으면 그 내용을 한 단계 위로 올린다 (런처가 exe 를 바로 찾도록) */
    private static void flattenSingleSubfolder(File dir) {
        File[] items = dir.listFiles(f -> !f.getName().startsWith("."));
        if (items == null || items.length != 1 || !items[0].isDirectory()) return;
        File sub = items[0];
        File[] inner = sub.listFiles();
        if (inner == null) return;
        for (File f : inner) {
            //noinspection ResultOfMethodCallIgnored
            f.renameTo(new File(dir, f.getName()));
        }
        //noinspection ResultOfMethodCallIgnored
        sub.delete();
    }
}
