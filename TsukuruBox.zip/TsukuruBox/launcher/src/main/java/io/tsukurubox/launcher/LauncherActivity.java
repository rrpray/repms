package io.tsukurubox.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.tsukurubox.core.GameDetector;
import io.tsukurubox.core.GameInfo;
import io.tsukurubox.core.Runner;

/** 통합 런처: 게임 폴더를 스캔해 엔진을 판별하고, 앱에 내장된 엔진으로 바로 실행한다. */
public class LauncherActivity extends Activity {
    private static final String PREFS = "tsukurubox";
    private static final String KEY_ROOT = "games_root";
    private static final String KEY_LOCALE = "wine_locale";
    private static final int REQ_STORAGE = 10;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<GameInfo> games = new ArrayList<>();

    private SharedPreferences prefs;
    private TextView header;
    private ProgressBar progress;
    private GameAdapter adapter;
    private boolean mkxp;
    private boolean askedPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        mkxp = EngineLauncher.mkxpAvailable();
        EngineLauncher.installCrashLogger();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(12);

        header = new TextView(this);
        header.setPadding(pad, pad, pad, dp(4));
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        root.addView(header);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)));

        ListView list = new ListView(this);
        adapter = new GameAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> launchDefault(games.get(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            showRunnerMenu(games.get(pos));
            return true;
        });
        TextView empty = new TextView(this);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(pad * 2, pad * 2, pad * 2, pad * 2);
        empty.setText("게임이 없습니다.\n\n게임 폴더를 아래 위치에 복사한 뒤 새로고침하세요.\n(폴더 하나 = 게임 하나)\n\n"
                + gamesRoot().getAbsolutePath());
        root.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        list.setEmptyView(empty);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasStorageAccess()) {
            ensureFolders();
            if (games.isEmpty()) rescan();
        } else if (!askedPermission) {
            askedPermission = true;
            requestStorageAccess();
        } else {
            header.setText("저장소 권한이 필요합니다. 메뉴 → 권한 허용");
        }
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    // ─── 저장소 권한 ────────────────────────────────────────

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            new AlertDialog.Builder(this)
                    .setTitle("모든 파일 접근 권한")
                    .setMessage("게임 폴더를 읽고 세이브를 쓰려면 '모든 파일에 대한 접근' 권한이 필요합니다.")
                    .setPositiveButton("설정 열기", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                        }
                    })
                    .setNegativeButton("나중에", null)
                    .show();
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_STORAGE && hasStorageAccess()) {
            ensureFolders();
            rescan();
        }
    }

    private void ensureFolders() {
        File app = EngineLauncher.appRoot();
        for (String sub : new String[]{"games", "rtp/2000", "rtp/2003", "rtp/XP", "rtp/VX", "rtp/VXAce", "fonts"}) {
            //noinspection ResultOfMethodCallIgnored
            new File(app, sub).mkdirs();
        }
        //noinspection ResultOfMethodCallIgnored
        gamesRoot().mkdirs();
    }

    // ─── 스캔 ───────────────────────────────────────────────

    private File gamesRoot() {
        String def = new File(EngineLauncher.appRoot(), "games").getAbsolutePath();
        return new File(prefs.getString(KEY_ROOT, def));
    }

    private void rescan() {
        File root = gamesRoot();
        header.setText("스캔 중… " + root.getAbsolutePath());
        progress.setVisibility(View.VISIBLE);
        worker.execute(() -> {
            List<GameInfo> found;
            try {
                found = GameDetector.scan(root, 2);
            } catch (Throwable t) {
                found = new ArrayList<>();
            }
            final List<GameInfo> result = found;
            ui.post(() -> {
                if (isFinishing()) return;
                games.clear();
                games.addAll(result);
                adapter.notifyDataSetChanged();
                progress.setVisibility(View.GONE);
                header.setText(root.getAbsolutePath() + "  ·  게임 " + result.size() + "개"
                        + (mkxp ? "" : "  ·  mkxp-z 미포함 빌드"));
            });
        });
    }

    // ─── 실행 ───────────────────────────────────────────────

    private void launchDefault(GameInfo g) {
        List<Runner> rs = g.runners(mkxp);
        if (rs.isEmpty()) {
            showDetails(g);
            return;
        }
        EngineLauncher.launch(this, g, rs.get(0), localeFor(g));
    }

    private void showRunnerMenu(GameInfo g) {
        List<Runner> rs = g.runners(mkxp);
        List<String> labels = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();
        for (Runner r : rs) {
            labels.add("▶ " + r.label + (r == rs.get(0) ? "  (추천)" : ""));
            actions.add(() -> EngineLauncher.launch(this, g, r, localeFor(g)));
        }
        if (g.exe != null) {
            labels.add("▶ Winlator (일본어 로케일)");
            actions.add(() -> EngineLauncher.launch(this, g, Runner.WINE, "ja_JP.UTF-8"));
            labels.add("▶ Winlator (한국어 로케일)");
            actions.add(() -> EngineLauncher.launch(this, g, Runner.WINE, "ko_KR.UTF-8"));
            labels.add("▶ Winlator (가상 패드 없이 · 마우스/키보드 게임용)");
            actions.add(() -> EngineLauncher.launch(this, g, Runner.WINE, localeFor(g), false));
        }
        labels.add("분석 결과 보기");
        actions.add(() -> showDetails(g));
        new AlertDialog.Builder(this)
                .setTitle(g.title)
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .show();
    }

    /** Winlator 로케일: 일본어 게임은 ja_JP, 그 외 기본값(설정 가능, 기본 ko_KR) */
    private String localeFor(GameInfo g) {
        if ("932".equals(g.encoding) || containsKana(g.title)) return "ja_JP.UTF-8";
        return prefs.getString(KEY_LOCALE, "ko_KR.UTF-8");
    }

    private static boolean containsKana(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '぀' && c <= 'ヿ') return true;
        }
        return false;
    }

    private void showDetails(GameInfo g) {
        StringBuilder b = new StringBuilder();
        b.append("엔진: ").append(g.engine.displayName).append('\n');
        b.append("경로: ").append(g.dir.getAbsolutePath()).append('\n');
        if (g.exe != null) b.append("실행 파일: ").append(g.exe.getName()).append('\n');
        List<Runner> rs = g.runners(mkxp);
        b.append("실행 엔진: ");
        if (rs.isEmpty()) b.append("없음");
        for (int i = 0; i < rs.size(); i++) b.append(i == 0 ? "" : " → ").append(rs.get(i).label);
        b.append("\n");
        if (!g.issues.isEmpty()) {
            b.append("\n[호환성 경고]\n");
            for (GameInfo.Issue i : g.issues) b.append("(").append(i.level).append(") ").append(i.message).append('\n');
        }
        if (!g.notes.isEmpty()) {
            b.append("\n[참고]\n");
            for (String n : g.notes) b.append("· ").append(n).append('\n');
        }
        new AlertDialog.Builder(this).setTitle(g.title).setMessage(b.toString()).setPositiveButton("닫기", null).show();
    }

    // ─── 메뉴 ───────────────────────────────────────────────

    private static final int M_REFRESH = 1, M_FOLDER = 2, M_LOCALE = 3, M_WINLATOR = 4, M_EASYRPG = 5, M_HELP = 6, M_PERM = 7, M_DIAG = 8, M_RTP = 9;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, M_REFRESH, 0, "새로고침").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(0, M_DIAG, 1, "진단 (한 번에 점검)").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add(0, M_RTP, 1, "RTP 받기 (XP / VX / VX Ace)");
        menu.add(0, M_FOLDER, 1, "게임 폴더 변경");
        menu.add(0, M_LOCALE, 2, "Winlator 기본 로케일");
        menu.add(0, M_WINLATOR, 3, "Winlator 설정 (컨테이너/드라이버)");
        menu.add(0, M_EASYRPG, 4, "EasyRPG 설정");
        menu.add(0, M_PERM, 5, "권한 허용");
        menu.add(0, M_HELP, 6, "사용법");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case M_REFRESH:
                if (hasStorageAccess()) rescan();
                else requestStorageAccess();
                return true;
            case M_FOLDER:
                editFolder();
                return true;
            case M_LOCALE:
                chooseLocale();
                return true;
            case M_WINLATOR:
                EngineLauncher.openClass(this, EngineLauncher.WINLATOR_MAIN, "Winlator");
                return true;
            case M_EASYRPG:
                EngineLauncher.openClass(this, EngineLauncher.EASYRPG_SETTINGS, "EasyRPG");
                return true;
            case M_RTP:
                if (hasStorageAccess()) askRtp();
                else requestStorageAccess();
                return true;
            case M_DIAG:
                EngineLauncher.openClass(this, EngineLauncher.DIAGNOSTICS, "진단");
                return true;
            case M_PERM:
                requestStorageAccess();
                return true;
            case M_HELP:
                showHelp();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void askRtp() {
        String[] names = new String[RtpDownloader.PACKAGES.length];
        boolean[] sel = new boolean[names.length];
        for (int i = 0; i < names.length; i++) {
            names[i] = RtpDownloader.PACKAGES[i][0];
            sel[i] = true;
        }
        new AlertDialog.Builder(this)
                .setTitle("RTP 받기 (공식 사이트)")
                .setMultiChoiceItems(names, sel, (d, which, checked) -> sel[which] = checked)
                .setPositiveButton("받기", (d, w) -> downloadRtp(sel))
                .setNegativeButton("취소", null)
                .show();
        Toast.makeText(this, "RPG Maker 공식 사이트(assets.rpgmakerweb.com)에서 직접 받습니다. "
                + "RTP 는 재배포가 금지되어 앱에 넣지 않았습니다.", Toast.LENGTH_LONG).show();
    }

    private void downloadRtp(boolean[] sel) {
        TextView msg = new TextView(this);
        int pad = dp(20);
        msg.setPadding(pad, pad, pad, pad);
        msg.setText("준비 중…");
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("RTP 받는 중").setView(msg).setCancelable(false).show();
        File root = gamesRoot();
        worker.execute(() -> {
            String result;
            try {
                RtpDownloader.downloadAll(root, sel, m -> ui.post(() -> msg.setText(m)));
                result = null;
            } catch (Exception e) {
                result = e.getMessage();
            }
            final String err = result;
            ui.post(() -> {
                dlg.dismiss();
                if (err != null) {
                    new AlertDialog.Builder(this).setTitle("RTP 받기 실패").setMessage(err)
                            .setPositiveButton("닫기", null).show();
                    return;
                }
                rescan();
                new AlertDialog.Builder(this).setTitle("다 받았습니다")
                        .setMessage("게임 목록에 'RTP 설치 - …' 항목이 생겼습니다.\n\n"
                                + "각 항목을 한 번씩 눌러 설치 창에서 다음 → 설치를 진행하세요 (화면을 누르면 클릭됩니다).\n"
                                + "설치가 끝나면 그 항목 폴더는 지워도 됩니다.")
                        .setPositiveButton("확인", null).show();
            });
        });
    }

    private void editFolder() {
        EditText input = new EditText(this);
        input.setText(gamesRoot().getAbsolutePath());
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("게임 폴더 경로")
                .setView(input)
                .setPositiveButton("저장", (d, w) -> {
                    String p = input.getText().toString().trim();
                    if (!p.isEmpty()) {
                        prefs.edit().putString(KEY_ROOT, p).apply();
                        rescan();
                    }
                })
                .setNeutralButton("기본값", (d, w) -> {
                    prefs.edit().remove(KEY_ROOT).apply();
                    rescan();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void chooseLocale() {
        String[] values = {"ko_KR.UTF-8", "ja_JP.UTF-8", "en_US.UTF-8", "zh_CN.UTF-8"};
        String cur = prefs.getString(KEY_LOCALE, values[0]);
        int sel = 0;
        for (int i = 0; i < values.length; i++) if (values[i].equals(cur)) sel = i;
        new AlertDialog.Builder(this)
                .setTitle("Winlator 기본 로케일 (일본어 게임은 자동으로 ja_JP)")
                .setSingleChoiceItems(values, sel, (d, which) -> {
                    prefs.edit().putString(KEY_LOCALE, values[which]).apply();
                    d.dismiss();
                })
                .show();
    }

    private void showHelp() {
        File app = EngineLauncher.appRoot();
        String msg = "① 게임 폴더를 통째로 복사: " + new File(app, "games") + "/<게임폴더>\n"
                + "② 새로고침 → 게임을 누르면 추천 엔진으로 실행, 길게 누르면 엔진 선택\n\n"
                + "· 2000/2003 → EasyRPG (RTP: " + new File(app, "rtp") + "/2000, /2003)\n"
                + "· MV/MZ/Tyrano → HTML5 러너\n"
                + "· XP/VX/VX Ace → mkxp-z(포함 시) 또는 Winlator (RTP 필요 게임: " + new File(app, "rtp") + "/XP, /VX, /VXAce)\n"
                + "· 울프 RPG, Unity, 기타 exe → Winlator\n\n"
                + "Winlator 첫 실행 시 Wine 환경 설치와 컨테이너 생성이 필요합니다 (메뉴 → Winlator 설정).\n"
                + "Winlator 게임에는 방향키·결정(Z)·취소(X)·달리기(Shift)·메뉴(Esc) 가상 패드가 뜨고, 화면을 누르면 그 위치를 바로 클릭합니다. "
                + "버튼 배치는 게임 중 Winlator 사이드 메뉴 → 입력 컨트롤에서 바꿀 수 있습니다.\n"
                + "Winlator 에서 한글이 깨지면 " + new File(app, "fonts") + " 에 한글 ttf 를 넣으면 실행 시 자동 복사됩니다.";
        new AlertDialog.Builder(this).setTitle("사용법").setMessage(msg).setPositiveButton("닫기", null).show();
    }

    // ─── 목록 ───────────────────────────────────────────────

    private final class GameAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return games.size();
        }

        @Override
        public Object getItem(int position) {
            return games.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row;
            TextView title, sub;
            if (convertView instanceof LinearLayout) {
                row = (LinearLayout) convertView;
                title = (TextView) row.getChildAt(0);
                sub = (TextView) row.getChildAt(1);
            } else {
                row = new LinearLayout(LauncherActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(16), dp(12), dp(16), dp(12));
                title = new TextView(LauncherActivity.this);
                title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
                title.setTypeface(Typeface.DEFAULT_BOLD);
                sub = new TextView(LauncherActivity.this);
                sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                row.addView(title);
                row.addView(sub);
            }
            GameInfo g = games.get(position);
            List<Runner> rs = g.runners(mkxp);
            title.setText(g.title);
            String state;
            int color;
            switch (g.worst()) {
                case HIGH:
                    state = "⚠ 호환성 경고";
                    color = Color.rgb(0xE5, 0x73, 0x73);
                    break;
                case MED:
                    state = "주의";
                    color = Color.rgb(0xFF, 0xB7, 0x4D);
                    break;
                default:
                    state = "양호";
                    color = Color.rgb(0x81, 0xC7, 0x84);
                    break;
            }
            sub.setText(g.engine.displayName + "  ·  " + (rs.isEmpty() ? "실행 불가" : rs.get(0).label) + "  ·  " + state);
            sub.setTextColor(color);
            return row;
        }
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }
}
