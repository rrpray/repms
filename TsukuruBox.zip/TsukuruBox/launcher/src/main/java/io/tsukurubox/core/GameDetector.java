package io.tsukurubox.core;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 폴더를 보고 엔진을 판별하고 모바일 호환성을 검사한다. Android 의존성 없음. */
public final class GameDetector {
    private GameDetector() {}

    private static final Set<String> SYSTEM_DLLS = new HashSet<>(Arrays.asList(
            "user32", "kernel32", "gdi32", "winmm", "shell32", "advapi32", "msvcrt",
            "ntdll", "ole32", "oleaut32", "comctl32", "comdlg32", "dwmapi", "imm32",
            "version", "shlwapi", "psapi", "ws2_32", "wininet", "dsound", "dinput8"));

    private static final Pattern EXE_SKIP = Pattern.compile("(?i).*(unins|setup|config|crash|launcher|redist|vc_).*");

    // ─── 탐색 ───────────────────────────────────────────────

    /** root 자체가 게임이면 그 하나만, 아니면 depth 단계까지 하위 폴더에서 게임을 찾는다. */
    public static List<GameInfo> scan(File root, int depth) {
        List<GameInfo> out = new ArrayList<>();
        scanInto(root, depth, out);
        return out;
    }

    private static void scanInto(File dir, int depth, List<GameInfo> out) {
        if (dir == null || !dir.isDirectory() || dir.getName().startsWith(".")) return;
        GameInfo g = detect(dir);
        if (g != null) {
            out.add(g);
            return;
        }
        if (depth <= 0) return;
        File[] subs = dir.listFiles(File::isDirectory);
        if (subs == null) return;
        Arrays.sort(subs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (File s : subs) scanInto(s, depth - 1, out);
    }

    // ─── 판별 ───────────────────────────────────────────────

    /** 게임 폴더가 아니면 null */
    public static GameInfo detect(File root) {
        GameInfo g = identify(root);
        if (g == null) return null;
        g.exe = mainExe(g.dir);
        try {
            analyze(g);
        } catch (Throwable e) {
            // 손상되었거나 악의적으로 만든 게임 파일이 런처를 죽이지 못하게 모든 오류를 잡는다
            g.add(GameInfo.Level.MED, "분석 중 오류: " + e.getClass().getSimpleName());
        }
        g.title = cleanTitle(g.title, g.dir.getName());
        return g;
    }

    private static GameInfo identify(File root) {
        if (f(root, "RPG_RT.ldb").isFile() && f(root, "RPG_RT.lmt").isFile()) {
            boolean is03 = f(root, "Battle2").isDirectory() || f(root, "BattleCharSet").isDirectory()
                    || f(root, "BattleWeapon").isDirectory();
            return new GameInfo(root, root, is03 ? Engine.RM2003 : Engine.RM2000);
        }
        for (File base : new File[]{root, f(root, "www")}) {
            if (f(base, "js/rmmz_core.js").isFile()) return new GameInfo(root, base, Engine.MZ);
            if (f(base, "js/rpg_core.js").isFile()) return new GameInfo(root, base, Engine.MV);
        }
        File data = f(root, "Data");
        if (any(root, ".rgss3a") || any(data, ".rvdata2")) return new GameInfo(root, root, Engine.VXACE);
        if (any(root, ".rgss2a") || any(data, ".rvdata")) return new GameInfo(root, root, Engine.VX);
        if (any(root, ".rgssad") || any(data, ".rxdata")) return new GameInfo(root, root, Engine.XP);

        if (f(root, "Data.wolf").isFile() || f(root, "Data/BasicData").isDirectory() || any(data, ".wolf")) {
            return new GameInfo(root, root, Engine.WOLF);
        }
        if (f(root, "renpy").isDirectory() || any(f(root, "game"), ".rpa") || any(f(root, "game"), ".rpyc")) {
            return new GameInfo(root, root, Engine.RENPY);
        }
        if (f(root, "tyrano").isDirectory() || f(root, "data/system/Config.tjs").isFile()) {
            return new GameInfo(root, root, Engine.TYRANO);
        }
        if (f(root, "UnityPlayer.dll").isFile() || hasUnityData(root)) return new GameInfo(root, root, Engine.UNITY);
        if (any(root, ".pck") && mainExe(root) != null) return new GameInfo(root, root, Engine.GODOT);
        if (f(root, "data.win").isFile()) return new GameInfo(root, root, Engine.GAMEMAKER);
        if (f(root, "FNA.dll").isFile() || f(root, "MonoGame.Framework.dll").isFile() || anyPrefix(root, "Microsoft.Xna.Framework")) {
            return new GameInfo(root, root, Engine.XNA);
        }
        if (mainExe(root) != null) return new GameInfo(root, root, Engine.EXE);
        return null;
    }

    private static void analyze(GameInfo g) {
        switch (g.engine) {
            case RM2000:
            case RM2003:
                analyze2k(g);
                break;
            case XP:
            case VX:
            case VXACE:
                analyzeRgss(g);
                break;
            case MV:
            case MZ:
                analyzeMv(g);
                break;
            case TYRANO:
                if (!f(g.baseDir, "index.html").isFile()) g.notes.add("index.html 없음 → exe 통합 빌드, Winlator 로 실행");
                break;
            case WOLF:
                g.notes.add("울프 RPG 는 Winlator 로 실행. 한글 깨짐 시 폰트 폴더에 한글 ttf 추가");
                break;
            default:
                break;
        }
        if (g.exe == null && (g.engine.isRgss() || g.engine == Engine.WOLF || g.engine.ordinal() >= Engine.RENPY.ordinal())) {
            if (g.engine != Engine.TYRANO) g.add(GameInfo.Level.MED, "실행 파일(.exe)을 찾지 못함");
        }
    }

    // ─── 2000/2003 ──────────────────────────────────────────

    private static void analyze2k(GameInfo g) {
        Map<String, String> ini = Text.readIni(f(g.dir, "RPG_RT.ini"));
        if (ini.containsKey("gametitle") && !ini.get("gametitle").isEmpty()) g.title = ini.get("gametitle");
        if ("1".equals(ini.get("fullpackageflag"))) g.notes.add("FullPackage (RTP 불필요)");
        else g.notes.add("RTP 가 필요할 수 있음 → TsukuruBox/rtp/2000 또는 2003 에 RTP 배치");

        File exe = f(g.dir, "RPG_RT.exe");
        byte[] exeBytes = new byte[0];
        try {
            if (exe.isFile()) exeBytes = Text.readAll(exe, 8L * 1024 * 1024);
        } catch (Exception ignored) {
        }
        if (f(g.dir, "DynPlugins").isDirectory() || f(g.dir, "dynloader.dll").isFile()
                || Text.contains(exeBytes, "DynRPG".getBytes(StandardCharsets.US_ASCII))) {
            g.add(GameInfo.Level.MED, "DynRPG 사용 — EasyRPG 는 일부 플러그인만 지원");
        }
        if (Text.contains(exeBytes, "Maniac".getBytes(StandardCharsets.US_ASCII))) {
            g.notes.add("Maniacs Patch 감지 (EasyRPG 최신 버전 대부분 지원)");
        }
        List<String> dlls = new ArrayList<>();
        File[] fs = g.dir.listFiles();
        if (fs != null) for (File x : fs) {
            String n = x.getName().toLowerCase(Locale.ROOT);
            if (n.endsWith(".dll") && !n.equals("harmony.dll") && !n.equals("dynloader.dll")) dlls.add(x.getName());
        }
        if (!dlls.isEmpty()) {
            Collections.sort(dlls);
            g.add(GameInfo.Level.MED, "비표준 DLL 포함: " + join(dlls, 5) + " — 확장 기능이 동작 안 할 수 있음");
        }
        g.encoding = detect2kEncoding(f(g.dir, "RPG_RT.ldb"));
        if ("949".equals(g.encoding)) g.notes.add("한국어(CP949) 텍스트 감지 → EasyRPG 인코딩 949 로 실행");
        else if ("932".equals(g.encoding)) g.notes.add("일본어(Shift-JIS) 텍스트 감지");
    }

    static String detect2kEncoding(File ldb) {
        byte[] data;
        try {
            data = Text.readAll(ldb, 32L * 1024 * 1024);
        } catch (Exception e) {
            return null;
        }
        Charset ko = firstSupported("x-windows-949", "windows-949", "MS949", "EUC-KR");
        Charset ja = firstSupported("Shift_JIS", "windows-31j");
        int koScore = 0, jaScore = 0;
        int i = 0;
        while (i < data.length) {
            int start = i;
            while (i + 1 < data.length && lead(data[i]) && trail(data[i + 1])) i += 2;
            if (i - start >= 4) {
                byte[] chunk = Arrays.copyOfRange(data, start, i);
                if (ko != null) koScore += count(new String(chunk, ko), '\uAC00', '\uD7A3');
                if (ja != null) {
                    String s = new String(chunk, ja);
                    jaScore += count(s, '\u3040', '\u30FF') + count(s, '\u4E00', '\u9FFF');
                }
            }
            if (i == start) i++;
        }
        if (koScore == 0 && jaScore == 0) return null;
        return koScore > jaScore * 1.2 ? "949" : "932";
    }

    private static boolean lead(byte b) {
        int v = b & 0xFF;
        return v >= 0x81 && v <= 0xFE;
    }

    private static boolean trail(byte b) {
        int v = b & 0xFF;
        return v >= 0x40 && v <= 0xFE;
    }

    private static int count(String s, char lo, char hi) {
        int c = 0;
        for (int k = 0; k < s.length(); k++) {
            char ch = s.charAt(k);
            if (ch >= lo && ch <= hi) c++;
        }
        return c;
    }

    private static Charset firstSupported(String... names) {
        for (String n : names) {
            try {
                if (Charset.isSupported(n)) return Charset.forName(n);
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    // ─── XP / VX / VX Ace ───────────────────────────────────

    private static final Pattern WIN32API = Pattern.compile("Win32API\\.new\\s*\\(\\s*['\"]([^'\"]+)['\"]");
    private static final Pattern DLL_STR = Pattern.compile("(?i)['\"]([\\w\\-. /\\\\]+?)\\.dll['\"]");
    private static final Object[][] RGSS_PATTERNS = {
            {GameInfo.Level.HIGH, Pattern.compile("WIN32OLE"), "WIN32OLE (COM 객체) 사용"},
            {GameInfo.Level.HIGH, Pattern.compile("\\bFiddle\\b|\\bDL\\s*::|require\\s*\\(?\\s*['\"]dl['\"]"), "Fiddle/DL 네이티브 호출"},
            {GameInfo.Level.MED, Pattern.compile("\\bsystem\\s*\\(|%x\\{|\\bspawn\\s*\\("), "외부 프로그램 실행 (system/spawn)"},
    };

    private static void analyzeRgss(GameInfo g) {
        Map<String, String> ini = Text.readIni(f(g.dir, "Game.ini"));
        if (ini.containsKey("title") && !ini.get("title").isEmpty()) g.title = ini.get("title");
        String rtp = ini.containsKey("rtp") ? ini.get("rtp") : ini.get("rtp1");
        if (rtp != null && !rtp.isEmpty()) {
            String sub = g.engine == Engine.XP ? "XP" : g.engine == Engine.VX ? "VX" : "VXAce";
            g.notes.add("RTP '" + rtp + "' 사용 → 'RTP 없음' 오류가 나면 TsukuruBox/rtp/" + sub + " 에 RTP 파일을 넣으세요");
        }

        String ext = g.engine == Engine.XP ? "rxdata" : g.engine == Engine.VX ? "rvdata" : "rvdata2";
        String arcExt = g.engine == Engine.XP ? ".rgssad" : g.engine == Engine.VX ? ".rgss2a" : ".rgss3a";
        byte[] data = null;
        try {
            File plain = f(g.dir, "Data/Scripts." + ext);
            if (plain.isFile()) {
                data = Text.readAll(plain, 64L * 1024 * 1024);
            } else {
                File arc = first(g.dir, arcExt);
                if (arc != null) {
                    data = RgssScripts.extractFromArchive(arc);
                    g.notes.add("암호화 아카이브 " + arc.getName() + " 에서 스크립트 추출");
                }
            }
        } catch (Exception e) {
            g.add(GameInfo.Level.MED, "스크립트 추출 실패 (" + e.getMessage() + ")");
        }

        List<RgssScripts.Script> scripts = Collections.emptyList();
        if (data == null) {
            if (g.issues.isEmpty()) g.add(GameInfo.Level.MED, "Scripts 파일을 찾지 못함 — 호환성 직접 확인 필요");
        } else {
            try {
                scripts = RgssScripts.parse(data);
                g.notes.add("스크립트 " + scripts.size() + "개 검사");
            } catch (Exception e) {
                g.add(GameInfo.Level.MED, "스크립트 파싱 실패 (" + e.getMessage() + ")");
            }
        }

        Set<String> folderDlls = new TreeSet<>();
        collectDlls(g.dir, folderDlls, 3);
        Map<String, Set<String>> sysHits = new LinkedHashMap<>();
        Map<String, Set<String>> customHits = new LinkedHashMap<>();

        for (RgssScripts.Script s : scripts) {
            String label = s.name.isEmpty() ? "(이름 없음)" : s.name;
            Set<String> dlls = new HashSet<>();
            Matcher m = WIN32API.matcher(s.code);
            while (m.find()) dlls.add(m.group(1));
            m = DLL_STR.matcher(s.code);
            while (m.find()) dlls.add(m.group(1));
            for (String d : dlls) {
                String key = d.replace('\\', '/');
                key = key.substring(key.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
                if (key.endsWith(".dll")) key = key.substring(0, key.length() - 4);
                if (key.startsWith("rgss")) continue;
                Map<String, Set<String>> bucket = SYSTEM_DLLS.contains(key) ? sysHits : customHits;
                bucket.computeIfAbsent(key, k -> new TreeSet<>()).add(label);
            }
            for (Object[] p : RGSS_PATTERNS) {
                if (((Pattern) p[1]).matcher(s.code).find()) g.add((GameInfo.Level) p[0], "[" + label + "] " + p[2]);
            }
        }
        for (Map.Entry<String, Set<String>> e : customHits.entrySet()) {
            String tag = folderDlls.contains(e.getKey()) ? "게임 폴더에 포함된" : "외부";
            g.add(GameInfo.Level.HIGH, tag + " DLL '" + e.getKey() + ".dll' 호출 — 스크립트: " + join(new ArrayList<>(e.getValue()), 3));
        }
        for (Map.Entry<String, Set<String>> e : sysHits.entrySet()) {
            g.add(GameInfo.Level.MED, "Windows API '" + e.getKey() + "' 호출 — 스크립트: " + join(new ArrayList<>(e.getValue()), 3)
                    + " (Winlator 외 엔진에서는 해당 기능 무시/오류 가능)");
        }
        List<String> extra = new ArrayList<>();
        for (String d : folderDlls) if (!d.startsWith("rgss")) extra.add(d);
        if (!extra.isEmpty()) g.notes.add("폴더 내 DLL: " + join(extra, 10));
    }

    private static void collectDlls(File dir, Set<String> out, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File x : fs) {
            String n = x.getName().toLowerCase(Locale.ROOT);
            if (x.isDirectory() && depth > 0) collectDlls(x, out, depth - 1);
            else if (n.endsWith(".dll")) out.add(n.substring(0, n.length() - 4));
        }
    }

    // ─── MV / MZ ────────────────────────────────────────────

    private static final Object[][] MV_PATTERNS = {
            {GameInfo.Level.MED, Pattern.compile("require\\s*\\(\\s*['\"](fs|path|os|child_process)['\"]"), "Node.js 모듈 사용"},
            {GameInfo.Level.MED, Pattern.compile("\\bnw\\.(Window|gui|App)\\b|require\\s*\\(\\s*['\"]nw\\.gui['\"]"), "NW.js 전용 API 사용"},
            {GameInfo.Level.HIGH, Pattern.compile("child_process"), "외부 프로세스 실행"},
            {GameInfo.Level.MED, Pattern.compile("greenworks|steamworks"), "Steam 연동"},
    };
    private static final Pattern PLUGIN_ENTRY = Pattern.compile(
            "\\{[^{}]*?\"name\"\\s*:\\s*\"([^\"]+)\"[^{}]*?\"status\"\\s*:\\s*(true|false)", Pattern.DOTALL);

    private static void analyzeMv(GameInfo g) {
        String sys = Text.readText(f(g.baseDir, "data/System.json"));
        if (sys != null) {
            Matcher m = Pattern.compile("\"gameTitle\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(sys);
            if (m.find() && !m.group(1).isEmpty()) g.title = unescapeJson(m.group(1));
        }
        Set<String> enabled = null;
        String plugins = Text.readText(f(g.baseDir, "js/plugins.js"));
        if (plugins != null) {
            enabled = new HashSet<>();
            Matcher m = PLUGIN_ENTRY.matcher(plugins);
            while (m.find()) if (m.group(2).equals("true")) enabled.add(m.group(1));
            g.notes.add("활성 플러그인 " + enabled.size() + "개 검사");
        }
        File[] js = f(g.baseDir, "js/plugins").listFiles((d, n) -> n.endsWith(".js"));
        if (js != null) {
            Arrays.sort(js);
            for (File p : js) {
                String name = p.getName().substring(0, p.getName().length() - 3);
                if (enabled != null && !enabled.contains(name)) continue;
                String code = Text.readText(p);
                if (code == null) continue;
                GameInfo.Level worst = null;
                Set<String> hits = new TreeSet<>();
                for (Object[] pat : MV_PATTERNS) {
                    if (((Pattern) pat[1]).matcher(code).find()) {
                        hits.add((String) pat[2]);
                        GameInfo.Level lv = (GameInfo.Level) pat[0];
                        if (worst == null || lv.ordinal() > worst.ordinal()) worst = lv;
                    }
                }
                if (worst != null) g.add(worst, "[" + name + "] " + String.join(", ", hits));
            }
        }
        if (!f(g.baseDir, "index.html").isFile()) g.add(GameInfo.Level.HIGH, "index.html 없음");
        if (g.worst() == GameInfo.Level.MED) {
            g.notes.add("Node/NW 의존 플러그인은 브라우저 환경에서 건너뛰도록 작성된 경우가 많음 — 실패 시 Winlator");
        }
    }

    private static String unescapeJson(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                if (n == 'u' && i + 4 < s.length()) {
                    b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                    i += 4;
                } else if (n == 'n') b.append('\n');
                else if (n == 't') b.append('\t');
                else b.append(n);
            } else b.append(c);
        }
        return b.toString();
    }

    // ─── 공통 ───────────────────────────────────────────────

    /** 게임 파일에서 읽은 제목은 신뢰할 수 없으므로 제어문자 제거·길이 제한 */
    static String cleanTitle(String t, String fallback) {
        if (t == null) return fallback;
        String c = t.replaceAll("[\\p{Cntrl}\\p{Cf}]", " ").replaceAll("\\s+", " ").trim();
        if (c.length() > 80) c = c.substring(0, 80);
        return c.isEmpty() ? fallback : c;
    }

    public static File mainExe(File root) {
        File[] exes = root.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".exe") && !EXE_SKIP.matcher(n).matches());
        if (exes == null || exes.length == 0) return null;
        for (String pref : new String[]{"Game.exe", "RPG_RT.exe", "nw.exe"}) {
            for (File e : exes) if (e.getName().equalsIgnoreCase(pref)) return e;
        }
        File best = exes[0];
        for (File e : exes) if (e.length() > best.length()) best = e;
        return best;
    }

    private static File f(File base, String rel) {
        return new File(base, rel);
    }

    private static boolean any(File dir, String ext) {
        return first(dir, ext) != null;
    }

    private static File first(File dir, String ext) {
        File[] fs = dir.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(ext));
        return fs == null || fs.length == 0 ? null : fs[0];
    }

    private static boolean anyPrefix(File dir, String prefix) {
        File[] fs = dir.listFiles((d, n) -> n.startsWith(prefix) && n.toLowerCase(Locale.ROOT).endsWith(".dll"));
        return fs != null && fs.length > 0;
    }

    private static boolean hasUnityData(File root) {
        File[] fs = root.listFiles(x -> x.isDirectory() && x.getName().endsWith("_Data"));
        if (fs == null) return false;
        for (File d : fs) if (f(d, "Managed").isDirectory() || f(d, "globalgamemanagers").isFile()) return true;
        return false;
    }

    private static String join(List<String> xs, int max) {
        return String.join(", ", xs.subList(0, Math.min(max, xs.size())));
    }
}
