package io.tsukurubox.launcher;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * RPG Maker MV/MZ, TyranoBuilder 등 HTML5 게임 러너.
 *
 * 게임마다 가상의 https 호스트(g<해시>.tsukurubox.invalid)를 부여하고, 그 호스트로 가는 요청을
 * 게임 폴더의 파일로 응답한다. 이렇게 하면
 *  - 게임별로 localStorage 가 분리되어 세이브가 서로 덮어써지지 않고
 *  - file:// 제약(XHR/fetch 차단)이 없다.
 */
public class WebGameActivity extends Activity {
    public static final String EXTRA_BASE_DIR = "base_dir";
    public static final String EXTRA_TITLE = "title";
    private static final String TAG = "TsukuruWeb";

    private static final Map<String, String> MIME = new HashMap<>();

    static {
        String[][] m = {
                {"html", "text/html"}, {"htm", "text/html"}, {"js", "application/javascript"},
                {"mjs", "application/javascript"}, {"json", "application/json"}, {"css", "text/css"},
                {"png", "image/png"}, {"jpg", "image/jpeg"}, {"jpeg", "image/jpeg"}, {"gif", "image/gif"},
                {"webp", "image/webp"}, {"svg", "image/svg+xml"}, {"bmp", "image/bmp"}, {"ico", "image/x-icon"},
                {"ogg", "audio/ogg"}, {"m4a", "audio/mp4"}, {"mp3", "audio/mpeg"}, {"wav", "audio/wav"},
                {"mp4", "video/mp4"}, {"webm", "video/webm"}, {"ogv", "video/ogg"},
                {"ttf", "font/ttf"}, {"otf", "font/otf"}, {"woff", "font/woff"}, {"woff2", "font/woff2"},
                {"wasm", "application/wasm"}, {"txt", "text/plain"}, {"ks", "text/plain"}, {"tjs", "text/plain"},
                {"xml", "application/xml"}, {"csv", "text/csv"},
        };
        for (String[] e : m) MIME.put(e[0], e[1]);
    }

    private WebView web;
    private File base;
    private String basePath;
    private String host;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String dir = getIntent().getStringExtra(EXTRA_BASE_DIR);
        if (dir == null) {
            finish();
            return;
        }
        base = new File(dir);
        try {
            basePath = base.getCanonicalPath();
        } catch (IOException e) {
            basePath = base.getAbsolutePath();
        }
        host = "g" + Integer.toHexString(basePath.hashCode()) + ".tsukurubox.invalid";

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        setContentView(web);
        hideSystemUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(false); // 오프라인 전용이라 불필요한 외부 조회 방지

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, m.sourceId() + ":" + m.lineNumber() + " " + m.message());
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                // 게임 폴더 밖(인터넷 포함)으로 나가는 요청은 모두 차단: 게임은 오프라인으로만 동작
                if (!host.equalsIgnoreCase(u.getHost()) || !"https".equalsIgnoreCase(u.getScheme())) {
                    Log.w(TAG, "blocked " + u);
                    return blocked();
                }
                return serve(u.getPath(), req.getRequestHeaders());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                // 게임 밖으로 나가는 링크는 열지 않음
                return !host.equalsIgnoreCase(req.getUrl().getHost());
            }
        });

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        if (title != null) setTitle(title);
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("https://" + host + "/index.html");
    }

    // ─── 파일 서빙 ──────────────────────────────────────────

    private WebResourceResponse serve(String path, Map<String, String> reqHeaders) {
        if (path == null || path.isEmpty() || path.equals("/")) path = "/index.html";
        File f = resolve(path);
        if (f == null) {
            Log.w(TAG, "404 " + path);
            WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8",
                    new ByteArrayInputStream(new byte[0]));
            r.setStatusCodeAndReasonPhrase(404, "Not Found");
            return r;
        }
        String mime = mimeOf(f.getName());
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-cache");
        headers.put("Accept-Ranges", "bytes");
        long len = f.length();
        try {
            String range = header(reqHeaders, "Range");
            if (range != null && range.startsWith("bytes=")) {
                String[] p = range.substring(6).split(",")[0].split("-", 2);
                long start = p[0].isEmpty() ? Math.max(0, len - Long.parseLong(p[1])) : Long.parseLong(p[0]);
                long end = (p.length > 1 && !p[1].isEmpty() && !p[0].isEmpty()) ? Long.parseLong(p[1]) : len - 1;
                end = Math.min(end, len - 1);
                if (start > end || start >= len) {
                    WebResourceResponse r = new WebResourceResponse(mime, null, new ByteArrayInputStream(new byte[0]));
                    headers.put("Content-Range", "bytes */" + len);
                    r.setStatusCodeAndReasonPhrase(416, "Range Not Satisfiable");
                    r.setResponseHeaders(headers);
                    return r;
                }
                headers.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
                headers.put("Content-Length", String.valueOf(end - start + 1));
                return new WebResourceResponse(mime, null, 206, "Partial Content", headers,
                        new RangeStream(f, start, end - start + 1));
            }
            headers.put("Content-Length", String.valueOf(len));
            return new WebResourceResponse(mime, charsetOf(mime), 200, "OK", headers, new FileInputStream(f));
        } catch (Exception e) {
            Log.w(TAG, "serve failed " + path, e);
            return blocked();
        }
    }

    private static WebResourceResponse blocked() {
        WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
        r.setStatusCodeAndReasonPhrase(403, "Forbidden");
        return r;
    }

    /** base 밖으로 나가는 경로 차단 + 대소문자 무시 폴백 */
    private File resolve(String path) {
        File f = new File(base, path);
        if (!f.isFile()) f = resolveIgnoreCase(path);
        if (f == null) return null;
        try {
            String c = f.getCanonicalPath();
            if (!c.equals(basePath) && !c.startsWith(basePath + File.separator)) return null;
        } catch (IOException e) {
            return null;
        }
        return f;
    }

    private File resolveIgnoreCase(String path) {
        File cur = base;
        for (String seg : path.split("/")) {
            if (seg.isEmpty() || seg.equals(".")) continue;
            if (seg.equals("..")) return null;
            File exact = new File(cur, seg);
            if (exact.exists()) {
                cur = exact;
                continue;
            }
            String[] names = cur.list();
            if (names == null) return null;
            File found = null;
            for (String n : names) {
                if (n.equalsIgnoreCase(seg)) {
                    found = new File(cur, n);
                    break;
                }
            }
            if (found == null) return null;
            cur = found;
        }
        return cur.isFile() ? cur : null;
    }

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        String ext = dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
        String m = MIME.get(ext);
        return m != null ? m : "application/octet-stream";
    }

    private static String charsetOf(String mime) {
        return mime.startsWith("text/") || mime.endsWith("javascript") || mime.endsWith("json") ? "utf-8" : null;
    }

    private static String header(Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return e.getValue();
        }
        return null;
    }

    /** 파일의 [start, start+length) 구간만 읽는 스트림 */
    private static final class RangeStream extends InputStream {
        private final RandomAccessFile raf;
        private long remaining;

        RangeStream(File f, long start, long length) throws IOException {
            raf = new RandomAccessFile(f, "r");
            raf.seek(start);
            remaining = length;
        }

        @Override
        public int read() throws IOException {
            if (remaining <= 0) return -1;
            int b = raf.read();
            if (b >= 0) remaining--;
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (remaining <= 0) return -1;
            int n = raf.read(b, off, (int) Math.min(len, remaining));
            if (n > 0) remaining -= n;
            return n;
        }

        @Override
        public void close() throws IOException {
            raf.close();
        }
    }

    // ─── 생명주기 ──────────────────────────────────────────

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.onPause();
            web.pauseTimers();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("게임을 종료할까요?\n(저장하지 않은 진행 상황은 사라집니다)")
                .setPositiveButton("종료", (d, w) -> finish())
                .setNegativeButton("계속", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            web.destroy();
            web = null;
        }
        super.onDestroy();
        if (isFinishing()) {
            // 별도 프로세스(:web)이므로 WebView 메모리를 확실히 반환
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }
}
