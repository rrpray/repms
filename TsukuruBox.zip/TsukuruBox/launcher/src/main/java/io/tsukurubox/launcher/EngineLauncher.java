package io.tsukurubox.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.tsukurubox.core.GameInfo;
import io.tsukurubox.core.Runner;

/** 같은 APK 안에 들어 있는 각 엔진의 Activity 를 실행한다. (클래스 이름으로 호출 → 컴파일 의존성 없음) */
final class EngineLauncher {
    private EngineLauncher() {}

    static final String EASYRPG_PLAYER = "org.easyrpg.player.player.EasyRpgPlayerActivity";
    static final String EASYRPG_SETTINGS = "org.easyrpg.player.settings.SettingsMainActivity";
    static final String MKXP_ACTIVITY = "com.hatkid.mkxpz.MainActivity";
    static final String WINE_BRIDGE = "io.tsukurubox.bridge.WinlatorBridgeActivity";
    static final String WINLATOR_MAIN = "com.winlator.cmod.MainActivity";

    static File appRoot() {
        return new File(Environment.getExternalStorageDirectory(), "TsukuruBox");
    }

    static boolean isAvailable(String className) {
        try {
            // initialize=false: 엔진 클래스의 static 초기화(네이티브 로드 등)를 런처 프로세스에서 실행하지 않음
            Class.forName(className, false, EngineLauncher.class.getClassLoader());
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean mkxpAvailable() {
        return isAvailable(MKXP_ACTIVITY);
    }

    static void launch(Activity a, GameInfo g, Runner runner, String wineLocale) {
        launch(a, g, runner, wineLocale, true);
    }

    static void launch(Activity a, GameInfo g, Runner runner, String wineLocale, boolean virtualPad) {
        Intent i;
        switch (runner) {
            case EASYRPG:
                i = easyRpg(a, g);
                break;
            case MKXP:
                i = component(a, MKXP_ACTIVITY);
                i.putExtra("game_path", g.dir.getAbsolutePath());
                break;
            case WEB:
                i = new Intent(a, WebGameActivity.class);
                i.putExtra(WebGameActivity.EXTRA_BASE_DIR, g.baseDir.getAbsolutePath());
                i.putExtra(WebGameActivity.EXTRA_TITLE, g.title);
                break;
            case WINE:
            default:
                if (g.exe == null) {
                    Toast.makeText(a, "실행 파일(.exe)이 없습니다", Toast.LENGTH_LONG).show();
                    return;
                }
                i = component(a, WINE_BRIDGE);
                i.putExtra("exe_path", g.exe.getAbsolutePath());
                i.putExtra("title", g.title);
                i.putExtra("lc_all", wineLocale);
                i.putExtra("virtual_pad", virtualPad);
                break;
        }
        start(a, i, runner.label);
    }

    static void openClass(Activity a, String className, String label) {
        start(a, component(a, className), label);
    }

    private static void start(Activity a, Intent i, String label) {
        try {
            a.startActivity(i);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(a, label + " 엔진이 이 빌드에 포함되지 않았습니다", Toast.LENGTH_LONG).show();
        }
    }

    private static Intent component(Activity a, String className) {
        Intent i = new Intent();
        i.setClassName(a.getPackageName(), className);
        return i;
    }

    /** EasyRPG GameBrowserHelper.launchGame 과 같은 방식으로 인자를 구성 (standalone = 일반 파일 경로 사용) */
    private static Intent easyRpg(Activity a, GameInfo g) {
        String path = g.dir.getAbsolutePath();
        File configDir = new File(a.getExternalFilesDir(null), "easyrpg");
        //noinspection ResultOfMethodCallIgnored
        configDir.mkdirs();
        String logFile = new File(configDir, "easyrpg-player.log").getAbsolutePath();

        List<String> args = new ArrayList<>();
        args.add("--project-path");
        args.add(path);
        args.add("--save-path");
        args.add(path);
        if (g.encoding != null) {
            args.add("--encoding");
            args.add(g.encoding);
        }
        File rtp = new File(appRoot(), "rtp/" + (g.engine == io.tsukurubox.core.Engine.RM2003 ? "2003" : "2000"));
        String[] rtpFiles = rtp.list();
        if (rtpFiles != null && rtpFiles.length > 0) {
            args.add("--rtp-path");
            args.add(rtp.getAbsolutePath());
        }
        args.add("--config-path");
        args.add(configDir.getAbsolutePath());
        args.add("--log-file");
        args.add(logFile);

        Intent i = component(a, EASYRPG_PLAYER);
        i.putExtra("project_path", path);
        i.putExtra("save_path", path);
        i.putExtra("log_file", logFile);
        i.putExtra("command_line", args.toArray(new String[0]));
        i.putExtra("standalone_mode", true);
        return i;
    }
}
