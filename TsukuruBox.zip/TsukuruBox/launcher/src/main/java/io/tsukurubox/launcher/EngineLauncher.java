package io.tsukurubox.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.tsukurubox.core.GameInfo;
import io.tsukurubox.core.Runner;

/** 같은 APK 안에 들어 있는 각 엔진의 Activity 를 실행한다. (클래스 이름으로 호출 → 컴파일 의존성 없음) */
final class EngineLauncher {
    private EngineLauncher() {}

    static final String EASYRPG_PLAYER = "org.easyrpg.player.player.EasyRpgPlayerActivity";
    static final String EASYRPG_SETTINGS = "org.easyrpg.player.settings.SettingsMainActivity";
    static final String MKXP_ACTIVITY = "com.hatkid.mkxpz.MainActivity";
    static final String WINE_BRIDGE = "io.tsukurubox.bridge.WinlatorBridgeActivity";
    static final String WINLATOR_MAIN = "com.winlator.cmod.MainActivity";
    static final String DIAGNOSTICS = "io.tsukurubox.bridge.DiagnosticsActivity";
    static final String KIRIKIRI_ACTIVITY = "org.tvp.kirikiri2.TsukuruKirikiriActivity";

    private static boolean crashHandlerInstalled;

    /** 앱이 튕기면 원인을 /sdcard/TsukuruBox/crash.txt 에 남긴다 (진단 화면에서 표시) */
    static synchronized void installCrashLogger() {
        if (crashHandlerInstalled) return;
        crashHandlerInstalled = true;
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try (java.io.PrintWriter w = new java.io.PrintWriter(new java.io.FileWriter(new File(logDir(), "crash.txt"), true))) {
                w.println("---- " + new java.util.Date() + " [" + android.app.Application.getProcessName() + " / " + t.getName() + "]");
                e.printStackTrace(w);
            } catch (Throwable ignored) {
            }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static File appRoot() {
        return new File(Environment.getExternalStorageDirectory(), "TsukuruBox");
    }

    /** 앱 기록 파일(crash.txt, last_launch.txt, diagnostics.txt)은 TsukuruBox/logs 에 모은다 */
    static File logDir() {
        File d = new File(appRoot(), "logs");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    static boolean isAvailable(String className) {
        try {
            // initialize=false: 엔진 클래스의 static 초기화(네이티브 로드 등)를 런처 프로세스에서 실행하지 않음
            Class.forName(className, false, EngineLauncher.class.getClassLoader());
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean mkxpAvailable() {
        return isAvailable(MKXP_ACTIVITY);
    }

    /** 엔진에 맞는 기본값으로 실행: 가상 패드(비주얼 노벨류는 끔), 화면 방식(3D 엔진은 컨테이너 설정 그대로) */
    static void launch(Activity a, GameInfo g, Runner runner, String wineLocale) {
        launch(a, g, runner, wineLocale, defaultPad(g.engine), !is3d(g.engine));
    }

    static void launch(Activity a, GameInfo g, Runner runner, String wineLocale, boolean virtualPad) {
        launch(a, g, runner, wineLocale, virtualPad, !is3d(g.engine));
    }

    /** 터치·클릭으로 진행하는 엔진은 가상 패드를 띄우지 않는다 (화면 터치 = 클릭) */
    static boolean defaultPad(io.tsukurubox.core.Engine e) {
        switch (e) {
            case KIRIKIRI:
            case RENPY:
            case TYRANO:
                return false;
            default:
                return true;
        }
    }

    /** 3D 엔진은 WineD3D 로 바꾸면 느려지므로 컨테이너 화면 방식(DXVK)을 그대로 쓴다 */
    static boolean is3d(io.tsukurubox.core.Engine e) {
        switch (e) {
            case UNITY:
            case GODOT:
            case XNA:
                return true;
            default:
                return false;
        }
    }

    /** safeGraphics: Winlator 화면 방식을 WineD3D 로 (Mali 등에서 DXVK 검은 화면 방지). false 면 컨테이너 설정 그대로 */
    static void launch(Activity a, GameInfo g, Runner runner, String wineLocale, boolean virtualPad, boolean safeGraphics) {
        Intent i;
        switch (runner) {
            case EASYRPG:
                i = easyRpg(a, g);
                break;
            case MKXP:
                i = component(a, MKXP_ACTIVITY);
                i.putExtra("game_path", g.dir.getAbsolutePath());
                break;
            case WEB:
                i = new Intent(a, WebGameActivity.class);
                i.putExtra(WebGameActivity.EXTRA_BASE_DIR, g.baseDir.getAbsolutePath());
                i.putExtra(WebGameActivity.EXTRA_TITLE, g.title);
                break;
            case KIRIKIROID:
                if (isAvailable(KIRIKIRI_ACTIVITY)) {
                    // 앱에 내장된 Kirikiroid2 로 바로 시작 (파일 선택 화면 없이)
                    i = component(a, KIRIKIRI_ACTIVITY);
                    i.putExtra("game_path", g.dir.getAbsolutePath());
                    break;
                }
                KirikiroidHelper.launch(a, g);
                return;
            case WINE:
            default:
                if (g.exe == null) {
                    Toast.makeText(a, "실행 파일(.exe)이 없습니다", Toast.LENGTH_LONG).show();
                    return;
                }
                i = component(a, WINE_BRIDGE);
                i.putExtra("exe_path", g.exe.getAbsolutePath());
                i.putExtra("title", g.title);
                i.putExtra("lc_all", wineLocale);
                i.putExtra("virtual_pad", virtualPad);
                i.putExtra("safe_graphics", safeGraphics);
                break;
        }
        start(a, i, runner.label);
    }

    static void openClass(Activity a, String className, String label) {
        start(a, component(a, className), label);
    }

    private static void start(Activity a, Intent i, String label) {
        try {
            a.startActivity(i);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(a, label + " 엔진이 이 빌드에 포함되지 않았습니다", Toast.LENGTH_LONG).show();
        }
    }

    private static Intent component(Activity a, String className) {
        Intent i = new Intent();
        i.setClassName(a.getPackageName(), className);
        return i;
    }

    /** EasyRPG GameBrowserHelper.launchGame 과 같은 방식으로 인자를 구성 (standalone = 일반 파일 경로 사용) */
    private static Intent easyRpg(Activity a, GameInfo g) {
        String path = g.dir.getAbsolutePath();
        File configDir = new File(a.getExternalFilesDir(null), "easyrpg");
        //noinspection ResultOfMethodCallIgnored
        configDir.mkdirs();
        String logFile = new File(configDir, "easyrpg-player.log").getAbsolutePath();

        List<String> args = new ArrayList<>();
        args.add("--project-path");
        args.add(path);
        args.add("--save-path");
        args.add(path);
        if (g.encoding != null) {
            args.add("--encoding");
            args.add(g.encoding);
        }
        File rtp = new File(appRoot(), "rtp/" + (g.engine == io.tsukurubox.core.Engine.RM2003 ? "2003" : "2000"));
        String[] rtpFiles = rtp.list();
        if (rtpFiles != null && rtpFiles.length > 0) {
            args.add("--rtp-path");
            args.add(rtp.getAbsolutePath());
        }
        args.add("--config-path");
        args.add(configDir.getAbsolutePath());
        args.add("--log-file");
        args.add(logFile);

        Intent i = component(a, EASYRPG_PLAYER);
        i.putExtra("project_path", path);
        i.putExtra("save_path", path);
        i.putExtra("log_file", logFile);
        i.putExtra("command_line", args.toArray(new String[0]));
        i.putExtra("standalone_mode", true);
        return i;
    }
}
