package io.tsukurubox.pad;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 게임 화면 위에 올리는 가상 패드 + 가상 키보드 + 사용자 지정 키.
 * 엔진마다 키를 보내는 방법만 다르므로 {@link KeySink} 로 받는다 (HTML5 러너: WebView, 吉里吉里: 네이티브 함수).
 *
 * 오른쪽 위 작은 버튼: [패드] 보이기/숨기기, [⌨] 전체 키보드, [＋] 내 키 추가.
 * 내가 추가한 키는 오른쪽에 세로로 놓이고, 길게 누르면 삭제. 설정은 profile 별로 저장.
 */
public class VirtualPad extends FrameLayout {

    public interface KeySink {
        void key(int keyCode, boolean down);
    }

    private static final String PREFS = "tsukurubox_pad";
    private static final int ALPHA = 150;

    private final KeySink sink;
    private final String profile;
    private final SharedPreferences prefs;
    private final FrameLayout padLayer;
    private final LinearLayout customColumn;
    private View keyboardPanel;

    /** 기본 버튼: {라벨, 키코드} */
    private final int[][] mainKeys;
    private final String[] mainLabels;

    public VirtualPad(Context ctx, String profile, KeySink sink) {
        super(ctx);
        this.sink = sink;
        this.profile = profile;
        this.prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // 빈 곳의 터치는 게임으로 그대로 통과 (FrameLayout 은 자식이 받지 않은 터치를 소비하지 않음)
        setClickable(false);

        if ("kirikiri".equals(profile)) {
            mainLabels = new String[]{"진행", "메뉴", "스킵", "숨김"};
            mainKeys = new int[][]{{KeyEvent.KEYCODE_ENTER}, {KeyEvent.KEYCODE_ESCAPE},
                    {KeyEvent.KEYCODE_CTRL_LEFT}, {KeyEvent.KEYCODE_SPACE}};
        } else {
            mainLabels = new String[]{"결정", "취소", "대시", "메뉴"};
            mainKeys = new int[][]{{KeyEvent.KEYCODE_ENTER}, {KeyEvent.KEYCODE_ESCAPE},
                    {KeyEvent.KEYCODE_SHIFT_LEFT}, {KeyEvent.KEYCODE_X}};
        }

        padLayer = new FrameLayout(ctx);
        addView(padLayer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        buildDpad();
        buildButtons();

        customColumn = new LinearLayout(ctx);
        customColumn.setOrientation(LinearLayout.VERTICAL);
        LayoutParams cl = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);
        cl.setMarginEnd(dp(8));
        cl.topMargin = -dp(40);
        padLayer.addView(customColumn, cl);
        reloadCustom();

        buildToolbar();
        padLayer.setVisibility(prefs.getBoolean(profile + "_visible", !"kirikiri".equals(profile)) ? VISIBLE : GONE);
    }

    // ─── 기본 패드 ──────────────────────────────────────────

    /**
     * 십자키: 한 덩어리로 터치를 받아, 손가락을 떼지 않고 미끄러뜨려도 방향이 바로 바뀐다.
     * 중심에서 대각선 쪽이면 두 방향을 같이 누른다 (8방향). 중심 근처는 입력 없음.
     */
    @SuppressLint("ClickableViewAccessibility")
    private void buildDpad() {
        int s = dp(54);
        final int size = s * 3;
        FrameLayout d = new FrameLayout(getContext());
        LayoutParams lp = new LayoutParams(size, size, Gravity.START | Gravity.BOTTOM);
        lp.leftMargin = dp(16);
        lp.bottomMargin = dp(16);
        padLayer.addView(d, lp);

        final int[] codes = {KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT};
        final String[] labels = {"▲", "▼", "◀", "▶"};
        final int[][] pos = {{s, 0}, {s, s * 2}, {0, s}, {s * 2, s}};
        final GradientDrawable[] bgs = new GradientDrawable[4];
        for (int i = 0; i < 4; i++) {
            TextView t = new TextView(getContext());
            t.setText(labels[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(Color.WHITE);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            bgs[i] = new GradientDrawable();
            bgs[i].setCornerRadius(dp(12));
            bgs[i].setColor(Color.argb(ALPHA / 2, 0, 0, 0));
            bgs[i].setStroke(dp(2), Color.argb(ALPHA, 255, 255, 255));
            t.setBackground(bgs[i]);
            LayoutParams bl = new LayoutParams(s - dp(4), s - dp(4));
            bl.leftMargin = pos[i][0] + dp(2);
            bl.topMargin = pos[i][1] + dp(2);
            d.addView(t, bl);
        }

        final boolean[] held = new boolean[4];
        final float dead = s * 0.35f;
        d.setOnTouchListener((v, e) -> {
            boolean[] want = new boolean[4];
            int act = e.getActionMasked();
            if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
                float dx = e.getX() - size / 2f, dy = e.getY() - size / 2f;
                if (Math.hypot(dx, dy) > dead) {
                    double ang = Math.toDegrees(Math.atan2(dy, dx)); // 0=오른쪽, 90=아래
                    // 각 방향 ±67.5° 범위 → 방향 사이 45° 는 두 키를 같이 누름
                    want[3] = Math.abs(ang) < 67.5;
                    want[2] = Math.abs(ang) > 112.5;
                    want[1] = ang > 22.5 && ang < 157.5;
                    want[0] = ang < -22.5 && ang > -157.5;
                }
            }
            for (int i = 0; i < 4; i++) {
                if (want[i] != held[i]) {
                    held[i] = want[i];
                    bgs[i].setColor(want[i] ? Color.argb(ALPHA, 255, 255, 255) : Color.argb(ALPHA / 2, 0, 0, 0));
                    send(codes[i], want[i]);
                }
            }
            return true;
        });
    }

    private void buildButtons() {
        int b = dp(64), sm = dp(48);
        FrameLayout r = new FrameLayout(getContext());
        LayoutParams lp = new LayoutParams(b * 2 + dp(20), b * 2 + dp(10), Gravity.END | Gravity.BOTTOM);
        lp.rightMargin = dp(16);
        lp.bottomMargin = dp(16);
        padLayer.addView(r, lp);
        addKey(r, mainLabels[0], mainKeys[0][0], b, b, b + dp(20), dp(10));   // 결정 (오른쪽)
        addKey(r, mainLabels[1], mainKeys[1][0], b, b, 0, b + dp(10) - dp(10)); // 취소 (왼쪽 아래)
        addKey(r, mainLabels[2], mainKeys[2][0], sm, sm, dp(8), 0);           // 대시/스킵 (왼쪽 위)
        addKey(r, mainLabels[3], mainKeys[3][0], sm, sm, b + dp(28), b + dp(14)); // 메뉴/숨김 (오른쪽 아래)
    }

    private void buildToolbar() {
        LinearLayout bar = new LinearLayout(getContext());
        bar.setOrientation(LinearLayout.HORIZONTAL);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.TOP);
        lp.topMargin = dp(6);
        lp.rightMargin = dp(6);
        addView(bar, lp);
        bar.addView(smallButton("패드", v -> {
            boolean show = padLayer.getVisibility() != VISIBLE;
            padLayer.setVisibility(show ? VISIBLE : GONE);
            prefs.edit().putBoolean(profile + "_visible", show).apply();
        }));
        bar.addView(smallButton("⌨", v -> toggleKeyboard()));
        bar.addView(smallButton("＋", v -> addCustomDialog()));
    }

    // ─── 사용자 지정 키 ─────────────────────────────────────

    private void reloadCustom() {
        customColumn.removeAllViews();
        List<String[]> list = loadCustom();
        for (int i = 0; i < list.size(); i++) {
            final int idx = i;
            String[] e = list.get(i);
            int code;
            try {
                code = Integer.parseInt(e[1]);
            } catch (NumberFormatException ex) {
                continue;
            }
            TextView t = keyView(e[0], code, () -> {
                new AlertDialog.Builder(getContext())
                        .setMessage("'" + e[0] + "' 키를 지울까요?")
                        .setPositiveButton("지우기", (d, w) -> {
                            List<String[]> l = loadCustom();
                            if (idx < l.size()) l.remove(idx);
                            saveCustom(l);
                            reloadCustom();
                        })
                        .setNegativeButton("취소", null)
                        .show();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(44));
            lp.bottomMargin = dp(6);
            customColumn.addView(t, lp);
        }
    }

    private List<String[]> loadCustom() {
        List<String[]> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString(profile + "_custom", "[]"));
            for (int i = 0; i < a.length() && i < 12; i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new String[]{o.getString("label"), String.valueOf(o.getInt("key"))});
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void saveCustom(List<String[]> list) {
        JSONArray a = new JSONArray();
        try {
            for (String[] e : list) {
                JSONObject o = new JSONObject();
                o.put("label", e[0]);
                o.put("key", Integer.parseInt(e[1]));
                a.put(o);
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(profile + "_custom", a.toString()).apply();
    }

    private void addCustomDialog() {
        Map<String, Integer> keys = allKeys();
        String[] names = keys.keySet().toArray(new String[0]);
        new AlertDialog.Builder(getContext())
                .setTitle("추가할 키 (최대 12개, 길게 누르면 삭제)")
                .setItems(names, (d, which) -> {
                    String name = names[which];
                    EditText et = new EditText(getContext());
                    et.setText(name);
                    et.setSelection(name.length());
                    new AlertDialog.Builder(getContext())
                            .setTitle("버튼에 표시할 이름")
                            .setView(et)
                            .setPositiveButton("추가", (d2, w2) -> {
                                String label = et.getText().toString().trim();
                                if (label.isEmpty()) label = name;
                                if (label.length() > 6) label = label.substring(0, 6);
                                List<String[]> l = loadCustom();
                                if (l.size() >= 12) l.remove(0);
                                l.add(new String[]{label, String.valueOf(keys.get(name))});
                                saveCustom(l);
                                reloadCustom();
                                padLayer.setVisibility(VISIBLE);
                            })
                            .setNegativeButton("취소", null)
                            .show();
                })
                .show();
    }

    // ─── 전체 키보드 ────────────────────────────────────────

    private void toggleKeyboard() {
        if (keyboardPanel != null) {
            removeView(keyboardPanel);
            keyboardPanel = null;
            return;
        }
        String[][] rows = {
                {"Esc", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"},
                {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "⌫"},
                {"Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]"},
                {"Caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "'", "Enter"},
                {"Shift", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "↑", "Del"},
                {"Ctrl", "Alt", "Space", "Home", "End", "PgUp", "PgDn", "Ins", "", "", "←", "↓", "→"},
        };
        Map<String, Integer> keys = allKeys();
        GridLayout g = new GridLayout(getContext());
        g.setColumnCount(13);
        g.setBackgroundColor(Color.argb(200, 20, 20, 20));
        int w = Math.max(dp(30), (getResources().getDisplayMetrics().widthPixels - dp(16)) / 13);
        for (String[] row : rows) {
            for (String k : row) {
                View v;
                if (k.isEmpty() || keys.get(k) == null) {
                    v = new View(getContext());
                } else {
                    v = keyView(k, keys.get(k), null);
                    ((TextView) v).setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                }
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = w - dp(2);
                lp.height = dp(38);
                lp.setMargins(dp(1), dp(1), dp(1), dp(1));
                g.addView(v, lp);
            }
        }
        ScrollView sv = new ScrollView(getContext());
        sv.addView(g);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        keyboardPanel = sv;
        addView(sv, lp);
    }

    /** 키 선택 목록 (이름 → 안드로이드 키코드). 엔진 쪽이 안드로이드 키코드를 Windows/JS 키로 바꾼다 */
    public static Map<String, Integer> allKeys() {
        Map<String, Integer> m = new LinkedHashMap<>();
        m.put("Enter", KeyEvent.KEYCODE_ENTER);
        m.put("Esc", KeyEvent.KEYCODE_ESCAPE);
        m.put("Space", KeyEvent.KEYCODE_SPACE);
        m.put("Shift", KeyEvent.KEYCODE_SHIFT_LEFT);
        m.put("Ctrl", KeyEvent.KEYCODE_CTRL_LEFT);
        m.put("Alt", KeyEvent.KEYCODE_ALT_LEFT);
        m.put("Tab", KeyEvent.KEYCODE_TAB);
        m.put("Caps", KeyEvent.KEYCODE_CAPS_LOCK);
        m.put("⌫", KeyEvent.KEYCODE_DEL);
        m.put("Del", KeyEvent.KEYCODE_FORWARD_DEL);
        m.put("Ins", KeyEvent.KEYCODE_INSERT);
        m.put("Home", KeyEvent.KEYCODE_MOVE_HOME);
        m.put("End", KeyEvent.KEYCODE_MOVE_END);
        m.put("PgUp", KeyEvent.KEYCODE_PAGE_UP);
        m.put("PgDn", KeyEvent.KEYCODE_PAGE_DOWN);
        m.put("↑", KeyEvent.KEYCODE_DPAD_UP);
        m.put("↓", KeyEvent.KEYCODE_DPAD_DOWN);
        m.put("←", KeyEvent.KEYCODE_DPAD_LEFT);
        m.put("→", KeyEvent.KEYCODE_DPAD_RIGHT);
        for (char c = 'A'; c <= 'Z'; c++) m.put(String.valueOf(c), KeyEvent.KEYCODE_A + (c - 'A'));
        for (char c = '0'; c <= '9'; c++) m.put(String.valueOf(c), KeyEvent.KEYCODE_0 + (c - '0'));
        for (int i = 1; i <= 12; i++) m.put("F" + i, KeyEvent.KEYCODE_F1 + i - 1);
        m.put("-", KeyEvent.KEYCODE_MINUS);
        m.put("=", KeyEvent.KEYCODE_EQUALS);
        m.put("[", KeyEvent.KEYCODE_LEFT_BRACKET);
        m.put("]", KeyEvent.KEYCODE_RIGHT_BRACKET);
        m.put(";", KeyEvent.KEYCODE_SEMICOLON);
        m.put("'", KeyEvent.KEYCODE_APOSTROPHE);
        m.put(",", KeyEvent.KEYCODE_COMMA);
        m.put(".", KeyEvent.KEYCODE_PERIOD);
        m.put("/", KeyEvent.KEYCODE_SLASH);
        return m;
    }

    // ─── 공통 ───────────────────────────────────────────────

    private void addKey(FrameLayout parent, String label, int code, int w, int h, int x, int y) {
        LayoutParams lp = new LayoutParams(w - dp(4), h - dp(4));
        lp.leftMargin = x + dp(2);
        lp.topMargin = y + dp(2);
        parent.addView(keyView(label, code, null), lp);
    }

    /** 누르고 있는 동안 키가 눌린 상태 (손가락을 떼면 키를 뗌) */
    @SuppressLint("ClickableViewAccessibility")
    private TextView keyView(String label, int code, Runnable onLongPress) {
        TextView t = new TextView(getContext());
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setColor(Color.argb(ALPHA / 2, 0, 0, 0));
        bg.setStroke(dp(2), Color.argb(ALPHA, 255, 255, 255));
        t.setBackground(bg);
        final boolean[] down = {false};
        final Runnable longPress = onLongPress == null ? null : () -> {
            if (down[0]) {
                down[0] = false;
                bg.setColor(Color.argb(ALPHA / 2, 0, 0, 0));
                send(code, false);
            }
            onLongPress.run();
        };
        t.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = true;
                    bg.setColor(Color.argb(ALPHA, 255, 255, 255));
                    send(code, true);
                    if (longPress != null) v.postDelayed(longPress, 1200);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (longPress != null) v.removeCallbacks(longPress);
                    if (down[0]) {
                        down[0] = false;
                        bg.setColor(Color.argb(ALPHA / 2, 0, 0, 0));
                        send(code, false);
                    }
                    return true;
                default:
                    return true;
            }
        });
        return t;
    }

    private void send(int code, boolean down) {
        try {
            sink.key(code, down);
        } catch (Throwable ignored) {
        }
    }

    private TextView smallButton(String label, OnClickListener l) {
        TextView t = new TextView(getContext());
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(4), dp(10), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(8));
        bg.setColor(Color.argb(120, 0, 0, 0));
        t.setBackground(bg);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32));
        lp.leftMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
