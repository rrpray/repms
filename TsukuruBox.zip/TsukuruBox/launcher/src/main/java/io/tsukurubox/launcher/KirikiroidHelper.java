package io.tsukurubox.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

import io.tsukurubox.core.GameInfo;

/**
 * 吉里吉里(Kirikiri) 게임은 안드로이드 전용 실행기 Kirikiroid2 로 넘긴다.
 * 없으면 공식 GitHub 릴리스(Kirikiroid2Yuri 1.3.9)에서 받아 SHA-256 을 확인한 뒤 시스템 설치 창을 띄운다.
 * Kirikiroid2 는 게임 경로를 인텐트로 받지 않으므로, 게임 폴더 경로를 클립보드에 넣고 안내한다.
 */
final class KirikiroidHelper {
    private KirikiroidHelper() {}

    /** 원본(zeas2)과 Yuri 릴리스 모두 이 패키지명, 소스 빌드판은 com.yuri.kirikiri2 */
    static final String[] PACKAGES = {"org.tvp.kirikiri2", "com.yuri.kirikiri2"};

    private static final String APK_URL =
            "https://github.com/YuriSizuku/Kirikiroid2Yuri/releases/download/1.3.9_yuri/Kirikiroid2_yuri_1.3.9.apk";
    private static final String APK_SHA256 = "782d85ed767ec8c07d69709b668275f3872ae6472b02343038538f011337c83d";
    private static final long APK_MAX = 64L * 1024 * 1024;
    private static final String ACTION_INSTALLED = "io.tsukurubox.KIRIKIROID_INSTALL_STATUS";

    static String installedPackage(Context c) {
        PackageManager pm = c.getPackageManager();
        for (String p : PACKAGES) {
            if (pm.getLaunchIntentForPackage(p) != null) return p;
        }
        return null;
    }

    static void launch(Activity a, GameInfo g) {
        String pkg = installedPackage(a);
        if (pkg == null) {
            new AlertDialog.Builder(a)
                    .setTitle("Kirikiroid2 가 필요합니다")
                    .setMessage("吉里吉里 게임은 안드로이드 전용 실행기 Kirikiroid2 로 실행합니다.\n\n"
                            + "공식 GitHub 릴리스(Kirikiroid2Yuri 1.3.9, 약 31MB)를 받아 설치할까요?\n"
                            + "받은 파일은 SHA-256 으로 원본과 같은지 확인한 뒤 설치 창을 띄웁니다.")
                    .setPositiveButton("받아서 설치", (d, w) -> downloadAndInstall(a))
                    .setNegativeButton("취소", null)
                    .show();
            return;
        }
        String path = g.dir.getAbsolutePath();
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("게임 폴더", path));
        new AlertDialog.Builder(a)
                .setTitle(g.title)
                .setMessage("Kirikiroid2 가 열리면 아래 폴더로 이동해 data.xp3 (또는 게임 exe)를 누르세요.\n"
                        + "한 번 열면 다음부터는 Kirikiroid2 첫 화면의 '최근' 목록에 나옵니다.\n\n"
                        + path + "\n\n(경로를 클립보드에 복사했습니다)")
                .setPositiveButton("Kirikiroid2 열기", (d, w) -> {
                    Intent i = a.getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i != null) a.startActivity(i);
                })
                .setNegativeButton("취소", null)
                .show();
    }

    // ─── 설치 ───────────────────────────────────────────────

    @SuppressWarnings("deprecation")
    private static void downloadAndInstall(Activity a) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(a, "'이 출처의 앱 설치 허용'을 켠 뒤 다시 눌러 주세요", Toast.LENGTH_LONG).show();
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + a.getPackageName())));
            return;
        }
        ProgressDialog pd = new ProgressDialog(a);
        pd.setMessage("Kirikiroid2 받는 중…");
        pd.setCancelable(false);
        pd.show();
        Handler ui = new Handler(Looper.getMainLooper());
        File apk = new File(a.getCacheDir(), "kirikiroid2.apk");
        new Thread(() -> {
            String err = null;
            try {
                download(apk, mb -> ui.post(() -> pd.setMessage("Kirikiroid2 받는 중… " + mb + "MB")));
                if (!APK_SHA256.equals(sha256(apk))) throw new IOException("파일이 공식 릴리스와 다릅니다 (SHA-256 불일치)");
            } catch (Exception e) {
                err = e.getMessage();
                //noinspection ResultOfMethodCallIgnored
                apk.delete();
            }
            final String error = err;
            ui.post(() -> {
                pd.dismiss();
                if (error != null) {
                    Toast.makeText(a, "받기 실패: " + error, Toast.LENGTH_LONG).show();
                    return;
                }
                try {
                    install(a, apk);
                } catch (Exception e) {
                    Toast.makeText(a, "설치 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    interface Progress {
        void mb(long mb);
    }

    private static void download(File dest, Progress p) throws IOException {
        String url = APK_URL;
        for (int hop = 0; hop < 5; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            try {
                int code = c.getResponseCode();
                if (code / 100 == 3) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null || !loc.startsWith("https://")) throw new IOException("잘못된 이동 주소");
                    url = loc;
                    continue;
                }
                if (code != 200) throw new IOException("HTTP " + code);
                try (InputStream in = new BufferedInputStream(c.getInputStream());
                     OutputStream out = new FileOutputStream(dest)) {
                    byte[] buf = new byte[64 * 1024];
                    long done = 0, shown = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        done += n;
                        if (done > APK_MAX) throw new IOException("파일이 너무 큼");
                        if (done - shown > (1 << 20)) {
                            shown = done;
                            p.mb(done >> 20);
                        }
                    }
                }
                return;
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("이동이 너무 많음");
    }

    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        StringBuilder b = new StringBuilder();
        for (byte x : md.digest()) b.append(String.format(Locale.ROOT, "%02x", x));
        return b.toString();
    }

    /** PackageInstaller 세션으로 설치 (FileProvider 불필요). 사용자 확인 창은 시스템이 띄운다 */
    private static void install(Activity a, File apk) throws Exception {
        PackageInstaller pi = a.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params =
                new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int id = pi.createSession(params);
        try (PackageInstaller.Session s = pi.openSession(id)) {
            try (InputStream in = new FileInputStream(apk);
                 OutputStream out = s.openWrite("kirikiroid2.apk", 0, apk.length())) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                s.fsync(out);
            }
            Context app = a.getApplicationContext();
            BroadcastReceiver r = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                    int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                    if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                        Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                        if (confirm != null) {
                            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            ctx.startActivity(confirm);
                        }
                        return;
                    }
                    try {
                        ctx.unregisterReceiver(this);
                    } catch (Exception ignored) {
                    }
                    //noinspection ResultOfMethodCallIgnored
                    apk.delete();
                    Toast.makeText(ctx, status == PackageInstaller.STATUS_SUCCESS
                                    ? "Kirikiroid2 설치 완료. 게임을 다시 누르세요."
                                    : "설치되지 않았습니다: " + intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE),
                            Toast.LENGTH_LONG).show();
                }
            };
            IntentFilter f = new IntentFilter(ACTION_INSTALLED);
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
            else app.registerReceiver(r, f);
            Intent cb = new Intent(ACTION_INSTALLED).setPackage(a.getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pend = PendingIntent.getBroadcast(app, id, cb, flags);
            s.commit(pend.getIntentSender());
        }
    }
}
