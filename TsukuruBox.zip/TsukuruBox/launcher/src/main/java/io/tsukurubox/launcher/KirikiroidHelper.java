package io.tsukurubox.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import io.tsukurubox.core.GameInfo;
import io.tsukurubox.core.Runner;

/**
 * 내장 吉里吉里 엔진이 빠진 빌드(엔진 빌드 실패 시 자동 제외)용 대체 경로.
 * 따로 설치된 Kirikiroid2 가 있으면 그 앱을 열고, 없으면 Winlator 로 실행을 제안한다.
 * (Kirikiroid2 배포 APK 에는 광고 SDK 가 들어 있어 앱이 대신 받아 설치하지 않는다)
 */
final class KirikiroidHelper {
    private KirikiroidHelper() {}

    /** 원본, Yuri 1.3.9 릴리스(패키지명에 버전이 붙음), Yuri 소스 빌드 */
    static final String[] PACKAGES = {"org.tvp.kirikiri2", "org.tvp.kirikiri2_yuri_10309", "com.yuri.kirikiri2"};

    static String installedPackage(Context c) {
        PackageManager pm = c.getPackageManager();
        for (String p : PACKAGES) {
            if (pm.getLaunchIntentForPackage(p) != null) return p;
        }
        for (android.content.pm.ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (ai.packageName.startsWith("org.tvp.kirikiri2") && pm.getLaunchIntentForPackage(ai.packageName) != null) {
                return ai.packageName;
            }
        }
        return null;
    }

    static void launch(Activity a, GameInfo g) {
        String pkg = installedPackage(a);
        if (pkg == null) {
            AlertDialog.Builder b = new AlertDialog.Builder(a)
                    .setTitle(g.title)
                    .setMessage("이 빌드에는 吉里吉里 엔진이 포함되지 않았습니다 (엔진 빌드 실패).\n"
                            + "Winlator 로 실행할까요?")
                    .setNegativeButton("취소", null);
            if (g.exe != null) {
                b.setPositiveButton("Winlator 로 실행", (d, w) ->
                        EngineLauncher.launch(a, g, Runner.WINE, "ja_JP.UTF-8"));
            }
            b.show();
            return;
        }
        String path = g.dir.getAbsolutePath();
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("게임 폴더", path));
        new AlertDialog.Builder(a)
                .setTitle(g.title)
                .setMessage("설치된 Kirikiroid2 앱으로 엽니다. 아래 폴더로 이동해 data.xp3 를 누르세요.\n\n"
                        + path + "\n\n(경로를 클립보드에 복사했습니다)")
                .setPositiveButton("열기", (d, w) -> {
                    Intent i = a.getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i != null) a.startActivity(i);
                })
                .setNegativeButton("취소", null)
                .show();
    }
}
