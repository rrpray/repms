package io.tsukurubox.core;

/** 판별 가능한 게임 엔진 */
public enum Engine {
    RM2000("RPG Maker 2000", "2K"),
    RM2003("RPG Maker 2003", "2K3"),
    XP("RPG Maker XP", "XP"),
    VX("RPG Maker VX", "VX"),
    VXACE("RPG Maker VX Ace", "VXA"),
    MV("RPG Maker MV", "MV"),
    MZ("RPG Maker MZ", "MZ"),
    WOLF("울프 RPG 에디터", "WOLF"),
    RENPY("Ren'Py", "RENPY"),
    TYRANO("TyranoBuilder", "TYRANO"),
    UNITY("Unity", "UNITY"),
    GODOT("Godot", "GODOT"),
    GAMEMAKER("GameMaker", "GM"),
    XNA("XNA / FNA / MonoGame", "XNA"),
    EXE("Windows 게임", "EXE");

    public final String displayName;
    public final String tag;

    Engine(String displayName, String tag) {
        this.displayName = displayName;
        this.tag = tag;
    }

    public boolean isRgss() {
        return this == XP || this == VX || this == VXACE;
    }

    public boolean is2k() {
        return this == RM2000 || this == RM2003;
    }
}
